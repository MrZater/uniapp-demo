import request from '@/utils/request'

export function add(data) {
  return request({
    url: 'api/storage',
    method: 'post',
    data: data
  })
}

export function del(id) {
  return request({
    url: 'api/storage/' + id,
    method: 'delete'
  })
}

export function delAll(ids) {
  return request({
    url: 'api/storage',
    method: 'delete',
    data: ids
  })
}

export function edit(id, data) {
  return request({
    url: 'api/storage/' + id,
    method: 'put',
    data: data
  })
}
