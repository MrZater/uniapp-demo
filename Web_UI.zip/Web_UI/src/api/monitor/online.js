import request from '@/utils/request'

export function del(key) {
  const data = {
    key
  }
  return request({
    url: 'auth/online',
    method: 'delete',
    data
  })
}

export function downloadOnline(params) {
  return request({
    url: 'auth/online/download',
    method: 'get',
    params,
    responseType: 'blob'
  })
}
