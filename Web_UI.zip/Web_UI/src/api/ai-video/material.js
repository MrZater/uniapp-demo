import request from '@/utils/request'

export function get(id) {
  return request({
    url: 'api/material/' + id,
    method: 'get'
  })
}

export function add(data) {
  return request({
    url: 'api/material',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/material/' + id,
    method: 'delete'
  })
}

export function enable(id) {
  return request({
    url: 'api/material/' + id,
    method: 'put'
  })
}
export function setDefaultImg(id) {
  return request({
    url: 'api/material/default/' + id,
    method: 'post'
  })
}

export function getDefaultImg() {
  return request({
    url: 'api/material/default',
    method: 'get'
  })
}
