import request from '@/utils/request'

export function getDraft() {
  const params = { page: 0, size: 20, type: 'anchor_works' }
  return request({
    url: 'api/draft',
    method: 'get',
    params
  })
}
export function getDraftWithID(id) {
  return request({
    url: 'api/draft/' + id,
    method: 'get'
  })
}
export function add(data) {
  data.type = 'anchor_works'
  return request({
    url: 'api/draft',
    method: 'post',
    data
  })
}

export function edit(id, data) {
  data.type = 'anchor_works'
  return request({
    url: 'api/draft/' + id,
    method: 'put',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/draft/' + id,
    method: 'delete'
  })
}

export function delAll(ids) {
  return request({
    url: 'api/draft',
    method: 'delete',
    data: ids
  })
}
