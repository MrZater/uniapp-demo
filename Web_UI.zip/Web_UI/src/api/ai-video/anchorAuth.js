import request from '@/utils/request'

/**
 * 获取多个授权
 * @param {string} tenantIds
 */
export function getAuthMap(tenantIds) {
  return request({
    url: 'api/anchor/auth/' + tenantIds,
    method: 'get'
  })
}

/**
 * 保存授权
 * @param {int} tenantId
 * @param {objeect} data
 */
export function editAuth(tenantId, data) {
  data.anchorIds = data.anchorIds.join(',')
  data.voicerIds = data.voicerIds.join(',')
  data.videoRatios = data.videoRatios.join(',')
  data.audioRates = data.audioRates.join(',')
  data.languageIds = data.languageIds === true ? '18' : '0'
  console.log('提交租户授权:', data)
  return request({
    url: 'api/anchor/auth/' + tenantId,
    method: 'put',
    data
  })
}

/**
 * 移除授权
 * @param {int}} tenantId
 */
export function resetAuth(tenantId) {
  return request({
    url: 'api/anchor/auth/' + tenantId,
    method: 'delete'
  })
}

export function getTenantAuth(id) {
  return request({
    url: '/api/anchor/auth/tenant/' + id,
    method: 'get'
  })
}
/**
 * 当前租户的授权信息
 */
export function getCurrentTenantAuth() {
  return request({
    url: 'api/anchor/auth/tenant',
    method: 'get'
  })
}

export function getCurrentDeptAuth() {
  return request({
    url: 'api/anchor/auth/dept',
    method: 'get'
  })
}

export function editDeptAuth(depId, data) {
  console.log('deptId:', data)
  data.anchorIds = data.anchorIds.join(',')
  data.voicerIds = data.voicerIds.join(',')
  data.videoRatios = data.videoRatios.join(',')
  data.audioRates = data.audioRates.join(',')
  data.languageIds = data.languageIds === true ? '18' : '0'
  return request({
    url: 'api/anchor/dept/' + depId,
    method: 'put',
    data
  })
}
export function deleteDeptAuth(depId) {
  return request({
    url: 'api/anchor/dept/' + depId,
    method: 'delete'
  })
}

export function getDeptAuth(depId) {
  return request({
    url: 'api/anchor/dept/' + depId,
    method: 'get'
  })
}

