import request from '@/utils/request'

export function get(id) {
  return request({
    url: 'api/works/' + id,
    method: 'get'
  })
}

export function listenAudio(data) {
  const postData = {
    title: data.title ? data.title : '未命名',
    content: data.content,
    vcn: data.vcn ? data.vcn : 'xiappei',
    spd: parseInt(data.spd),
    vol: parseInt(data.vol),
    format: data.audioFormat === 'mp3' || data.audioFormat === 'wav' ? data.audioFormat : 'mp3',
    audioType: 1,
    lanType: data.lanType,
    audioRate: data.audioRate
  }
  return request({
    url: 'api/works/tts',
    method: 'post',
    data: postData
  })
}

export function addAudio(data) {
  const postData = {
    title: data.title ? data.title : '未命名',
    content: data.content,
    vcn: data.vcn ? data.vcn : 'xiappei',
    spd: parseInt(data.spd),
    vol: parseInt(data.vol),
    format: data.audioFormat === 'mp3' || data.audioFormat === 'wav' ? data.audioFormat : 'mp3',
    audioType: 1,
    rate: data.rate,
    lanType: data.lanType
  }
  console.log('addAudioForm:', postData)
  return request({
    url: 'api/works/audio',
    method: 'post',
    data: postData
  })
}

export function addVideo(data) {
  data.subtitles = data.subtitles ? 1 : 0
  data.taskId = ''
  data.vcn = 'xiapei'
  console.log('addVideo:', data)
  return request({
    url: 'api/works/video',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/works/' + id,
    method: 'delete'
  })
}

export function edit(id, data) {
  data.subtitles = data.subtitles ? 1 : 0
  return request({
    url: 'api/works/' + id,
    method: 'put',
    data
  })
}
/**
 * 获取视频播放地址
 * @param {*} id
 */
export function getPlayUrl(id) {
  return request({
    url: 'api/works/play/' + id,
    method: 'get'
  })
}

/**
 * 获取合成任务日志
 * @param string taskId
 */
export function getTaskLog(taskId) {
  return request({
    url: 'api/tasklog/' + taskId,
    method: 'get'
  })
}
