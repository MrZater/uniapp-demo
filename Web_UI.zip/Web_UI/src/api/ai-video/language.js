import request from '@/utils/request'

export function getLanguages() {
  return request({
    url: 'api/anchor/language',
    method: 'get'
  })
}

export function add(data) {
  return request({
    url: 'api/anchor/language',
    method: 'post',
    data
  })
}

export function edit(id, data) {
  return request({
    url: 'api/anchor/language/' + id,
    method: 'put',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/anchor/language/' + id,
    method: 'delete'
  })
}

export function toggle(id) {
  return request({
    url: 'api/anchor/language/toggle/' + id,
    method: 'put'
  })
}

export function visibleLanguages() {
  return request({
    url: 'api/anchor/language/visible',
    method: 'get'
  })
}
