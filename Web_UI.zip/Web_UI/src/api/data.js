import request from '@/utils/request'
import qs from 'qs'

export function getData(url, params) {
  return request({
    url: url + '?' + qs.stringify(params, { indices: false }),
    method: 'get'
  })
}

export function getDataP(url, params) {
  return new Promise((resolve, reject) => {
    request({
      url: url + '?' + qs.stringify(params, { indices: false }),
      method: 'get'
    }).then((res) => {
      resolve(res)
    }).catch((err) => {
      reject(err)
    })
  })
}

export function download(url, params) {
  return request({
    url: url + '?' + qs.stringify(params, { indices: false }),
    method: 'get',
    responseType: 'blob'
  })
}
