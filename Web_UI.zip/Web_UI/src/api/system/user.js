import request from '@/utils/request'

export function add(data) {
  return request({
    url: 'api/user',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/user/' + id,
    method: 'delete'
  })
}

export function edit(id, data) {
  return request({
    url: 'api/user/' + id,
    method: 'put',
    data
  })
}

export function updatePass(user) {
  const data = {
    oldPass: user.oldPass,
    newPass: user.newPass
  }
  return request({
    url: 'api/user/update-pass/',
    method: 'post',
    data
  })
}

export function updateProfile(data) {
  return request({
    url: 'api/user/update-profile',
    method: 'post',
    data
  })
}

export function updatePhone(code, data) {
  return request({
    url: 'api/user/update-phone/' + code,
    method: 'post',
    data
  })
}

export function updateAvatar(data) {
  return request({
    url: 'api/user/update-avatar',
    method: 'post',
    data
  })
}

export function unlock(id) {
  return request({
    url: 'api/user/unlock/' + id,
    method: 'post'
  })
}

export function resetPasswd(id) {
  return request({
    url: 'api/user/reset-passwd/' + id,
    method: 'post'
  })
}

export function listUser(ids) {
  return request({
    url: 'api/users/map/' + ids,
    method: 'get'
  })
}

export function checkUser(id) {
  return request({
    url: 'api/user/check/' + id,
    method: 'get'
  })
}
