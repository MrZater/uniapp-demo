import request from '@/utils/request'

export function getVisibleTenants() {
  return request({
    url: 'api/tenant/visible',
    method: 'get'
  })
}

export function getVisibleTenantList() {
  return request({
    url: '/api/tenant/visible',
    method: 'get'
  })
}

export function add(data) {
  return request({
    url: 'api/tenant',
    method: 'post',
    data
  })
}

export function edit(id, data) {
  return request({
    url: 'api/tenant/' + id,
    method: 'put',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/tenant/' + id,
    method: 'delete'
  })
}

export function delAll(ids) {
  return request({
    url: 'api/tenant',
    method: 'delete',
    data: ids
  })
}
export function setSettings(id, data) {
  return request({
    url: 'api/tenant/settings/' + id,
    method: 'put',
    data
  })
}

export function getSettings() {
  return request({
    url: 'api/tenant/current',
    method: 'get'
  })
}

