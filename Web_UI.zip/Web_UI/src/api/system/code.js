import request from '@/utils/request'

export function updatePass(pass) {
  return request({
    url: 'api/user/update-pass/' + pass,
    method: 'get'
  })
}

export function resetPhone(data) {
  return request({
    url: 'api/code/reset-phone',
    method: 'post',
    data
  })
}
