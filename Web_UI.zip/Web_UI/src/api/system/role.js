import request from '@/utils/request'

// 获取所有的Role
export function getVisibleRoles() {
  return request({
    url: 'api/roles/visible',
    method: 'get'
  })
}

export function add(data) {
  const post = {
    name: data.name,
    level: data.level,
    deptIds: data.deptIds,
    remark: data.remark,
    dataScope: data.dataScope
  }
  return request({
    url: 'api/roles',
    method: 'post',
    data: post
  })
}

export function get(id) {
  return request({
    url: 'api/roles/' + id,
    method: 'get'
  })
}

export function getLevel() {
  return request({
    url: 'api/roles/level',
    method: 'get'
  })
}

export function del(id) {
  return request({
    url: 'api/roles/' + id,
    method: 'delete'
  })
}

export function edit(id, data) {
  const post = {
    name: data.name,
    level: data.level,
    deptIds: data.deptIds,
    remark: data.remark,
    dataScope: data.dataScope
  }
  return request({
    url: 'api/roles/' + id,
    method: 'put',
    data: post
  })
}

export function updateMenu(id, data) {
  return request({
    url: 'api/roles/menu/' + id,
    method: 'put',
    data
  })
}
