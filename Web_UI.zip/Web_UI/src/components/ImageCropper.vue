<template>
  <div>
    <div class="cropper-content">
      <!-- 剪裁框 -->
      <div class="cropper">
        <VueCropper
          ref="cropper"
          :img="imgFile"
          :output-size="option.size"
          :output-type="option.outputType"
          :info="option.infoTrue"
          :full="option.full"
          :can-move="option.canMove"
          :can-move-box="option.canMoveBox"
          :original="option.original"
          :auto-crop="option.autoCrop"
          :auto-crop-width="option.autoCropWidth"
          :auto-crop-height="option.autoCropHeight"
          :fixed-box="option.fixedBox"
          :fixed="option.fixed"
          :fixed-number="option.fixedNumber"
          :center-box="option.centerBox"
          :max-img-size="option.maxImgSize"
          :enlarge="option.enlarge"
          :mode="option.mode"
          @realTime="realTime"
        />
      </div>
      <!-- 预览框 -->
      <div class="show-preview" :style="{'width': (option.autoCropWidth + 20) + 'px', 'height': '400px', 'overflow': 'hidden', 'margin-left': '20px', 'padding': '10px'}">
        <div class="preview" :style="previewStyle3">
          <img :src="previews.url" :style="previews.img">
        </div>
        <div class="preview preview-round" :style="previewStyle4">
          <img :src="previews.url" :style="previews.img">
        </div>
      </div>
    </div>
    <div class="footer-btn">
      <!-- 缩放旋转按钮 -->
      <div class="scope-btn">
        <el-button-group>
          <el-button size="small" icon="el-icon-zoom-in" @click="changeScale(1)">放大</el-button>
          <el-button size="small" icon="el-icon-zoom-out" @click="changeScale(-1)">缩小</el-button>
          <el-button size="small" icon="el-icon-refresh-left" @click="rotateLeft()">左转</el-button>
          <el-button size="small" icon="el-icon-refresh-right" @click="rotateRight()">右转</el-button>
        </el-button-group>
      </div>
      <!-- 确认上传按钮 -->
      <div class="upload-btn">
        <el-button size="medium" type="primary" :disabled="isDisabled" @click="submitCrop('blob')"><svg-icon icon-class="crop" /> 裁剪</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import { VueCropper } from 'vue-cropper'
export default {
  components: { VueCropper },
  props: ['imgFile', 'fixedNumber', 'skuname'],
  data() {
    return {
      previews: {}, // 预览数据

      option: {
        infoTrue: true, // 截图信息展示是否是真实的输出宽高
        outputSize: 1, // 裁剪生成图片的质量  (默认:1)
        full: false, // 是否输出原图比例的截图 选true生成的图片会非常大  (默认:false)
        original: false, // 上传图片按照原始比例渲染  (默认:false)
        outputType: 'jpeg', // 裁剪生成图片的格式  (默认:jpeg)
        canMove: true, // 上传图片是否可以移动  (默认:true)
        canMoveBox: true, // 截图框能否拖动  (默认:true)
        centerBox: false, // 截图框能否超过图片 (默认:false)
        autoCrop: true, // 是否默认生成截图框  (默认:false)
        autoCropWidth: 200, // 默认生成截图框宽度  (默认:80%)
        autoCropHeight: 200, // 默认生成截图框高度  (默认:80%)
        fixedBox: false, // 固定截图框大小 不允许改变  (默认:false)
        fixed: true, // 是否开启截图框宽高固定比例  (默认:true)
        fixedNumber: [1, 1], // 截图框比例  (默认:[1:1])
        enlarge: 1, // 倍数  可渲染当前截图框的n倍 0 - 1000 (默认:1)
        mode: 'contain', // 图片布局方式 (默认: contain)
        maxImgSize: 2000, // 上传时图片最大大小(默认会压缩尺寸到这个大小)
        limitMinSize: [100, 100] // 截图框最小限制
      },
      isDisabled: false,
      previewStyle3: {},
      previewStyle4: {}
    }
  },
  watch: {
    imgFile: function(file) {
      this.imgFile = file
    },
    skuname: function(val) {
      this.skuname = val
    }
  },
  methods: {
    changeScale(num) {
      // 图片缩放
      num = num || 1
      this.$refs.cropper.changeScale(num)
    },
    rotateLeft() {
      // 向左旋转
      this.$refs.cropper.rotateLeft()
    },
    rotateRight() {
      // 向右旋转
      this.$refs.cropper.rotateRight()
    },
    refreshImg() {
      // this.file = this.imgFile
      this.option.img = this.imgFile.url
    },
    realTime(data) {
      var previews = data

      // 实时预览
      this.previews = previews

      this.previewStyle3 = {
        width: previews.w + 'px',
        height: previews.h + 'px',
        zoom: (this.option.autoCropWidth / previews.w)
      }
      this.previewStyle4 = {
        width: previews.w + 'px',
        height: previews.h + 'px',
        'margin-top': '20px',
        zoom: (this.option.autoCropWidth / 1.5 / previews.h)
      }
    },
    submitCrop(type) {
      // 将剪裁好的图片回传给父组件
      event.preventDefault()
      // this.isDisabled = true
      const that = this
      // console.log(this.skuname);
      if (type === 'blob') {
        this.$refs.cropper.getCropBlob(blob => {
          console.log('getCropBlob', blob)
          that.$emit('cropFinished', blob, that.skuname)
          that.$emit('crop-finished', blob, that.skuname)
        })
      } else {
        this.$refs.cropper.getCropData(data => {
          that.$emit('cropFinished', data, that.skuname)
          that.$emit('crop-finished', data, that.skuname)
        })
      }
    }
  }
}
</script>
<style lang="scss">
.cropper-content {
  display: flex;
  display: -webkit-flex;
  justify-content: flex-end;
  -webkit-justify-content: flex-end;
}
.cropper-content .cropper {
  height: 400px;
  flex: 1;
  -webkit-flex: 1;
  display: flex;
  display: -webkit-flex;
  justify-content: center;
  -webkit-justify-content: center;
}
.cropper-content .show-preview {
  overflow: hidden;
  border: 1px solid #cccccc;
  background: #cccccc;
}

.show-preview .preview {
  border: 1px solid #cccccc;
  float: left;
  margin-right: 10px;
  border-radius: 2px;
  background-color: #fff;
  overflow: hidden;
}

.show-preview .preview:hover {
  border-color: #ccf;
  box-shadow: 0 0 5px rgba(0,0,0,.15);
}

.show-preview .preview img {
  width: 100%;
}

.show-preview .preview-round{
  border-radius: 50%;
}

.footer-btn {
  margin-top: 10px;
  display: flex;
  display: -webkit-flex;
  justify-content: flex-end;
  -webkit-justify-content: flex-end;
}
.footer-btn .scope-btn {
  width: 320px;
  display: flex;
  display: -webkit-flex;
  justify-content: space-between;
  -webkit-justify-content: space-between;
}
.footer-btn .upload-btn {
  flex: 1;
  -webkit-flex: 1;
  display: flex;
  display: -webkit-flex;
  justify-content: flex-end;
  -webkit-justify-content: flex-end;
}
</style>
