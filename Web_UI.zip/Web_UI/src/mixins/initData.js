import { getData, download } from '@/api/data'
import { parseTime, downloadFile } from '@/utils/index'
import checkPermission from '@/utils/permission'

export default {
  data() {
    return {
      // 标题
      title: '',
      // 数据主键id
      priKey: 'id',
      // 表格数据
      data: [],
      // 页码
      page: 0,
      // 每页数据条数
      size: 20,
      // 排序规则，默认 id 降序， 支持多字段排序 ['id,desc', 'createTime,asc']
      sort: ['id,desc'],
      // 总数据条数
      total: 0,
      // 请求数据的url
      url: '',
      // 查询数据的参数
      params: {},
      // 待查询的对象
      query: {},
      // 等待时间
      time: 50,
      // 是否为新增类型的表单
      isAdd: false,
      // 表格 Loading 属性
      loading: true,
      // 删除 Loading 属性
      delLoading: false,
      delAllLoading: false,
      // 导出的 Loading
      downloadLoading: false,
      // 弹窗组件
      dialogForm: null,
      deleteTips: '',
      // 选择列表
      selections: [],
      statusOptions: [
        { key: 0, display_name: '禁用' },
        { key: 1, display_name: '正常' }
      ]
    }
  },
  methods: {
    parseTime,
    downloadFile,
    checkPermission,
    // async init() {
    init() {
      if (!this.beforeInit()) {
        return
      }
      return new Promise((resolve, reject) => {
        this.dialogForm = this.$refs.form
        this.loading = true
        // 请求数据
        getData(this.url, this.getQueryParams()).then(data => {
          this.total = data.totalElements
          this.data = data.content
          // time 毫秒后显示表格
          setTimeout(() => {
            this.loading = false
          }, this.time)
          resolve(data)
          this.afterInit(data.content)
        }).catch(err => {
          this.loading = false
          reject(err)
        })
      })
    },
    beforeInit() {
      return true
    },
    afterInit(data) {
      // this.data = data
      return
    },
    // 展开或折叠表格
    toggleAllRowExpansion(expanded) {
      if (typeof (this.$refs.treeTable) === 'undefined') {
        console.error('no el-table ref set as "treeTable"')
        return
      }
      const treeData = this.$refs.treeTable.store.states.treeData
      for (var item in treeData) {
        if (treeData[item].expanded !== expanded) {
          const nodeInfo = {}
          nodeInfo.id = item
          this.$refs.treeTable.toggleRowExpansion(nodeInfo, expanded)
        }
      }
    },
    getQueryParams: function() {
      return {
        ...this.params,
        sort: this.sort ? this.sort : null
      }
    },
    // 改变页码
    pageChange(e) {
      this.page = e - 1
      this.init()
    },
    // 改变每页显示数
    sizeChange(e) {
      this.page = 0
      this.size = e
      this.init()
    },
    // 预防删除第二页最后一条数据时，或者多选删除第二页的数据时，页码错误导致请求无数据
    dleChangePage(size) {
      if (size === undefined) {
        size = 1
      }
      if (this.data.length === size && this.page !== 0) {
        this.page = this.page - 1
      }
    },
    // 选择改变
    selectionChangeHandler(val) {
      this.selections = val
    },
    // 查询方法
    toQuery() {
      this.page = 0
      this.init()
    },
    isAdminRole() {
      return checkPermission(['admin', 'business'])
    },
    /**
     * 通用的提示封装
     */
    deleteSuccessNotify() {
      this.$message({
        message: '删除成功',
        type: 'success',
        duration: 2500
      })
    },
    deleteCancelNotify() {
      this.$message({
        message: '已取消删除',
        type: 'info',
        duration: 2500
      })
    },
    notify(message, type = 'info') {
      this.$message({
        message,
        type,
        duration: 2500
      })
    },

    /**
     * 带提示的启用/禁用
     */
    toggleStatus(id, status) {
      this.$confirm('您确定要【' + (status === 1 ? '禁用' : '启用') + '】该' + (this.title ? this.title : '条数据') + '吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.realToggleStatus(id, status)
      })
    },
    /**
     * 不带提示的启用/禁用
     */
    realToggleStatus(id, status) {
      this.delLoading = true
      console.log('currentMethod:', this.crudMethod)
      this.crudMethod.toggle(id).then(() => {
        this.delLoading = false
        this.$message({
          message: '操作成功',
          type: 'success',
          duration: 2500
        })
        this.afterToggleStatus(id)
        this.init()
      }).catch(() => {
        this.delLoading = false
      })
    },
    afterToggleStatus(id) {
    },

    /**
     * 删除前可以调用 deleteOne 做一些操作
     */
    deleteOne(id) {
      this.$confirm(this.deleteTips ? this.deleteTips : ('你确定【删除】该' + (this.title ? this.title : '条数据') + '吗？'), '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.realDeleteOne(id)
      }).catch(() => {
        this.deleteCancelNotify()
      })
    },
    /**
     * 通用的删除
     */
    realDeleteOne(id) {
      this.delLoading = true
      this.crudMethod.del(id).then(() => {
        this.delLoading = false
        this.deleteSuccessNotify()
        this.afterDeleteOne(id)
        this.dleChangePage()
        this.init()
      }).catch(() => {
        this.delLoading = false
      })
    },
    afterDeleteOne(id) {
    },

    /**
     * 多选删除提示
     */
    batchDelete() {
      this.$confirm('你确定【删除】选中的数据吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.realBatchDelete()
      }).catch(() => {
        this.deleteCancelNotify()
      })
    },
    /**
     * 多选删除
     */
    realBatchDelete() {
      this.delAllLoading = true
      const data = this.$refs.table.selection
      const ids = []
      for (let i = 0; i < data.length; i++) {
        ids.push(data[i][this.priKey])
      }
      this.crudMethod.delAll(ids).then(() => {
        this.delAllLoading = false
        this.dleChangePage(ids.length)
        this.deleteSuccessNotify()
        this.afterBatchDelete()
        this.init()
      }).catch(() => {
        this.delAllLoading = false
      })
    },
    afterBatchDelete() {
    },

    /**
     * 显示新增弹窗前可以调用该方法
     */
    beforeShowAddDialog() {
    },
    /**
     * 显示新增弹窗
     */
    showAddDialog() {
      this.isAdd = true
      this.beforeShowAddDialog()
      if (this.dialogForm) {
        this.dialogForm.resetForm = JSON.parse(JSON.stringify(this.dialogForm.form))
        this.dialogForm.dialog = true
      }
    },

    /**
     * 显示编辑弹窗前可以调用该方法
     */
    beforeShowEditDialog(data) {
      return data
    },
    /**
     * 显示编辑弹窗
     */
    showEditDialog(data = {}) {
      this.isAdd = false
      const formData = this.beforeShowEditDialog(data)
      if (this.dialogForm) {
        this.dialogForm.id = data[this.priKey] ? data[this.priKey] : 0
        this.dialogForm.resetForm = JSON.parse(JSON.stringify(this.dialogForm.form))
        this.dialogForm.form = JSON.parse(JSON.stringify(formData))
        this.dialogForm.dialog = true
      }
    },

    /**
     * 通用导出
     */
    exportExcel() {
      this.beforeInit()
      this.downloadLoading = true
      download(this.url + '/download', this.params).then(result => {
        this.downloadFile(result, this.title + '数据', 'xlsx')
        this.downloadLoading = false
      }).catch(() => {
        this.downloadLoading = false
      })
    }
  }
}
