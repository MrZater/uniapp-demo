import { getDictMap } from '@/api/system/dictDetail'

export default {
  data() {
    return {
      dictMap: {}, labelMap: {}
    }
  },
  methods: {
    // 多个字典查询时使用逗号拼接， 如：
    // 加载多个数据字典，如何调用如下：
    // this.getDictMap('user_status,job_status')
    // 在vue中使用加载出来的字典：
    // dictMap.[字典名称] 如：dictMap.user_status、 dictMap.job_status
    async getDictMap(name) {
      // 优先放入到dictMap中，避免页面加载时 undefined
      const names = name.split(',')
      for (let i = 0; i < names.length; i++) {
        this.dictMap[names[i]] = {}
        this.labelMap[names[i]] = {}
      }

      await getDictMap(name).then(resMap => {
        console.log(resMap)
        names.forEach(name => {
          const dicts = resMap[name]
          this.dictMap[name] = dicts
          dicts.forEach(dict => {
            this.labelMap[name][dict.value] = dict.label
          })
        })

        console.log(this.labelMap)
      })
    }
  }
}
