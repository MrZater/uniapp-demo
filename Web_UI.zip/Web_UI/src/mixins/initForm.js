export default {
  props: {
    isAdd: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      // ID
      id: 0,
      // 标题
      title: '',
      // 表格 Loading 属性
      loading: false,
      // 弹窗 Loading 属性
      dialog: false,
      // Form 表单
      form: {},
      // 重置表单
      resetForm: {},
      statusOptions: [
        { key: 0, display_name: '禁用' },
        { key: 1, display_name: '正常' }
      ]
    }
  },
  methods: {
    /**
     * 获取弹窗的标题
     */
    getFormTitle() {
      return this.isAdd ? `新增${this.title}` : `编辑${this.title}`
    },

    /**
     * 通用的提示封装
     */
    addSuccessNotify() {
      this.$message({
        message: '新增成功',
        type: 'success',
        duration: 2500
      })
    },
    editSuccessNotify() {
      this.$message({
        message: '编辑成功',
        type: 'success',
        duration: 2500
      })
    },

    /**
     * 新增方法
     */
    doAdd() {
      this.crudMethod.add(this.form).then(() => {
        this.addSuccessNotify()
        this.loading = false
        this.afterDoAdd()
        this.cancel()
        this.$parent.init()
      }).catch(() => {
        this.loading = false
      })
    },
    /**
     * 新增后可以调用该方法
     */
    afterDoAdd() {},

    /**
     * 通用的编辑方法
     */
    doEdit() {
      this.crudMethod.edit(this.id, this.form).then(() => {
        this.editSuccessNotify()
        this.loading = false
        this.afterDoEdit()
        this.cancel()
        this.$parent.init()
      }).catch(() => {
        this.loading = false
      })
    },
    /**
     * 编辑后可以调用该方法
     */
    afterDoEdit() {},

    /**
     * 提交前可以调用该方法
     */
    beforeSubmitForm() {
      return true
    },
    /**
     * 提交
     */
    submitForm() {
      if (!this.beforeSubmitForm()) {
        return
      }
      if (this.$refs['form']) {
        this.$refs['form'].validate((valid) => {
          if (valid) {
            this.loading = true
            if (this.isAdd) {
              this.doAdd()
            } else {
              this.doEdit()
            }
          }
        })
      }
    },

    /**
     * 隐藏弹窗
     */
    cancel() {
      this.dialog = false
      this.$refs['form'].clearValidate()
      this.form = this.resetForm
    }

  }
}
