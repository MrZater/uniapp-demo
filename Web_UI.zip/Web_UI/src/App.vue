<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style scoped>

.el-table {
    margin-top: 5px;
    border-radius: 2px;
    box-shadow: 0px 0px 1px rgba(0, 0, 0, .2), 0px 1px 0px rgba(0, 0, 0, .1);
}
</style>
