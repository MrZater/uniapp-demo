<template>
  <div class="login" :style="{ background:loginBackImageUrl }">
    <el-form ref="loginForm" :model="loginForm" :rules="loginRules" label-position="left" label-width="0px" class="login-form">
      <h3 class="title">{{ webName }}</h3>
      <el-form-item prop="username">
        <el-input v-model="loginForm.username" type="text" auto-complete="off" placeholder="账号">
          <svg-icon slot="prefix" icon-class="user" class="el-input__icon" />
        </el-input>
      </el-form-item>
      <el-form-item prop="password">
        <el-input v-model="loginForm.password" type="password" auto-complete="off" placeholder="密码" @keyup.enter.native="handleLogin">
          <svg-icon slot="prefix" icon-class="password" class="el-input__icon" />
        </el-input>
      </el-form-item>
      <el-form-item prop="code">
        <el-input v-model="loginForm.code" auto-complete="off" placeholder="验证码" style="width: 63%" @keyup.enter.native="handleLogin">
          <svg-icon slot="prefix" icon-class="validCode" class="el-input__icon" />
        </el-input>
        <div class="login-code">
          <img :src="codeUrl" @click="getCode">
        </div>
      </el-form-item>
      <el-form-item style="width:100%;">
        <el-button :loading="loading" type="primary" class="loginButton" @click.native.prevent="handleLogin">
          <span v-if="!loading">登&nbsp;&nbsp;&nbsp;&nbsp;录</span>
          <span v-else>登 录 中...</span>
        </el-button>
      </el-form-item>
      <el-form-item>
        <div style="width:100%;text-align: center">
          <img v-show="logoUrl.length > 0" class="user_logo" :src="logoUrl">
          <div v-show="logoUrl.length >0 " class="line" />
          <el-image :src="imgSrc" class="c_logo" fit="fill" /></div>
      </el-form-item>
    </el-form>
    <!--  底部  -->
    <div v-if="$store.state.settings.showFooter" id="el-login-footer">
      <span v-html="$store.state.settings.footerTxt" />
      <span> ⋅ </span>
      <a href="http://www.beian.miit.gov.cn" target="_blank">{{ $store.state.settings.caseNumber }}</a>
    </div>
  </div>
</template>

<script>
import md5 from 'js-md5'
import { mapState } from 'vuex'
import { getCodeImg } from '@/api/login'
import { getDataP } from '@/api/data'
import i_img from '@/assets/logo/c_logo.png'
import login_bg from '@/assets/login/bg.jpg'
export default {
  name: 'Login',
  data() {
    return {
      imgSrc: i_img,
      codeUrl: '',
      loginBackImageUrl: `url(${login_bg})`,
      logoUrl: '',
      loginForm: {
        username: '',
        password: '',
        code: '',
        uuid: ''
      },
      loginRules: {
        username: [{ required: true, trigger: 'blur', message: '用户名不能为空' }],
        password: [{ required: true, trigger: 'blur', message: '密码不能为空' }],
        code: [{ required: true, trigger: 'change', message: '验证码不能为空' }]
      },
      loading: false,
      redirect: undefined
    }
  },
  computed: {
    ...mapState({
      webName: state => state.settings.webName
    })
  },
  created() {
    this.$nextTick(() => {
      this.getConfigFromDomain()
      this.getCode()
    })
  },
  methods: {
    getConfigFromDomain() {
      getDataP('api/tenant/domain', { domain: document.domain }).then(res => {
        if (res && res.tenantConfig) {
          const config = res.tenantConfig
          if (config.hasOwnProperty('logoUrl') && config.logoUrl.length > 0) {
            this.logoUrl = config.logoUrl
            this.$store.dispatch('UpdateUserLogo', res.logoUrl)
          }
          if (config.hasOwnProperty('bgUrl') && config.bgUrl.length > 0) {
            this.loginBackImageUrl = `url(${config.bgUrl})`
          }
          this.setLogoAndBg()
        }
      })
    },
    setLogoAndBg() {
      var link = document.querySelector("link[rel*='icon']") || document.createElement('link')
      link.type = 'image/x-icon'
      link.rel = 'shortcut icon'
      link.href = this.logoUrl
      document.getElementsByTagName('head')[0].appendChild(link)
    },
    getCode() {
      getCodeImg().then(res => {
        this.codeUrl = 'data:image/gif;base64,' + res.img
        this.loginForm.uuid = res.uuid
      })
    },
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        const user = {
          username: this.loginForm.username,
          password: md5(this.loginForm.password),
          code: this.loginForm.code,
          uuid: this.loginForm.uuid
        }

        if (valid) {
          this.loading = true
          this.$store.dispatch('Login', user).then(() => {
            this.loading = false
            this.$router.push({ path: '/' })
          }).catch(() => {
            this.loading = false
            this.getCode()
          })
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  .login {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    background-size: cover !important;
    background-repeat: no-repeat !important;
  }

  .title {
    margin: 0px auto 30px auto;
    text-align: center;
    color: #707070;
  }
  .login-form {
    border-radius: 6px;
    background: #ffffff;
    width: 400px;
    padding: 25px 25px 5px 25px;
  }
  /deep/ .el-form-item__error {
    left: 0;
  }
  .login-code {
    width: 33%;
    display: inline-block;
    height: 40px;
    float: right;
    img{
      height: 38px;
      cursor: pointer;
      vertical-align:middle;
      border-radius: 3px;
      border: 1px solid #eee;
    }
  }
  .loginButton{
    width:100%;
    background-color:rgb(27, 57, 84);
    font-size: 16px;
  }
  .line{
    width:1px;
    background-color:rgb(211, 211, 211);
    height: 30px;
    display: inline-block;
    margin:0 10px;
  }
  .user_logo{
    height:25px;
  }
  .c_logo{
    width: 85px;
    height: 25px;;
  }
</style>
