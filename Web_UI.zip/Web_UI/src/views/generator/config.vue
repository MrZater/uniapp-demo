<template>
  <div class="app-container">
    <el-row :gutter="10">
      <el-col>
        <el-card class="box-card" shadow="never" style="margin-bottom:10px">
          <div slot="header" class="clearfix">
            <span class="role-span">生成配置：{{ tableName }}</span>
            <div style="float: right">
              <el-button :loading="configLoading" icon="el-icon-check" size="mini" type="primary" @click="doSubmit">保存</el-button>
            </div>
          </div>
          <el-form ref="form" :inline="true" :model="form" :rules="rules" size="small" label-width="100px">
            <el-form-item label="接口名称" prop="apiAlias">
              <span slot="label">
                接口名称
                <el-tooltip class="item" effect="dark" content="接口的名称，用于控制器与接口文档中" placement="top-start">
                  <i class="el-icon-question" />
                </el-tooltip>
              </span>
              <el-input v-model="form.apiAlias" placeholder="输入接口名称" />
            </el-form-item>
            <el-form-item label="作者名称" prop="author">
              <span slot="label">
                作者名称
                <el-tooltip class="item" effect="dark" content="类上面的作者名称" placement="top-start">
                  <i class="el-icon-question" />
                </el-tooltip>
              </span>
              <el-input v-model="form.author" placeholder="输入作者名称" />
            </el-form-item>
            <el-form-item label="模块名称" prop="moduleName">
              <span slot="label">
                模块名称
                <el-tooltip class="item" effect="dark" content="模块的名称，请选择项目中已存在的模块" placement="top-start">
                  <i class="el-icon-question" />
                </el-tooltip>
              </span>
              <el-input v-model="form.moduleName" placeholder="输入模块名称" />
            </el-form-item>
            <el-form-item label="至于包下" prop="pack">
              <span slot="label">
                至于包下
                <el-tooltip class="item" effect="dark" content="项目包的名称，生成的代码放到哪个包里面" placement="top-start">
                  <i class="el-icon-question" />
                </el-tooltip>
              </span>
              <el-input v-model="form.pack" placeholder="输入包名，如：com.xxx.xxx" />
            </el-form-item>
            <el-form-item label="去表前缀" prop="prefix">
              <span slot="label">
                去表前缀
                <el-tooltip class="item" effect="dark" content="默认不去除表前缀，可自定义" placement="top-start">
                  <i class="el-icon-question" />
                </el-tooltip>
              </span>
              <el-input v-model="form.prefix" placeholder="默认不去除表前缀" />
            </el-form-item>
            <el-form-item label="前端路径" prop="path">
              <span slot="label">
                前端路径
                <el-tooltip class="item" effect="dark" content="输入views文件夹下的目录，不存在即创建" placement="top-start">
                  <i class="el-icon-question" />
                </el-tooltip>
              </span>
              <el-input v-model="form.path" placeholder="输入前端路径" />
            </el-form-item>
            <el-form-item label="是否覆盖" prop="cover">
              <span slot="label">
                是否覆盖
                <el-tooltip class="item" effect="dark" content="谨防误操作，请慎重选择" placement="top-start">
                  <i class="el-icon-question" />
                </el-tooltip>
              </span>
              <el-radio-group v-model="form.cover" size="mini">
                <el-radio-button label="true">是</el-radio-button>
                <el-radio-button label="false">否</el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <el-card class="box-card" shadow="never" style="margin-bottom:10px">
          <div slot="header" class="clearfix">
            <span class="role-span">字段配置</span>
            <div style="float: right">
              <el-tooltip class="item" effect="dark" content="数据库中表字段变动时使用该功能" placement="top-start">
                <el-button :loading="syncLoading" icon="el-icon-refresh" size="mini" type="info" @click="sync">同步</el-button>
              </el-tooltip>
              <el-button :loading="columnLoading" icon="el-icon-check" size="mini" type="primary" @click="saveColumnConfig">保存</el-button>
              <el-button :loading="genLoading" icon="el-icon-s-promotion" size="mini" type="success" @click="toGen">保存&生成</el-button>
            </div>
          </div>
          <el-form size="small" label-width="90px">
            <el-table v-loading="loading" :data="data" :max-height="tableHeight">
              <el-table-column prop="columnName" label="字段名称" />
              <el-table-column prop="columnType" label="字段类型" />
              <el-table-column prop="remark" label="字段描述">
                <template slot-scope="scope">
                  <el-input v-model="data[scope.$index].remark" size="mini" class="edit-input" />
                </template>
              </el-table-column>
              <el-table-column align="center" label="是否必填" width="70px">
                <template slot-scope="scope">
                  <el-checkbox v-model="data[scope.$index].notNull" />
                </template>
              </el-table-column>
              <el-table-column align="center" label="列表显示" width="70px">
                <template slot-scope="scope">
                  <el-checkbox v-model="data[scope.$index].listShow" />
                </template>
              </el-table-column>
              <el-table-column align="center" label="表单显示" width="70px">
                <template slot-scope="scope">
                  <el-checkbox v-model="data[scope.$index].formShow" />
                </template>
              </el-table-column>
              <el-table-column label="表单类型">
                <template slot-scope="scope">
                  <el-select v-model="data[scope.$index].formType" filterable class="edit-input" clearable size="mini" placeholder="请选择">
                    <el-option label="单行文本框" value="Input" />
                    <el-option label="多行文本域" value="Textarea" />
                    <el-option label="单选框" value="Radio" />
                    <el-option label="下拉框" value="Select" />
                    <el-option label="日期选择框" value="Date" />
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column label="查询方式">
                <template slot-scope="scope">
                  <el-select v-model="data[scope.$index].queryType" filterable class="edit-input" clearable size="mini" placeholder="请选择">
                    <el-option label="=" value="=" />
                    <el-option label="!=" value="!=" />
                    <el-option label=">=" value=">=" />
                    <el-option label="<=" value="<=" />
                    <el-option label="Like" value="Like" />
                    <el-option label="BetWeen" value="BetWeen" />
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column label="日期注解">
                <template slot-scope="scope">
                  <el-select v-model="data[scope.$index].dateAnnotation" filterable class="edit-input" clearable size="mini" placeholder="请选择">
                    <el-option label="自动创建时间" value="CreationTimestamp" />
                    <el-option label="自动更新时间" value="UpdateTimestamp" />
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column label="关联字典">
                <template slot-scope="scope">
                  <el-select v-model="data[scope.$index].dictName" filterable class="edit-input" clearable size="mini" placeholder="请选择">
                    <el-option v-for="item in dicts" :key="item.id" :label="item.remark === '' ? item.name : item.remark" :value="item.name" />
                  </el-select>
                </template>
              </el-table-column>
            </el-table>
          </el-form>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { updateConfig, getConfig, save, sync, generator } from '@/api/generator/generator'
import { getDicts } from '@/api/system/dict'
export default {
  name: 'GeneratorConfig',
  mixins: [initData],
  data() {
    return {
      tableName: '', columnLoading: false, configLoading: false, tableHeight: 550, dicts: [], syncLoading: false, genLoading: false,
      form: { author: '', pack: '', path: '', moduleName: '', cover: 'false', apiPath: '', prefix: '', apiAlias: null },
      rules: {
        author: [
          { required: true, message: '作者不能为空', trigger: 'blur' }
        ],
        pack: [
          { required: true, message: '包路径不能为空', trigger: 'blur' }
        ],
        moduleName: [
          { required: true, message: '包路径不能为空', trigger: 'blur' }
        ],
        path: [
          { required: true, message: '前端路径不能为空', trigger: 'blur' }
        ],
        apiAlias: [
          { required: true, message: '接口名称不能为空', trigger: 'blur' }
        ],
        cover: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 190
    this.tableName = this.$route.params.tableName
    this.$nextTick(() => {
      this.init()
      getConfig(this.tableName).then(data => {
        this.form = data
        this.form.cover = this.form.cover.toString()
      })
      getDicts().then(data => {
        this.dicts = data
      })
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/generator/columns'
      const tableName = this.tableName
      this.params = { tableName }
      return true
    },
    saveColumnConfig() {
      this.columnLoading = true
      save(this.data).then(res => {
        this.notify('保存成功', 'success')
        this.columnLoading = false
      }).catch(err => {
        this.columnLoading = false
        console.log(err.response.data.message)
      })
    },
    doSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.configLoading = true
          updateConfig(this.tableName, this.form).then(res => {
            this.notify('保存成功', 'success')
            this.form = res
            this.form.cover = this.form.cover.toString()
            this.configLoading = false
          }).catch(err => {
            this.configLoading = false
            console.log(err.response.data.message)
          })
        }
      })
    },
    sync() {
      this.syncLoading = true
      sync([this.tableName]).then(() => {
        this.init()
        this.notify('同步成功', 'success')
        this.syncLoading = false
      }).then(() => {
        this.syncLoading = false
      })
    },
    toGen() {
      this.genLoading = true
      save(this.data).then(res => {
        this.notify('保存成功', 'success')
        // 生成代码
        generator(this.tableName, 0).then(data => {
          this.genLoading = false
          this.notify('生成成功', 'success')
        }).catch(err => {
          this.genLoading = false
          console.log(err.response.data.message)
        })
      }).catch(err => {
        this.genLoading = false
        console.log(err.response.data.message)
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

  .role-span {
    font-weight: bold; color: #303133;
    font-size: 15px;
  }

  .edit-input {
    .el-input__inner {
      border: 1px solid #e5e6e7;
    }
  }

  /deep/ .input-with-select .el-input-group__prepend {
    background-color: #fff;
  }
</style>
