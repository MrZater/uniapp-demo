<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <el-input v-model="query.name" clearable size="small" placeholder="请输入表名" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>

      <el-tooltip slot="right" class="item" effect="dark" content="数据库中表字段变动时使用该功能" placement="top-start">
        <el-button
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-refresh"
          :loading="syncLoading"
          :disabled="selections.length === 0"
          @click="toSync"
        >同步</el-button>
      </el-tooltip>
    </div>
    <!--表格渲染-->
    <el-table v-loading="loading" :data="data" style="width: 100%;" @selection-change="selectionChangeHandler">
      <el-table-column type="selection" width="55" />
      <el-table-column prop="tableName" label="表名" />
      <el-table-column prop="engine" label="数据库引擎" />
      <el-table-column prop="coding" label="字符编码集" />
      <el-table-column prop="remark" label="备注" />
      <el-table-column prop="createTime" label="创建日期">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button size="mini" type="text" @click="toConfig(scope.row.tableName)">配置</el-button>
          <el-button size="mini" type="text" @click="tpPreview(scope.row.tableName)">预览</el-button>
          <el-button size="mini" type="text" @click="toDownload(scope.row.tableName)">下载</el-button>
          <el-button size="mini" type="text" @click="toGen(scope.row.tableName)">生成</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      :current-page="page + 1"
      :page-size="size"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"
    />
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { generator, sync } from '@/api/generator/generator'
export default {
  name: 'GeneratorIndex',
  mixins: [initData],
  data() {
    return {
      syncLoading: false
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/generator/tables'
      return true
    },
    toConfig(tableName) {
      this.$router.push('/sys-tools/generator/config/' + tableName)
      return
    },
    tpPreview(tableName) {
      this.$router.push('/sys-tools/generator/preview/' + tableName)
      return
    },
    toGen(tableName) {
      // 生成代码
      generator(tableName, 0).then(data => {
        this.$notify({
          title: '生成成功',
          type: 'success',
          duration: 2500
        })
      })
    },
    toDownload(tableName) {
      // 打包下载
      generator(tableName, 2).then(data => {
        this.downloadFile(data, tableName, 'zip')
      })
    },
    toSync() {
      const tables = []
      this.selections.forEach(val => {
        tables.push(val.tableName)
      })
      this.syncLoading = true
      sync(tables).then(() => {
        this.syncLoading = false
        this.$message({
          type: 'success',
          message: '同步成功!'
        })
      }).then(() => {
        this.syncLoading = false
      })
    }
  }
}
</script>

<style scoped>

</style>
