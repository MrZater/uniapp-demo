<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>
<script>
import echarts from 'echarts'
//   import '../../node_modules/echarts/map/js/world.js'
// import '../../node_modules/echarts/map/js/china.js' // 引入中国地图数据
// 引入中国地图数据
require('echarts/map/js/china')
require('echarts/theme/macarons') // echarts theme
import { debounce } from '@/utils'

export default {
  name: 'ChinaMap',
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '800px'
    },
    chartData: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      chart: null,
      sidebarElm: null
    }
  },
  watch: {
    chartData: function(val) {
      this.setOptions()
    }
  },
  mounted() {
    this.initChart()
    this.__resizeHandler = debounce(() => {
      if (this.chart) {
        this.chart.resize()
      }
    }, 100)
    window.addEventListener('resize', this.__resizeHandler)

    // 监听侧边栏的变化
    this.sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    this.sidebarElm && this.sidebarElm.addEventListener('transitionend', this.sidebarResizeHandler)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    window.removeEventListener('resize', this.__resizeHandler)

    this.sidebarElm && this.sidebarElm.removeEventListener('transitionend', this.sidebarResizeHandler)

    this.chart.dispose()
    this.chart = null
  },
  methods: {
    sidebarResizeHandler(e) {
      if (e.propertyName === 'width') {
        this.__resizeHandler()
      }
    },
    getProvinceLabels(date) {
      var titleData = []
      const mapData = this.chartData.filter(item => {
        return item.date === date
      })
      if (mapData && mapData.length > 0) {
        mapData[0].data.slice(-20).forEach(province => {
          titleData.push(province.name)
        })
      }
      return titleData
    },
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      if (this.chartData && this.chartData.length > 0) {
        this.setOptions()
      }
    },
    setOptions() {
      var legendData = []
      var seriesData = []
      this.chartData.forEach(item => {
        legendData.push(item.date)

        // 左侧地图
        seriesData.push({
          z: 1,
          name: item.date,
          type: 'map',
          map: 'china',
          layoutCenter: ['38%', '50%'],
          layoutSize: 800,
          label: {
            normal: {
              show: true
            },
            emphasis: {
              show: true
            }
          },
          data: item.data
        })
        // 右侧bar
        seriesData.push({
          name: item.date,
          z: 2,
          type: 'bar',
          label: {
            normal: {
              show: true
            },
            emphasis: {
              show: true
            }
          },
          itemStyle: {
            emphasis: {
              color: 'rgb(254,153,78)'
            }
          },
          data: item.data.slice(-20)
        })
      })

      var options = {
        backgroundColor: '#fff',
        // title: [{
        //   text: '各省收视占比',
        //   subtext: '仅供参考',
        //   left: 'center'
        // }],
        tooltip: {
          trigger: 'item'
        },
        legend: {
          orient: 'vertical',
          left: 30,
          data: legendData,
          selectedMode: 'single'
        },
        visualMap: {
          orient: 'horizontal',
          min: 10000,
          max: 1000000,
          left: 30,
          bottom: 40,
          text: ['高', '低'],
          calculable: true,
          colorLightness: [0.2, 100],
          color: ['#FF6000', '#FFFDD4'],
          dimension: 0
        },
        toolbox: {
          show: true,
          orient: 'vertical',
          left: 'right',
          top: 'center'
        },
        grid: {
          right: 30,
          top: 80,
          bottom: 80,
          width: '20%'
        },
        xAxis: [{
          position: 'top',
          type: 'value',
          boundaryGap: false,
          axisLabel: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          }
        }],
        yAxis: [{
          name: 'TOP20的省份',
          type: 'category',
          data: this.getProvinceLabels(legendData[0]),
          axisTick: {
            alignWithLabel: true
          }
        }],
        series: seriesData
      }
      this.chart.setOption(options)

      const that = this
      this.chart.on('legendselectchanged', function(params) {
        options.yAxis[0].data = that.getProvinceLabels(params.name)
        that.chart.setOption(options)
      })
    }
  }
}
</script>
