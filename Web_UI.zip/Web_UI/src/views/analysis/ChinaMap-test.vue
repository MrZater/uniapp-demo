<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>
<script>
import echarts from 'echarts'
//   import '../../node_modules/echarts/map/js/world.js'
// import '../../node_modules/echarts/map/js/china.js' // 引入中国地图数据
// 引入中国地图数据
require('echarts/map/js/china')
require('echarts/theme/macarons') // echarts theme
import { debounce } from '@/utils'

function NumDescSort(a, b) {
  return a.value - b.value
}

function randomData() {
  return Math.round(Math.random() * 10000)
}

export default {
  name: 'ChinaMap',
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '800px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  mounted() {
    this.initChart()
    this.__resizeHandler = debounce(() => {
      if (this.chart) {
        this.chart.resize()
      }
    }, 100)
    window.addEventListener('resize', this.__resizeHandler)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    window.removeEventListener('resize', this.__resizeHandler)
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')

      var data = [{
        name: '北京',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '天津',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '上海',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '重庆',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '河北',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '河南',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '云南',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '辽宁',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '黑龙江',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '湖南',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '安徽',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '山东',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '新疆',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '江苏',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '浙江',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '江西',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '湖北',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '广西',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '甘肃',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '山西',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '内蒙古',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '陕西',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '吉林',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '福建',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '贵州',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '广东',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '青海',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '西藏',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '四川',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '宁夏',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '海南',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '台湾',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '香港',
        value1: randomData(),
        value2: randomData()
      }, {
        name: '澳门',
        value1: randomData(),
        value2: randomData()
      }]

      var resultdata0 = []
      var resultdata1 = []
      var resultdata2 = []
      var sum0 = 0
      var sum1 = 0
      var sum2 = 0
      var titledata = []
      for (var i = 0; i < data.length; i++) {
        var d0 = {
          name: data[i].name,
          value: data[i].value1 + data[i].value2
        }
        var d1 = {
          name: data[i].name,
          value: data[i].value1
        }
        var d2 = {
          name: data[i].name,
          value: data[i].value2
        }
        titledata.push(data[i].name)
        resultdata0.push(d0)
        resultdata1.push(d1)
        resultdata2.push(d2)
        sum0 += data[i].value1 + data[i].value2
        sum1 += data[i].value1
        sum2 += data[i].value2
      }

      resultdata0.sort(NumDescSort)
      resultdata1.sort(NumDescSort)
      resultdata2.sort(NumDescSort)

      const options = {
        title: [{
          text: '各省收视占比',
          subtext: '仅供参考',
          left: 'center'
        }],
        tooltip: {
          trigger: 'item'
        },
        legend: {
          orient: 'vertical',
          left: 'left',
          data: ['总量', '2020-09-21', '2020-09-22'],
          selectedMode: 'single'
        },
        visualMap: {
          orient: 'horizontal',
          min: 0,
          max: 20000,
          left: 'left',
          bottom: 40,
          text: ['高', '低'],
          calculable: true,
          colorLightness: [0.2, 100],
          color: ['#6FCF6A', '#FFFD64', '#FF5000'],
          dimension: 0
        },
        toolbox: {
          show: true,
          orient: 'vertical',
          left: 'right',
          top: 'center'
        },
        grid: {
          right: 40,
          top: 40,
          bottom: 40,
          width: '20%'
        },
        xAxis: [{
          position: 'top',
          type: 'value',
          boundaryGap: false,
          splitLine: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          }
        }],
        yAxis: [{
          type: 'category',
          data: titledata,
          axisTick: {
            alignWithLabel: true
          }
        }],
        series: [{
          z: 1,
          name: '总量',
          type: 'map',
          map: 'china',
          layoutCenter: ['38%', '50%'],
          layoutSize: 800,
          label: {
            normal: {
              show: true
            },
            emphasis: {
              show: true
            }
          },
          data: resultdata0
        }, {
          z: 1,
          name: '2020-09-21',
          type: 'map',
          map: 'china',
          layoutCenter: ['38%', '50%'],
          layoutSize: 800,
          label: {
            normal: {
              show: true
            },
            emphasis: {
              show: true
            }
          },
          data: resultdata1
        }, {
          z: 1,
          name: '2020-09-22',
          type: 'map',
          map: 'china',
          layoutCenter: ['38%', '50%'],
          layoutSize: 800,
          label: {
            normal: {
              show: true
            },
            emphasis: {
              show: true
            }
          },
          data: resultdata2
        }, {
          name: '总量',
          z: 2,
          type: 'bar',
          label: {
            normal: {
              show: true
            },
            emphasis: {
              show: true
            }
          },
          itemStyle: {
            emphasis: {
              color: 'rgb(254,153,78)'
            }
          },
          data: resultdata0
        }, {
          name: '2020-09-21',
          z: 2,
          type: 'bar',
          label: {
            normal: {
              show: true
            },
            emphasis: {
              show: true
            }
          },
          itemStyle: {
            emphasis: {
              color: 'rgb(254,153,78)'
            }
          },
          data: resultdata1
        }, {
          name: '2020-09-22',
          z: 2,
          type: 'bar',
          label: {
            normal: {
              show: true
            },
            emphasis: {
              show: true
            }
          },
          itemStyle: {
            emphasis: {
              color: 'rgb(254,153,78)'
            }
          },
          data: resultdata2
        }]
      }
      this.chart.setOption(options)
    }
  }
}
</script>
