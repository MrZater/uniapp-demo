<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入搜索内容" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-select v-model="query.type" clearable placeholder="类型" class="filter-item" style="width: 130px">
        <el-option v-for="item in queryTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <el-button v-permission="['admin','voiceWorks:add']" class="filter-item" size="mini" type="primary" icon="el-icon-plus" @click="showAddDialog">新增</el-button>
      <!-- 导出 -->
      <el-button :loading="downloadLoading" size="mini" class="filter-item" type="warning" icon="el-icon-download" @click="showAddDialog">导出</el-button>
      <!-- 多选删除 -->
      <el-button v-permission="['admin','voiceWorks:delete']" :loading="delAllLoading" :disabled="data.length === 0 || $refs.table.selection.length === 0" class="filter-item" size="mini" type="danger" icon="el-icon-delete" @click="showAddDialog">删除</el-button>
      <!--表单组件-->
      <eForm ref="form" :is-add="isAdd" />
      <!--表格渲染-->
      <el-table ref="table" v-loading="loading" :data="data" style="width: 100%;">
        <el-table-column type="selection" width="55" />
        <el-table-column prop="id" label="自动编号" />
        <el-table-column prop="userId" label="用户ID" />
        <el-table-column prop="deptId" label="部门ID" />
        <el-table-column prop="title" label="作品名称" />
        <el-table-column prop="content" label="发音内容" />
        <el-table-column prop="vcn" label="发音人" />
        <el-table-column prop="spd" label="语速" />
        <el-table-column prop="vol" label="音量" />
        <el-table-column prop="type" label="类型 0音频 1视频" />
        <el-table-column prop="format" label="音频格式mp3/wav,视频格式mp4/avi" />
        <el-table-column prop="anchorId" label="形象ID" />
        <el-table-column prop="location" label="虚拟主播位置" />
        <el-table-column prop="createTime" label="创建时间">
          <template slot-scope="scope">
            <span>{{ parseTime(scope.row.createTime) }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态">
          <template slot-scope="scope">
            {{ labelMap['common_status'][scope.row.status] }}
          </template>
        </el-table-column>
        <el-table-column v-if="checkPermission(['admin','voiceWorks:edit','voiceWorks:delete'])" label="操作" width="150px" align="center">
          <template slot-scope="scope">
            <el-button v-permission="['admin','voiceWorks:edit']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
            <el-button v-permission="['admin','voiceWorks:delete']" :loading="delLoading" size="mini" type="danger" icon="el-icon-delete" @click="deleteOne(scope.row.id)" />
          </template>
        </el-table-column>
      </el-table>
      <!--分页组件-->
      <el-pagination
        :total="total"
        :current-page="page + 1"
        :page-size="size"
        style="margin-top: 8px;"
        layout="total, prev, pager, next, sizes"
        @size-change="sizeChange"
        @current-change="pageChange"
      />
    </div>
  </div>
</template>

<script>
import initDict from '@/mixins/initDict'
import initData from '@/mixins/initData'
import { del } from '@/api/ai-voice/voiceWorks'
import eForm from './form'
export default {
  components: { eForm },
  mixins: [initData, initDict],
  data() {
    return {
      title: '语音',
      crudMethod: { del },
      priKey: 'id',
      // 排序规则，默认 id 降序， 支持多字段排序 ['id,desc', 'createTime,asc']
      sort: ['id,desc'],
      queryTypeOptions: [
        { key: 'userId', display_name: '用户ID' },
        { key: 'deptId', display_name: '部门ID' },
        { key: 'title', display_name: '作品名称' }
      ]
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()

      // 加载数据字典
      this.getDictMap('common_status')

      console.log(this.labelMap)
    })
  },
  methods: {
    // 获取数据前设置好接口地址
    beforeInit() {
      this.url = 'api/voiceWorks'
      const sort = 'id,desc'
      this.params = { page: this.page, size: this.size, sort: sort }
      const query = this.query
      const type = query.type
      const value = query.value
      if (type && value) { this.params[type] = value }
      return true
    }
  }
}
</script>

<style scoped>

</style>
