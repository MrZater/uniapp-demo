<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" :title="getFormTitle()" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="自动编号">
        <el-input v-model="form.id" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="用户ID" prop="userId">
        <el-input v-model="form.userId" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="部门ID" prop="deptId">
        <el-input v-model="form.deptId" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="作品名称" prop="title">
        <el-input v-model="form.title" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="发音内容" prop="content">
        <el-input v-model="form.content" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="发音人" prop="vcn">
        <el-input v-model="form.vcn" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="语速" prop="spd">
        <el-input v-model="form.spd" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="音量" prop="vol">
        <el-input v-model="form.vol" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="类型 0音频 1视频" prop="type">
        未设置字典，请手动设置 Radio
      </el-form-item>
      <el-form-item label="音频格式mp3/wav,视频格式mp4/avi">
        未设置字典，请手动设置 Radio
      </el-form-item>
      <el-form-item label="形象ID">
        <el-input v-model="form.anchorId" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="虚拟主播位置">
        <el-input v-model="form.location" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="创建时间">
        <el-input v-model="form.createTime" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="状态 0待合成 1合成成功 2合成失败 3合成中" prop="status">
        <el-input v-model="form.status" style="width: 370px;" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="submitForm">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/ai-voice/voiceWorks'
export default {
  title: '菜单',
  mixins: [initForm],
  props: {
    isAdd: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      crudMethod: { add, edit },
      form: {
        id: '',
        userId: '',
        deptId: '',
        title: '',
        content: '',
        vcn: '',
        spd: '',
        vol: '',
        type: '',
        format: '',
        anchorId: '',
        location: '',
        createTime: '',
        updateTime: '',
        status: '',
        isDeleted: ''
      },
      rules: {
      }
    }
  },
  methods: {

  }
}
</script>

<style scoped>

</style>
