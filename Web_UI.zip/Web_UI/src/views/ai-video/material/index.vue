<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入文件名称搜索" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />

      <el-select v-model="query.type" clearable placeholder="类型" class="filter-item" style="width: 90px" @change="toQuery">
        <el-option v-for="item in typeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-select v-model="query.tenantId" v-permission="['admin','business']" placeholder="租户" class="filter-item" style="width: 120px" @change="rToQuery">
        <el-option v-for="item in tenantList" :key="item.id" :label="item.name" :value="item.id" />
      </el-select>
      <el-cascader v-model="query.deptId" :disabled="query.tenantId === '0'" :options="deptList" :props="props" :show-all-levels="false" placeholder="部门" class="filter-item" style="width: 120px" />
      <el-select v-model="query.status" clearable placeholder="状态" class="filter-item" style="width: 90px" @change="toQuery">
        <el-option v-for="item in statusOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <div v-permission="['admin','material:add']" style="display: inline-block;margin: 0px 2px;">
        <el-button
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-upload"
          @click="uploadHandle"
        >上传素材</el-button>
      </div>
    </div>

    <!-- 弹窗, 上传文件 -->
    <upload v-if="uploadVisible" ref="upload" @refreshDataList="init" />

    <!--表格渲染-->
    <el-table v-loading="loading" :data="data">
      <el-table-column type="index" width="50" align="center" />
      <el-table-column :show-overflow-tooltip="true" prop="name" label="素材名称">
        <template slot-scope="scope">
          <el-link :underline="false" :href="scope.row.url" target="_blank" type="primary">{{ scope.row.name }}</el-link>
          <el-tag v-if="scope.row.id === defaultImageID" type="success">正在使用</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="类型" align="center" prop="type">
        <template slot-scope="scope">
          <div v-for="item in typeOptions" :key="item.key">
            <el-tag v-if="scope.row.type === item.key" size="small" :type="item.type">{{ item.display_name }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="部门 / 上传者">
        <template slot-scope="scope">
          {{ scope.row.deptName +' / ' + scope.row.userName }}
        </template>
      </el-table-column>
      <el-table-column label="文件大小" align="center">
        <template slot-scope="scope">
          <div>{{ getCountFileSize(scope.row.size) }}</div>
        </template>
      </el-table-column>
      <el-table-column label="状态" align="center">
        <template slot-scope="scope">
          <div v-for="item in statusOptions" :key="item.key">
            <el-tag v-if="scope.row.status === item.key" size="small" :type="scope.row.status === 1 ? '' : 'info'">{{ item.display_name }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建日期" align="center">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column v-if="checkPermission(['admin','material:edit','material:delete'])" label="操作" align="center">
        <template slot-scope="scope">
          <el-button v-if="scope.row.type === 'image'" v-permission="['admin','material:edit']" :disabled="scope.row.status == 0 || userDeptId !== scope.row.deptId || scope.row.id === defaultImageID" size="mini" type="success" @click="setDefaultBackgroundImage(scope.row.id)">默认背景</el-button>
          <el-button v-permission="['admin','material:edit']" :disabled="editLoading" size="mini" :type="(scope.row.status == 1 ? 'warning' : 'success')" icon="el-icon-edit" @click="subEdit(scope.row.id)">{{ scope.row.status == 1 ? '禁用' : '启用' }}</el-button>
          <el-button v-permission="['admin','material:delete']" :loading="delLoading" type="danger" icon="el-icon-delete" size="mini" @click="deleteOne(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      :current-page="page + 1"
      :page-size="size"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"
    />
  </div>
</template>

<script>
import Upload from './upload'
import initData from '@/mixins/initData'
import { del, enable, setDefaultImg } from '@/api/ai-video/material'
import { getVisibleTenants } from '@/api/system/tenant'
import { getVisibleDepts } from '@/api/system/dept'
import { getDefaultImg } from '@/api/ai-video/material'
export default {
  name: 'Materials',
  components: {
    Upload
  },
  mixins: [initData],
  data() {
    return {
      props: {
        value: 'id',
        label: 'label',
        children: 'children',
        checkStrictly: true
      },
      userDeptId: this.$store.getters.user.dept.id,
      defaultImageID: 0,
      deptList: [],
      tenantList: [],
      delLoading: false,
      editLoading: false,
      uploadVisible: false,
      typeOptions: [
        { key: 'image', type: 'info', display_name: '图片' },
        { key: 'audio', type: 'success', display_name: '音频' },
        { key: 'video', type: '', display_name: '视频' }
      ],
      dialog: false
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
      this.getTenantList()
      this.getDefaultBgImg()
    })
  },
  methods: {
    getCountFileSize(size) {
      return (size / 1024 / 1024).toFixed(2) + 'M'
    },
    beforeInit() {
      this.url = 'api/material'
      this.params = { page: this.page, size: this.size }
      const query = this.query
      const value = query.value
      const type = query.type
      const status = query.status
      const deptId = query.deptId
      const tenantID = query.tenantId === undefined ? '0' : query.tenantId
      this.params['tenantId'] = tenantID
      if (value) { this.params['name'] = value }
      if (type !== '' && type !== null) { this.params['type'] = type }
      if (status !== '' && status !== null) { this.params['status'] = status }
      if (deptId !== '' && deptId !== null && deptId !== undefined) { this.params['deptId'] = deptId[deptId.length - 1] }
      return true
    },
    afterInit(data) {
      if (!data || data.length === 0) {
        return
      }
      console.log('素材S：', data, 'user:', this.$store.getters.user)
      const userIds = []
      data.forEach(function(data, index) {
        if (userIds.indexOf(data.userId) === -1) {
          userIds.push(data.userId)
        }
      })
      return
    },
    rToQuery() {
      if (this.query.tenantId !== '0') {
        getVisibleDepts({ 'tenantId': this.query.tenantId, status: 1 }).then(deptRes => {
          this.deptList = deptRes.content
        })
      } else {
        this.deptList = []
        this.query.deptId = null
      }
      this.page = 0
      this.init()
    },
    getDefaultBgImg() {
      getDefaultImg().then(res => {
        this.defaultImageID = res.id
      }).catch(() => {
      })
    },
    getTenantList() {
      if (this.isAdminRole()) {
        getVisibleTenants().then(res => {
          const all = { 'id': '0', 'name': '所有租户' }
          this.tenantList = res.content
          this.query.tenantId = '0'
          this.tenantList.splice(0, 0, all)
          this.rToQuery()
        })
      } else {
        this.query.tenantId = String(this.$store.getters.user.tenantId)
        this.rToQuery()
      }
    },
    // 上传文件
    uploadHandle() {
      this.uploadVisible = true
      this.$nextTick(() => {
        this.$refs.upload.init()
      })
    },
    deleteOne(id) {
      this.$confirm('此操作将永久删除该素材, 是否继续?', '提示', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' }).then(() => {
        this.delLoading = true
        del(id).then(res => {
          this.delLoading = false
          this.dleChangePage()
          this.init()
          this.$message({
            message: '删除成功',
            type: 'success',
            duration: 2500
          })
        }).catch(err => {
          this.delLoading = false
          console.log(err.response.data.message)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    setDefaultBackgroundImage(id) {
      const _that = this
      setDefaultImg(id).then(res => {
        _that.$message({
          message: '设置成功',
          type: 'success',
          duration: 2500
        })
        this.page = 0
        this.init()
      })
    },
    subEdit(id) {
      this.editLoading = true
      enable(id).then(res => {
        this.editLoading = false
        for (let i = 0; i < this.data.length; i++) {
          if (id === this.data[i].id) {
            this.data[i].status = this.data[i].status === 1 ? 0 : 1
            break
          }
        }
        this.$message({
          message: '操作成功',
          type: 'success',
          duration: 2500
        })
      }).catch(err => {
        this.editLoading = false
        console.log(err.response.data.message)
      })
    }
  }
}
</script>

