<template>
  <div class="container">
    <el-dialog v-loading.fullscreen.lock="loading" :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="visible" title="上传素材" width="500px">
      <el-form ref="form" :model="form" :rules="rules" size="small" label-width="80px">
        <el-form-item label="素材说明" prop="name">
          <el-input ref="input" v-model="form.name" style="width: 370px;" />
        </el-form-item>
        <!--   上传文件   -->
        <el-form-item ref="uploadItem" label="选择素材" prop="file">
          <el-upload
            ref="upload"
            action="http://aboutblank.com"
            drag
            :accept="allowedFileTypes"
            list-type="picture"
            :http-request="aliUploadFile"
            :limit="2"
            :file-list="files"
            :auto-upload="false"
            :before-upload="handleBeforeUpload"
            :on-change="handleFileChange"
            :on-remove="handleRemoveFile"
          >
            <i class="el-icon-upload" />
            <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          </el-upload>
        </el-form-item>
        <el-form-item label="提示">
          <span>只允许上传PNG/JPG、MP3/WAV、MP4/AVI格式的文件，且文件大小不超过100M</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="medium" round @click="cancel">取消</el-button>
        <el-button type="primary" size="medium" round @click="doSubmit">确认</el-button>
      </div>
    </el-dialog>
    <el-dialog title="素材上传" :show-close="false" :visible.sync="uploadDialogVisibale" :close-on-click-modal="false" append-to-body width="600px">
      <el-progress style="padding-bottom: 20px" type="line" :text-inside="true" :stroke-width="20" :percentage="uploadProgress" />
    </el-dialog>
  </div>
</template>

<script>
import AliOSS from '@/utils/ali-oss'
import { getToken } from '@/utils/auth'
import { add } from '@/api/ai-video/material'
export default {
  data() {
    return {
      filePromise: null,
      files: [],
      uploadDialogVisibale: false,
      uploadProgress: 0,
      loading: false,
      visible: false,
      allowedFileTypes: 'jpg,png,mp3,wav,mp4,avi',
      form: {
        file: null,
        name: ''
      },
      rules: {
        name: [
          { required: true, message: '请输入素材说明', trigger: 'blur' },
          { min: 3, max: 30, message: '长度在 3 到 30 个字符', trigger: 'blur' }
        ],
        file: [
          { required: true, message: '请选择要上传的文件', trigger: 'change' }
        ]
      }
    }
  },
  methods: {
    init(id) {
      this.visible = true
    },
    cancel() {
      this.resetForm()
      this.$refs.upload.clearFiles()
    },
    doSubmit() {
      const that = this
      this.$refs['form'].validate((valid) => {
        if (valid) {
          that.visible = false
          that.$refs.upload.submit()
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm() {
      this.visible = false
      this.$refs['form'].resetFields()
      this.form = {
        id: '',
        name: ''
      }
    },
    getFileWidthHeight(file) {
      if (file.type === 'image/png' || file.type === 'image/jpeg') {
        this.filePromise = new Promise((resolve, reject) => {
          const img = new Image()
          img.onload = function() {
            resolve(img)
          }
          img.src = URL.createObjectURL(file)
        }).then(res => {
          const ratio = `${res.width} x ${res.height}`
          return Promise.resolve(ratio)
        }).catch(err => {
          return Promise.reject(err)
        })
      } else {
        this.filePromise = null
      }
    },
    aliUploadFile(res) {
      const that = this
      this.loading = true
      AliOSS.ossUploadFile({
        header: {
          'Authorization': 'Bearer ' + getToken()
        },
        file: res.file,
        onProgress: p => {
          that.loading = false
          that.uploadProgress = p.percent
          that.uploadDialogVisibale = true
        },
        onSuccess: fileUrl => {
          that.loading = false
          that.uploadProgress = 0
          that.uploadDialogVisibale = false
          that.$refs.upload.clearFiles()
          if (that.filePromise === null) {
            const content = {
              'name': that.$refs.input.value,
              'type': res.file.type,
              'url': fileUrl,
              'filename': res.file.name,
              'size': res.file.size
            }
            that.handleAdd(content)
          } else {
            that.filePromise.then((ratio) => {
              const content = {
                'name': that.$refs.input.value,
                'type': res.file.type,
                'url': fileUrl,
                'filename': res.file.name,
                'size': res.file.size,
                'ratio': ratio
              }
              that.handleAdd(content)
            })
          }
        },
        onError: error => {
          that.loading = false
          that.uploadProgress = 0
          that.uploadDialogVisibale = false
          that.$refs.upload.clearFiles()
          console.log(error)
        }
      })
    },
    handleAdd(content) {
      console.log('uploadCotent:', content)
      const that = this
      add(content).then(res => {
        that.resetForm()
        that.$message({
          message: '素材上传成功',
          type: 'success',
          duration: 2500
        })
        that.loading = false
        that.$parent.init()
      }).catch(res => {
        that.$message({
          message: '素材上传失败',
          type: 'error'
        })
      })
    },
    handleBeforeUpload(file) {
      this.getFileWidthHeight(file)
      console.log('handleBeforeUpload', file)
      const fileType = file.name.split('.')[1].toLowerCase()
      const isAllowed = this.allowedFileTypes.split(',').indexOf(fileType) >= 0
      const isLt2M = file.size / 1024 / 1024 < 100
      if (!isAllowed) {
        this.$message.error('上传文件类型不允许!')
      }
      if (!isLt2M) {
        this.$message.error('上传文件大小不能超过100MB!')
      }
      return isAllowed && isLt2M
    },

    handleFileChange(file, fileList) {
      this.files = fileList.slice(-1)
      this.form.file = true
      this.$refs.uploadItem.clearValidate()
      console.log(this.files)
    },
    handleRemoveFile(file) {
      this.form.file = null
      this.$refs.uploadItem.resetField()
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
/deep/ .el-upload-dragger {
    width: 370px;
    height: 120px;
}

.el-upload-dragger .el-icon-upload {
    font-size: 67px;
    color: #C0C4CC;
    margin: 20px 0 10px;
    line-height: 50px;
}
</style>
