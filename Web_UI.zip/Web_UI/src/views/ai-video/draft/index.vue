<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入搜索内容" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <div style="display: inline-block;">
        <el-button
          :loading="delAllLoading"
          :disabled="data.length === 0"
          class="filter-item"
          size="mini"
          type="danger"
          icon="el-icon-delete"
          @click="batchDelete"
        >删除</el-button>
      </div>
    </div>
    <!--表格渲染-->
    <el-table ref="table" v-loading="loading" :data="data" @selection-change="selectChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column prop="title" label="名称" />
      <el-table-column prop="content" label="草稿内容">
        <template slot-scope="scope">
          <span class="lineBreak">{{ scope.row.content.content }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建时间">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150px" align="center">
        <template slot-scope="scope">
          <el-button size="mini" type="primary" icon="el-icon-edit" @click="enterCreateView(scope.row)" />
          <el-button :loading="delLoading" size="mini" type="danger" icon="el-icon-delete" @click="deleteOne(scope.row.id)" />
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      :current-page="page + 1"
      :page-size="size"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"
    />
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { del, delAll } from '@/api/ai-video/draft'
export default {
  mixins: [initData],
  data() {
    return {
      title: '草稿',
      crudMethod: { del, delAll },
      priKey: 'id'
    }
  },
  created() {
    console.log('table:', this.$refs)
    this.$nextTick(() => {
      this.init()
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/draft'
      const value = this.query.value
      this.params = { page: this.page, size: this.size, type: 'anchor_works' }
      if (value) { this.params['title'] = value }
      return true
    },
    afterInit() {
      console.log('data:', this.data)
    },
    enterCreateView(row) {
      console.log('draftrow:', row)
      this.$router.push({ path: './create', query: { draftId: row.id }})
    },
    selectChange(val) {
    }
  }
}
</script>

<style scoped>
.lineBreak{
  text-overflow: -o-ellipsis-lastline;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 5;
  -webkit-box-orient: vertical;
}
</style>
