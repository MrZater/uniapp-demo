<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入搜索内容" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-select v-model="query.status" clearable placeholder="状态" class="filter-item" style="width: 90px" @change="toQuery">
        <el-option v-for="item in statusOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <div style="display: inline-block;margin: 0px 2px;">
        <el-button
          v-permission="['admin','anchor:config']"
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-plus"
          @click="showAddDialog"
        >新增</el-button>
      </div>
    </div>
    <!--表单组件-->
    <eForm ref="form" :is-add="isAdd" />
    <!--表格渲染-->
    <el-table v-loading="loading" :data="data">
      <el-table-column prop="sort" label="排序" align="center" width="80" />
      <el-table-column prop="thumb" label="形象">
        <template slot-scope="scope">
          <el-image :src="scope.row.thumb" />
        </template>
      </el-table-column>
      <el-table-column prop="name" label="名称" />
      <el-table-column prop="type" label="类型" align="center">
        <template slot-scope="scope">
          <div v-for="item in typeOptions" :key="item.key">
            <el-tag v-if="scope.row.type === item.key" size="small" :type="scope.row.type === 1 ? '' : 'info'">{{ item.display_name }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="partnerId" label="合作方ID" align="center" />
      <el-table-column prop="description" label="描述" show-overflow-tooltip />
      <el-table-column prop="createTime" label="添加时间">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" align="center">
        <template slot-scope="scope">
          <div v-for="item in statusOptions" :key="item.key">
            <el-tag v-if="scope.row.status === item.key" size="small" :type="scope.row.status === 1 ? '' : 'info'">{{ item.display_name }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column v-if="checkPermission(['admin','anchor:config'])" label="操作" width="150px" align="center">
        <template slot-scope="scope">
          <el-button v-permission="['admin','anchor:config']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
          <el-button v-permission="['admin','anchor:config']" size="mini" type="warning" @click="toggleStatus(scope.row.id, scope.row.status)"><svg-icon :icon-class="scope.row.status === 1 ? 'disable' : 'enable'" /></el-button>
          <el-button v-permission="['admin','anchor:config']" size="mini" type="danger" icon="el-icon-delete" @click="deleteOne(scope.row.id)" />
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      :current-page="page + 1"
      :page-size="size"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"
    />
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { del, toggle } from '@/api/ai-video/anchor'
import eForm from './form'
export default {
  components: { eForm },
  mixins: [initData],
  data() {
    return {
      title: '形象',
      crudMethod: { del, toggle },
      sort: ['sort,desc'],
      typeOptions: [
        { key: 0, display_name: '卡通' },
        { key: 1, display_name: '真人' }
      ]
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/anchor'
      this.params = { page: this.page, size: this.size }
      const query = this.query
      const value = query.value
      const status = query.status
      if (value) { this.params['name'] = value }
      if (status !== '' && status !== null) { this.params['status'] = status }
      return true
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
/deep/ .el-image__inner {
  width: 75px;
  height: 75px;
  border: 1px solid #dddddd;
  border-radius: 5px;
}
</style>
