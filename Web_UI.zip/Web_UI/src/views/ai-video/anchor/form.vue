<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" :title="getFormTitle()" width="500px">
    <el-form ref="form" v-loading.fullscreen.lock="loading" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="排序" prop="sort">
        <el-input-number v-model.number="form.sort" :min="1" :max="999" controls-position="right" />
      </el-form-item>
      <el-form-item ref="uploadRef" label="形象图片" prop="thumb">
        <el-upload
          ref="upload"
          class="avatar-uploader"
          action=""
          :http-request="aliUploadFile"
          :accept="allowedFileTypes"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="fileOnChange"
        >
          <img v-if="form.thumb" :src="form.thumb" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon el-upload" />
        </el-upload>
      </el-form-item>
      <el-form-item label="名称" prop="name">
        <el-input v-model="form.name" placeholder="请输入虚拟形象名称" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="类型" prop="type" required>
        <el-radio v-for="item in typeOptions" :key="item.key" v-model="form.type" :label="item.key">{{ item.display_name }}</el-radio>
      </el-form-item>
      <el-form-item label="合作方ID" prop="partnerId">
        <el-input v-model="form.partnerId" type="number" placeholder="请输入合作方ID，数字" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="描述" prop="description">
        <el-input v-model="form.description" placeholder="请输入虚拟形象描述" type="textarea" maxlength="250" show-word-limit :autosize="{ minRows: 3, maxRows: 6}" style="width: 370px;" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="text" size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/ai-video/anchor'
import AliOSS from '@/utils/ali-oss'
import { getToken } from '@/utils/auth'

export default {
  mixins: [initForm],
  data() {
    return {
      title: '形象',
      imageUrl: '',
      crudMethod: { add, edit },
      fileChange: false,
      allowedFileTypes: 'image/png,image/jpeg',
      form: {
        id: '',
        sort: '',
        partnerId: 2,
        name: '',
        thumb: '',
        description: ''
      },
      rules: {
        sort: [
          { required: true, message: '排序不能为空', trigger: 'blur' }
        ],
        partnerId: [
          { required: true, message: '合作方ID不能为空，且只能为整数', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '名称不能为空', trigger: 'blur' }
        ],
        thumb: [
          { required: true, message: '请选择要上传的文件', trigger: 'change' }
        ]
      },
      typeOptions: [
        { key: 0, display_name: '卡通' },
        { key: 1, display_name: '真人' }
      ]
    }
  },
  methods: {
    aliUploadFile(res) {
      this.loading = true
      console.log('uploadFile:', res)
      const that = this
      AliOSS.ossUploadFile({
        header: {
          'Authorization': 'Bearer ' + getToken()
        },
        file: res.file,
        onProgress: p => {
        },
        onSuccess: fileUrl => {
          that.loading = false
          that.$refs.upload.clearFiles()
          that.form.thumb = fileUrl
          if (that.isAdd) {
            that.doAdd()
          } else {
            that.doEdit()
          }
        },
        onError: error => {
          that.loading = false
          console.log(error)
          that.$message({
            message: '提交失败',
            type: 'error'
          })
        }
      })
    },
    fileOnChange(file) {
      const isAllowed = this.allowedFileTypes.split(',').indexOf(file.raw.type) >= 0
      const isLt2M = file.size / 1024 / 1024 < 100
      if (!isAllowed) {
        this.$message.error('上传文件类型不允许!')
        return false
      }
      if (!isLt2M) {
        this.$message.error('上传文件大小不能超过100MB!')
        return false
      }
      this.fileChange = true
      this.form.thumb = URL.createObjectURL(file.raw)
      this.$refs.uploadRef.clearValidate()
      return isAllowed && isLt2M
    },
    cancel() {
      this.dialog = false
      this.$refs['form'].clearValidate()
      this.form = this.resetForm

      this.fileChange = false
      this.$refs.upload.clearFiles()
      this.imageUrl = null
    },
    doSubmit() {
      const that = this
      this.$refs['form'].validate((valid) => {
        if (valid) {
          that.dialog = false
          if (!that.isAdd && !that.fileChange) {
            that.doEdit()
          } else {
            that.$refs.upload.submit()
          }
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style scoped>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 120px;
    height: 120px;
    line-height: 120px;
    text-align: center;
  }
  .avatar {
    width: 120px;
    height: 120px;
    display: block;
    border-radius: 6px;
  }
</style>
