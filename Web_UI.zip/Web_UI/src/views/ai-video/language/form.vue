<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" :title="getFormTitle()" width="500px">
    <el-form ref="form" v-loading.fullscreen.lock="loading" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="排序" prop="sort">
        <el-input-number v-model.number="form.sort" :min="1" :max="999" controls-position="right" />
      </el-form-item>
      <el-form-item label="名称" prop="name">
        <el-input v-model="form.name" placeholder="请输入语种名称" style="width: 370px;" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="text" size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/ai-video/language'
export default {
  mixins: [initForm],
  data() {
    return {
      title: '语种',
      imageUrl: '',
      crudMethod: { add, edit },
      form: {
        id: '',
        sort: '',
        name: '',
        description: ''
      },
      rules: {
        sort: [
          { required: true, message: '排序不能为空', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '名称不能为空', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {

    cancel() {
      this.dialog = false
      this.$refs['form'].clearValidate()
      this.form = this.resetForm
    },
    doSubmit() {
      const that = this
      this.$refs['form'].validate((valid) => {
        if (valid) {
          that.dialog = false
          if (that.isAdd) {
            that.doAdd()
          } else {
            that.doEdit()
          }
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style scoped>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 120px;
    height: 120px;
    line-height: 120px;
    text-align: center;
  }
  .avatar {
    width: 120px;
    height: 120px;
    display: block;
    border-radius: 6px;
  }
</style>
