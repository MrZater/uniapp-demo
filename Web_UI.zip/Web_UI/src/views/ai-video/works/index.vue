<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入作品名称搜索" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-select v-model="query.type" clearable placeholder="类型" class="filter-item" style="width: 90px" @change="toQuery">
        <el-option v-for="item in typeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-select v-model="query.tenantId" v-permission="['admin','business']" placeholder="租户" class="filter-item" style="width: 120px" @change="rToQuery">
        <el-option v-for="item in tenantList" :key="item.id" :label="item.name" :value="item.id" />
      </el-select>
      <el-cascader ref="cascader" v-model="query.deptId" :options="deptList" :props="props" :disabled="query.tenantId === '0'" :show-all-levels="false" placeholder="部门" class="filter-item" style="width: 120px" />
      <el-select v-model="query.status" clearable placeholder="状态" class="filter-item" style="width: 90px" @change="toQuery">
        <el-option v-for="item in statusOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <div v-permission="['admin','works:add']" style="display: inline-block;margin: 0px 2px;">
        <el-button
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-plus"
          @click="add"
        >创建作品</el-button>
      </div>
    </div>
    <!--表单组件-->
    <el-dialog :title="videoTitle" :visible.sync="playVideoDialogVisible" append-to-body width="650" show-close @close="closePlay">
      <div v-if="!isIE()">
        <vue-audio v-if="videoTitle === '音频播放'" :the-url="videoUrl" />
        <player v-else ref="videoPlayer" :video-url="videoUrl" />
      </div>
      <div v-else ref="iePlayer" v-html="embedHtml" />
    </el-dialog>
    <!--表格渲染-->
    <el-table v-loading="loading" :data="data">
      <el-table-column prop="id" label="ID" align="center" width="100">
        <template slot-scope="scope">
          <span class="table_id" title="点击复制" @click="handleClipBoard($event,scope.row.id)">{{ scope.row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="title" label="作品名称" />
      <el-table-column label="作品时长" nowrap align="center">
        <template slot-scope="scope">
          {{ scope.row.duration ? scope.row.duration.substring(0, 8) : '' }}
        </template>
      </el-table-column>
      <el-table-column label="部门 / 创建者">
        <template slot-scope="scope">
          {{ scope.row.deptName }}<br>{{ scope.row.userName }}
        </template>
      </el-table-column>
      <el-table-column prop="content" label="发音内容" show-overflow-tooltip />
      <el-table-column label="类型" align="center" width="80" prop="type">
        <template slot-scope="scope">
          <div v-for="item in typeOptions" :key="item.key">
            <el-tag v-if="scope.row.type === item.key" size="small" :type="scope.row.type ? '' : 'info'">{{ item.display_name }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="合成状态" align="center" width="80" prop="status">
        <div slot-scope="scope">
          <div v-for="item in statusOptions" :key="item.key">
            <el-popover v-if="scope.row.status === item.key" placement="top" width="480" trigger="click">
              <el-table v-loading="taskLoading" :data="gridData" :show-header="false" size="small">
                <el-table-column type="index" width="30" />
                <el-table-column prop="createTime" label="时间" width="150">
                  <template slot-scope="scope2">
                    <span>{{ parseTime(scope2.row.createTime) }}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="message" label="信息" show-overflow-tooltip />
              </el-table>
              <el-tag slot="reference" size="small" :type="item.type" @click="viewTaskLog(scope.row.taskId)">{{ item.display_name }}</el-tag>
            </el-popover>
          </div>
        </div>
      </el-table-column>
      <el-table-column prop="createTime" align="center" label="创建时间 / 过期时间">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}<br>{{ parseTime(scope.row.expireTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="200px" align="center">
        <template slot-scope="scope">
          <el-button v-if="scope.row.status == 1" v-permission="['admin','works:list']" size="mini" type="success" icon="el-icon-caret-right" @click="playVideo(scope.row)">播放</el-button>
          <el-button v-if="scope.row.status == 1" v-permission="['admin','works:download']" size="mini" type="primary" icon="el-icon-download" @click="download(scope.row)">下载</el-button>
          <el-button v-permission="['admin','works:edit']" size="mini" type="warning" icon="el-icon-edit" @click="edit(scope.row)">重新制作</el-button>
          <el-button v-permission="['admin','works:delete']" :loading="delLoading" type="danger" icon="el-icon-delete" size="mini" @click="deleteOne(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      :current-page="page + 1"
      :page-size="size"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"
    />

    <!--下载进度条-->
    <el-dialog title="文件下载" :show-close="dowloadProgress === 0" :visible.sync="downLoadDialogVisibale" :close-on-click-modal="false" append-to-body width="600px">
      <div v-if="dowloadProgress === 0">
        <el-input v-model="downloadTitle" placeholder="请输入文件名" maxlength="50" show-word-limit />
      </div>
      <div v-else>
        <el-progress type="line" :text-inside="true" :stroke-width="20" :percentage="dowloadProgress" />
      </div>
      <div v-if="dowloadProgress === 0" slot="footer" class="dialog-footer">
        <el-button @click="handleClipBoard($event,'')">复制地址</el-button>
        <el-button type="primary" @click="startDownloadFile">开始下载</el-button>
      </div>
      <div v-else slot="footer" class="dialog-footer">
        <el-button type="warning" @click="cancleDownloadFile">取消下载</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import Player from '@/views/player/index'
import { downloadFile, cancleDownload } from '@/utils/download'
import initData from '@/mixins/initData'
import { del, getPlayUrl, getTaskLog } from '@/api/ai-video/works'
import { getVisibleTenants } from '@/api/system/tenant'
import { getVisibleDepts } from '@/api/system/dept'
import VueAudio from '@/components/AudioPlayer'
import clipboard from '@/utils/clipboard'
export default {
  name: 'Works',
  components: { VueAudio, Player },
  mixins: [initData],
  data() {
    return {
      props: {
        value: 'id',
        label: 'label',
        children: 'children',
        checkStrictly: true
      },
      embedHtml: '',
      deptList: [],
      tenantList: [],
      timer: null,
      videoTitle: '',
      videoUrl: '',
      videoPaused: false,
      delLoading: false,
      playVideoDialogVisible: false,
      downLoadDialogVisibale: false,
      dowloadProgress: 0,
      downloadUrl: false,
      // 任务日志相关
      taskLoading: false,
      taskLogVisible: false,
      gridData: [],
      userData: {},
      visibleTaskId: '',
      downloadTitle: '', // 下载文件名
      typeOptions: [
        { key: 0, display_name: '音频' },
        { key: 1, display_name: '视频' }
      ],
      statusOptions: [
        { key: 0, type: 'info', display_name: '合成中' },
        { key: 1, type: '', display_name: '合成成功' },
        { key: 2, type: 'danger', display_name: '合成失败' },
        { key: 4, type: 'danger', display_name: '已过期' }
      ]
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
      this.getTenantList()
    })
  },
  destroyed() {
    if (this.timer) {
      clearInterval(this.timer)
    }
  },
  methods: {
    beforeInit() {
      this.url = 'api/works'
      this.params = { page: this.page, size: this.size }
      const query = this.query
      const value = query.value
      const type = query.type
      const status = query.status
      const deptId = query.deptId
      const tenantId = query.tenantId === undefined ? '0' : query.tenantId
      if (value) { this.params['title'] = value }
      if (type !== '' && type !== null) { this.params['type'] = type }
      if (status !== '' && status !== null) { this.params['status'] = status }
      if (deptId !== '' && deptId !== null && deptId !== undefined) { this.params['deptId'] = deptId[deptId.length - 1] }
      if (tenantId !== '' && tenantId !== null && tenantId !== undefined) { this.params['tenantId'] = tenantId }
      return true
    },
    afterInit(data) {
      if (!data || data.length === 0) {
        return
      }
      const userIds = []
      var needReload = false
      const date = Date.parse(new Date())
      // 是否过期
      data.forEach(function(data, index) {
        if (data.status === 1) {
          data.status = date > data.expireTime ? 4 : data.status
        }
        if (userIds.indexOf(data.userId) === -1) {
          userIds.push(data.userId)
        }
        if (data.status === 0 || data.status === 3) {
          needReload = true
        }
      })
      needReload ? this.startTimer() : this.stopTimer()
      return
    },
    copyID() {

    },
    rToQuery() {
      if (this.query.tenantId !== '0') {
        getVisibleDepts({ 'tenantId': this.query.tenantId, status: 1 }).then(deptRes => {
          this.deptList = deptRes.content
        })
      } else {
        this.deptList = []
      }
      this.page = 0
      this.init()
    },
    getTenantList() {
      console.log('this.isAdminRole:', this.isAdminRole())
      if (this.isAdminRole()) {
        getVisibleTenants().then(res => {
          console.log('租户列表：', res)
          const all = { 'id': '0', 'name': '所有租户' }
          this.tenantList = res.content
          this.query.tenantId = '0'
          this.tenantList.splice(0, 0, all)
        })
      } else {
        this.query.tenantId = this.$store.getters.user.tenantId
        this.rToQuery()
      }
    },
    startTimer() {
      const that = this
      if (this.timer === null) {
        this.timer = setInterval(() => {
          that.init()
        }, 60000)
      }
    },
    stopTimer() {
      clearInterval(this.timer)
      this.timer = null
    },
    viewTaskLog(taskId) {
      console.log(taskId)
      if (taskId === undefined || taskId === '') {
        this.visibleTaskId = taskId
        this.gridData = []
        return
      }

      if (this.taskLogVisible && this.visibleTaskId === taskId) {
        return
      }
      this.taskLoading = true
      this.visibleTaskId = taskId
      this.taskLogVisible = !this.taskLogVisible
      getTaskLog(taskId).then(res => {
        this.taskLoading = false
        this.taskLogVisible = true
        this.gridData = res
      }).catch(() => {
        this.taskLoading = false
      })
    },
    deleteOne(id) {
      this.$confirm('此操作将永久删除该作品, 是否继续?', '提示', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' }).then(() => {
        this.delLoading = true
        del(id).then(res => {
          this.delLoading = false
          this.dleChangePage()
          this.init()
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        }).catch(err => {
          this.delLoading = false
          console.log(err.response.data.message)
        })
      }).catch(() => {
      })
    },
    add() {
      this.$router.push({ path: './create' })
    },
    edit(data) {
      this.$router.push({
        path: './create',
        query: {
          worksId: data.id
        },
        params: {
          worksId: data.id
        }
      })
    },

    closePlay() {
      this.videoPaused = true
      this.videoUrl = 'http://aboutblank.com'
      if (this.isIE()) {
        const videoPlayer = document.getElementById('ieVideoPlayer')
        videoPlayer.stop()
      }
    },
    // or listen state event
    // playerStateChanged(playerCurrentState) {
    //   if (playerCurrentState.pause) {
    //     this.videoPaused = true
    //   } else {
    //     this.videoPaused = false
    //   }
    // },
    isIE() { // IE11 返回true
      if (!!window.ActiveXObject || 'ActiveXObject' in window) { return true } else { return false }
    },
    playVideo(row) {
      const that = this
      this.loading = true
      getPlayUrl(row.id).then(res => {
        that.loading = false
        if (res.length > 0) {
          that.videoUrl = res
          if (row.type === 0) {
            that.videoTitle = '音频播放'
            that.playVideoDialogVisible = true
          } else if (row.type === 1) {
            that.videoTitle = '视频播放'
            that.playVideoDialogVisible = true
            that.videoPaused = false
          }
          if (that.isIE()) {
            // const videoPlayer = document.getElementById('ieVideoPlayer')
            // console.log(div, videoPlayer)
            // div.removeChild(videoPlayer)
            const embedHtml = `<embed id="ieVideoPlayer" src="${that.videoUrl}" width="600" height="450" autostart="true" loop="false" volume="99">`
            this.embedHtml = embedHtml
          }
        }
      }).catch(_ => {
        that.loading = false
      })
    },
    download(row) {
      const that = this
      this.loading = true
      getPlayUrl(row.id).then(res => {
        that.loading = false
        if (res.length > 0) {
          that.downloadUrl = res
          that.dowloadProgress = 0
          that.downLoadDialogVisibale = true
          that.downloadTitle = 'CCTV-AI_VIDEO-' + row.id
        } else {
          that.downLoadDialogVisibale = false
          that.$message({
            message: '获取下载地址失败',
            type: 'error'
          })
        }
      }).catch(_ => {
        that.loading = false
        that.$message({
          message: '获取下载地址失败',
          type: 'error'
        })
      })
    },
    startDownloadFile() {
      const that = this
      const ext = that.downloadUrl.split('?')[0].split('.').pop()
      const fileName = this.downloadTitle + '.' + ext
      downloadFile(that.downloadUrl, fileName, function(progress) {
        that.dowloadProgress = progress
      }, function(resBack) {
        that.downLoadDialogVisibale = false
        if (resBack === true) {
          that.$message({
            message: '下载完成',
            type: 'success'
          })
        } else {
          this.$message({
            message: '下载失败',
            type: 'error'
          })
        }
      })
    },
    cancleDownloadFile() {
      if (this.dowloadProgress < 100) {
        cancleDownload()
      }
      this.downLoadDialogVisibale = false
    },
    handleClipBoard(event, str) {
      console.log('click')
      str = str.length === 0 ? this.downloadUrl : str
      clipboard(str, event)
    }
  }
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
 /deep/ .vue-treeselect__control {
     height: 31px;

 }
.table_id{
  display: block;
  word-break: keep-all;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
