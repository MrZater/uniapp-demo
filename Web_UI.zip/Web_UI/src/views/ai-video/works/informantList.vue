<template>
  <div id="scrollList">
    <el-table v-if="listData.length > 0" ref="table" :data="listData" style="width:100%" max-height="350px" @row-click="cellClick">
      <el-table-column prop="name" label="姓名" />
      <el-table-column prop="code" label="VCN" />
      <el-table-column prop="languages" label="语言" />
      <el-table-column prop="style" label="风格" />
      <el-table-column prop="info" label="特征" />
    </el-table>
    <div v-else class="noList">您暂无可用的发音人</div>
  </div>
</template>

<script>

export default {
  name: 'InformantList',
  props: {
    listData: {
      type: Array,
      default: function() {
        return []
      }
    }
  },
  data() {
    return {
      lastSelect: -1
    }
  },
  methods: {
    cellClick(row) {
      this.$emit('handleSelectVoicerListen', row)
    },
    setCurrentSelect(index) {
      this.$refs.table.setCurrentRow(index)
    }
  }

}
</script>

<style scoped>
.infinite-list{
  overflow:auto;
  height: 300px;
  width:100%;
  list-style: none;
}
.infinite-list-item{
  float:left;
  width:31%;
  height: 50px;
  margin: 5px;
  border-radius: 1px;
  padding: 10px;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.active{
  background-color: rgba(242,243,247,1);
}
.infinite-list-item .title {
  font-size: 13px;
}

.infinite-list-item .image {
  width: 26px;
  height: 26px
}
.infinite-list-item:hover{
  background-color: rgba(242,243,247,1);
}
.noList{
  width: 100%;
  font-size: 20px;
  text-align: center;
}
</style>
