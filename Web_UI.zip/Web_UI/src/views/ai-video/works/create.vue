<template>
  <div class="app-container">
    <el-form ref="ruleForm" v-loading.fullscreen.lock="loading" classs="works-edit" :model="ruleForm" :rules="rules" label-width="180px" element-loading-text="拼命加载中" element-loading-background="rgba(0, 0, 0, 0.5)">
      <div class="panel-fieldset">
        <h4 class="panel-legend">作品信息</h4>
        <el-form-item label="作品名称" prop="title">
          <el-col :sm="24" :md="18">
            <el-input v-model="ruleForm.title" placeholder="输入作品名称" maxlength="100" show-word-limit clearable />
          </el-col>
        </el-form-item>
        <el-form-item label="发音内容" prop="content">
          <el-col :sm="24" :md="18">
            <div @mouseup="setTryBtnCanBeUse">
              <el-input ref="contentInput" v-model="ruleForm.content" placeholder="输入需要配音的文本" type="textarea" maxlength="5000" show-word-limit :autosize="{ minRows: 6, maxRows: 14}" @blur="textAreaBlur" @input="textAreaValueChange" />
            </div>
            <el-button v-show="!moreLanguages" size="mini" :disabled="isSelectContentText" @click="textSelectSubmitListen">试听选中</el-button>
            <el-dropdown v-show="moreLanguages" placement="bottom-start" size="small" trigger="click" @command="inserValue">
              <el-button size="mini">语种选择</el-button>
              <el-dropdown-menu slot="dropdown">
                <div style="max-height:200px;overflow:scroll">
                  <el-dropdown-item v-for="item in languagesData" :key="item.id" :command="'0,' + item.name">{{ item.name }}</el-dropdown-item>
                </div>
              </el-dropdown-menu>
            </el-dropdown>
            <el-dropdown placement="bottom-start" size="small" trigger="click" @command="inserValue">
              <el-button size="mini">静音</el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="1,1">1s</el-dropdown-item>
                <el-dropdown-item command="1,2">2s</el-dropdown-item>
                <el-dropdown-item command="1,3">3s</el-dropdown-item>
                <el-dropdown-item command="1,5">5s</el-dropdown-item>
                <el-dropdown-item command="1,10">10s</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <el-dropdown placement="bottom-start" size="small" trigger="click" @command="inserValue">
              <el-button size="mini">停顿</el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="2,0">无停顿</el-dropdown-item>
                <el-dropdown-item command="2,1">短停顿</el-dropdown-item>
                <el-dropdown-item command="2,3">长停顿</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <el-popover v-model="pyInputVisible" title="插入注音" placement="top-start" trigger="click" @show="pyInputValue=''">
              <el-input v-model="pyInputValue" placeholder="请输入拼音">
                <el-dropdown slot="append" trigger="click" @command="inserValue">
                  <el-button type="primary">声调<i class="el-icon-arrow-down el-icon--right" /></el-button>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item command="3,1">阴平</el-dropdown-item>
                    <el-dropdown-item command="3,2">阳平</el-dropdown-item>
                    <el-dropdown-item command="3,3">上声</el-dropdown-item>
                    <el-dropdown-item command="3,4">去声</el-dropdown-item>
                    <el-dropdown-item command="3,5">轻声</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </el-input>
              <el-button slot="reference" size="mini">注音</el-button>
            </el-popover>

            <el-popover title="文本标注说明" placement="right" trigger="click">
              <p>静音：在光标位置静音一段时间,格式:[p*](*=无符号整数),单位：毫秒。</p>
              <p>停顿：在光标位置插入停顿,短停顿:[w1]常用于韵律词后面;长停顿[w3]常用于韵律短语后面。</p>
              <p>注音：为光标前面的多音字加注拼音和音调,格式:[=*](*=拼音1~5),如:“着[=zhuo2]手”,“着”字将读作“zhuó”。</p>
              <el-button slot="reference" type="text" icon="el-icon-info" size="mini" circle />
            </el-popover>
          </el-col>
        </el-form-item>
        <el-form-item label="朗读语速">
          <el-col :sm="24" :md="10">
            <el-slider v-model="ruleForm.spd" :min="1" :max="100" @change="contentChanged($event)" />
          </el-col>
        </el-form-item>
        <el-form-item label="朗读音量">
          <el-col :sm="24" :md="10">
            <el-slider v-model="ruleForm.vol" :min="1" :max="100" @change="contentChanged($event)" />
          </el-col>
        </el-form-item>
        <el-tabs v-model="activeName" @tab-click="tabClick">
          <el-tab-pane label="音频选项" name="audio">
            <span slot="label">
              <svg-icon icon-class="audio" /> <strong>音频选项</strong></span>
            <el-form-item
              label="发音人"
              prop="vcn"
              :rules="{
                required: activeName === 'audio', message: '请选择发音人', trigger: ['blur', 'change']
              }"
            >
              <el-card v-if="selectVoicer !== null" style="margin:0; float: left;" :body-style="{ padding: '5px', margin:'0 5px' }" shadow="false">
                <div style="display: flex;align-items: center">
                  <span style="margin-left: 6px">{{ selectVoicer.name + '  ' + selectVoicer.style }}</span>
                </div>
              </el-card>
              <el-popover ref="voicerpopover" style="float:left; margin-left:10px;" placement="right" width="650" height trigger="click" @show="voicerShow">
                <InformantList ref="scrollerRef" :list-data="vListData" @handleSelectVoicerListen="selectVoicerListen" />
                <el-button slot="reference" icon="el-icon-edit-outline" style="height: 50px">选择发音人</el-button>
              </el-popover>
            </el-form-item>
            <el-form-item label="音频格式" prop="audioFormat">
              <el-radio-group v-model="ruleForm.audioFormat">
                <el-radio label="mp3">MP3</el-radio>
                <el-radio label="wav">WAV</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="音频采样率" prop="lwRatio">
              <el-select v-model="ruleForm.rate">
                <el-option
                  v-for="(item, index) in audioRateOptions"
                  :key="index"
                  :value="item"
                  :label="item"
                />
              </el-select>
            </el-form-item>
          </el-tab-pane>
          <el-tab-pane label="视频选项" name="video">
            <span slot="label">
              <svg-icon icon-class="video" /> <strong>视频选项</strong></span>
            <el-form-item
              label="形象选择"
              prop="anchorId"
              :rules="{
                required: activeName === 'video', message: '请选择虚拟形象', trigger: ['blur', 'change']
              }"
            >
              <el-button class="anchorButton" @click="showSelectAnchor">
                <img v-show="selectAnchor !== null" :src="selectAnchor !== null?selectAnchor.thumb:''">
                <div>{{ selectAnchor !== null? selectAnchor.name:'点击选择' }}</div>
              </el-button>
              <!--
              <el-radio-group v-model="ruleForm.anchorId" @change="anchorChanged($event)">
                <el-radio-button v-for="(item, index) in anchorData" :key="index" :label="item.partnerId">
                  <div class="anchor-image"><el-image :src="item.thumb" fit="fit" /></div>
                  <div class="anchor-title">{{ item.name }}</div>
                </el-radio-button>
              </el-radio-group> -->
            </el-form-item>
            <!-- <el-form-item label="主播类型" prop="videoType">
              <el-radio-group v-model="ruleForm.videoType" disabled>
                <el-radio :label="1">真人</el-radio>
                <el-radio :label="0">卡通</el-radio>
              </el-radio-group>
            </el-form-item> -->
            <el-form-item label="视频分辨率" prop="ratio">
              <el-select v-model="ruleForm.ratio" @change="ratioSelect">
                <el-option
                  v-for="(value , index ) in fblOptios"
                  :key="index"
                  :value="value"
                  :label="value"
                />
              </el-select>
            </el-form-item>
            <el-form-item
              label="背景图片"
              prop="bgUrl"
              :rules="{
                required: activeName === 'video', message: '请选择背景图片', trigger: ['blur', 'change']
              }"
            >
              <div style="display: flex;justify-content: start;align-items: center;">
                <img v-show="ruleForm.bgUrl.length > 0" :src="ruleForm.bgUrl" style="width: 100px;height: 62px; border-radius:5px; border: 1px solid #DCDFE6; margin-right: 10px;">
                <el-button icon="el-icon-edit" style="width: 62px;height: 62px; border-radius:5px; border: 1px solid #DCDFE6;font-size:30px" @click="selectBackGroundSourceClick(1)" />
              </div>
            </el-form-item>
            <el-form-item label="虚拟主播位置" prop="location">
              <el-select v-model.number="selectLocation" :disabled="isPortrait">
                <el-option
                  v-for="item in zbPostionOptions"
                  :key="item.value"
                  :value="item
                    .value"
                  :label="item.label"
                />
              </el-select>
              <!-- <span style="color:red">竖屏视频虚拟主播位置需居中</span> -->
            </el-form-item>
            <el-form-item label="视频格式" prop="videoFormat">
              <el-select v-model="ruleForm.videoFormat">
                <el-option
                  v-for="item in formatOptions"
                  :key="item.value"
                  :value="item.value"
                  :label="item.label"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="视频码流" prop="quality">
              <el-radio-group v-model.number="ruleForm.quality">
                <el-radio :label="0">标准码流</el-radio>
                <el-radio v-show="anchorAuthData.highBitrate" :label="1">高码流</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="视频字幕">
              <el-switch v-model="ruleForm.subtitles" />
            </el-form-item>
            <el-form-item label="背景音乐">
              <el-col :sm="24" :md="10">
                <el-input prefix-icon="el-icon-headset" :value="getAudioName(ruleForm.bgAudioUrl)" placeholder="选择背景音乐" readonly>
                  <el-button v-if="getAudioName(ruleForm.bgAudioUrl) !== null" slot="suffix" icon="el-icon-close" circle size="mini" style="margin-top: 8px;margin-right: 10px;" @click="deleteSelectAudio" />
                  <el-button slot="append" icon="el-icon-edit" @click="selectBackGroundSourceClick(2)">选择</el-button>
                </el-input>
              </el-col>
            </el-form-item>
            <el-form-item label="背景音量">
              <el-col :sm="24" :md="10">
                <el-slider v-model="ruleForm.bgAudioVol" :min="1" :max="100" />
              </el-col>
            </el-form-item>
          </el-tab-pane>
        </el-tabs>
        <el-form-item align="center">
          <button-player v-show="fetchedAudio" ref="audioPlayer" the-type="success" the-title="配音试听" the-control-list="showAsButton" @tryPlayEnd="tryPlayEnd" />
          <el-button v-show="(!moreLanguages) && (!fetchedAudio)" type="success" @click="submitListen($event)">
            <svg-icon icon-class="play" /> 全文试听</el-button>
          <el-button v-show="activeName=='audio'" type="primary" @click="submitAudio($event)">
            <svg-icon icon-class="audio" /> 制作音频</el-button>
          <el-button v-show="activeName=='video'" type="primary" @click="submitVideo($event)">
            <svg-icon icon-class="video" /> 制作视频</el-button>
          <el-button @click="saveCaoGao(false)">保存草稿</el-button>
          <el-button @click="$router.back(-1)">取消</el-button>
        </el-form-item>
      </div>
    </el-form>
    <AnchorSelect ref="anchorSelect" @handleAnchorSelect="anchorSelectListen" />
    <source-select ref="sourceSelect" @handleSourceSelect="sourceSelectListen" />
    <el-dialog title="试听" :visible.sync="audioDialogVisible" append-to-body show-close @close="tryListenClosePlay">
      <button-player ref="textareaAudioPlayer" style="width:100%" the-type="success" the-title="配音试听" the-control-list="showAsButton" @tryPlayEnd="tryPlayEnd" />
    </el-dialog>
  </div>
</template>

<script>
import SourceSelect from './sourceSelect'
import InformantList from './informantList'
import ButtonPlayer from '@/components/AudioPlayer'
import AnchorSelect from './anchorSelect'
import { get, listenAudio, addVideo, addAudio } from '@/api/ai-video/works'
import { getCurrentDeptAuth } from '@/api/ai-video/anchorAuth'
import { add, edit, del, getDraft, getDraftWithID } from '@/api/ai-video/draft'
import { getDefaultImg } from '@/api/ai-video/material'
import { visibleLanguages } from '@/api/ai-video/language'

export default {
  name: 'WorksCreate',
  components: {
    SourceSelect,
    ButtonPlayer,
    InformantList,
    AnchorSelect
  },
  data() {
    return {
      //
      isPortrait: false, // 视频分辨率为竖屏
      moreLanguages: false, // 是否是多语种模式
      fromEditOrDraft: false,
      selectLocation: 0, // 主播位置
      anchorAuthData: {}, // 租户配置数据
      audioDialogVisible: false, // 选中试听
      isSelectContentText: true, // 试听按钮是否可以用
      selectString: '', // 试听选中文本
      selectVoicer: null, // 选中voicer
      selectAnchor: null, // 选中anchor
      vListData: [], // voicer列表
      anchorData: [], // 形象列表
      languagesData: [], // 语种列表
      contentParts: [], // 试听文本分组
      lastContent: '', // 记录上一次文本内容
      pyInputValue: '', // 文本拼音输入
      pyInputVisible: false, // 音频输入框
      loading: false,
      fetchedAudio: false,
      worksId: 0, // 作品ID
      playUrl: '', // 语音试听URL
      playUrlLists: {},
      draftID: 0,
      timerID: '',
      ruleForm: {
        title: '',
        content: '',
        type: 1, // 类型 0音频 1视频
        vcn: '', // 发音人
        spd: 50, // 语
        vol: 50, // 朗读音量
        ratio: '', // 视频分辨率 1080 720 480
        audioFormat: 'mp3', // 音频格式 mp3 wav
        rate: '', // 音频采样率
        bgAudioUrl: '', // 背景音乐URL
        bgAudioVol: 100, // 背景音乐音量 0-1 1为原声音  这里要除以100
        videoFormat: 'mp4', // 视频格式 mp4 avi
        quality: 0, // 码流
        videoType: 0, // 视频类型 0真人 1卡通
        subtitles: 0, // 是否有字幕 0 无  1 有
        location: 0, // 形象位置  0 中间 -100 左边， 100 右边
        anchorId: '', // 虚拟形象ID
        bgUrl: '', // 背景URL
        bgType: 0, // 背景类型 0 图片 1 视频,
        format: 'mp4'
      },
      zbPostionOptions: [
        { value: -0.25, label: '居左' },
        { value: 0, label: '居中' },
        { value: 0.25, label: '居右' }
      ],
      fblOptios: [],
      formatOptions: [
        { value: 'mp4', label: 'MP4' },
        { value: 'avi', label: 'AVI(仅供下载，不支持在线预览)' }
      ],
      audioRateOptions: [],
      rules: {
        title: [
          { required: true, message: '请输入作品名称', trigger: 'blur' },
          { min: 3, max: 100, message: '长度在 3 到 100 个字符', trigger: 'blur' }
        ],
        content: [
          { required: true, min: 3, max: 5000, message: '长度在 3 到 5000 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    activeName: {
      get: function() {
        return this.ruleForm.type === 0 ? 'audio' : 'video'
      },
      set: function(val) {
        this.ruleForm.type = (val === 'video') ? 1 : 0
      }
    }
  },
  watch: {
    playUrl: function(val) {
      if (val.length < 2) {
        this.$refs.textareaAudioPlayer.player.src = val
        this.$refs.audioPlayer.player.src = val
        return
      }
      if (this.audioDialogVisible) {
        this.$refs.textareaAudioPlayer.player.src = val
      } else {
        this.$refs.audioPlayer.player.src = val
      }
    }
  },
  mounted() {
    this.worksId = this.$route.query.worksId
    this.draftId = this.$route.query.draftId
    const _that = this
    if (this.draftId > 0) {
      this.fromEditOrDraft = true
      getDraftWithID(this.draftId).then(res => {
        var draftContent = res.content
        draftContent.title = res.title
        this.setFormDefaultValue(draftContent)
        this.initRequest()
      })
    } else if (this.worksId > 0) {
      _that.fromEditOrDraft = true
      get(this.worksId).then(res => {
        _that.setFormDefaultValue(res)
        _that.initRequest()
      })
    } else {
      this.initRequest()
    }
    if (!this.timerID) {
      const _that = this
      this.timerID = setInterval(() => {
        _that.saveCaoGao(true)
      }, 60000)
    }
  },
  destroyed() {
    if (this.timerID) {
      clearInterval(this.timerID)
    }
  },
  methods: {
    /** **
    *  草稿
    */
    delCaoGao() {
      del(this.draftID).then(res => {
      })
    },
    saveCaoGao(autoSaveDraft) {
      if (this.ruleForm.title.length > 0) {
        this.resetVideoFormSomeValue()
        this.ruleForm.format = this.activeName === 'audio' ? this.ruleForm.audioFormat : this.ruleForm.videoFormat
        this.ruleForm.lanType = this.moreLanguages ? 1 : 0
        this.ruleForm.location = String(this.selectLocation)
        const _this = this
        const ruleC = JSON.parse(JSON.stringify(this.ruleForm))
        delete ruleC.title
        const pData = {
          title: this.ruleForm.title,
          content: ruleC
        }
        console.log('保存草稿:', pData)
        if (this.draftID !== 0) {
          edit(this.draftID, pData).then(res => {
            _this.$message({
              message: '草稿箱' + (autoSaveDraft ? '自动保存' : '保存') + '成功',
              type: 'success',
              duration: 2000,
              onClose: function() {
                if (!autoSaveDraft) {
                  _this.$router.push({ path: './draft' })
                }
              }
            })
          })
        } else {
          add(pData).then(res => {
            _this.draftID = res.id
            _this.$message({
              message: '草稿箱' + (autoSaveDraft ? '自动保存' : '保存') + '成功',
              type: 'success',
              duration: 2000,
              onClose: function() {
                if (!autoSaveDraft) {
                  _this.$router.push({ path: './draft' })
                }
              }
            })
          })
        }
      } else {
        if (!autoSaveDraft) {
          this.$confirm('作品名称必须填写', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          })
        }
      }
    },
    /**
     *  初始化
     */
    initRequest() {
      this.getFiguresListData()
      this.getDraftMessage()
      this.getDefaultBgImg()
    },
    getFiguresListData() {
      const that = this
      getCurrentDeptAuth().then(res => {
        console.log('租户配置:', res)
        that.anchorData = res.anchors
        that.vListData = res.voicers
        that.moreLanguages = res.languages ? res.languages.length > 0 : false
        that.anchorAuthData = res
        that.getVisibleLanguages()
        that.getAuthServerConfig()
        if (that.fromEditOrDraft) {
          that.anchorData.forEach((item, index) => {
            if (item.partnerId === that.ruleForm.anchorId) {
              that.selectAnchor = item
            }
          })
          that.vListData.forEach((item, index) => {
            if (item.code === that.ruleForm.vcn) {
              that.selectVoicer = item
              return true
            }
          })
        } else {
          if (that.vListData && that.vListData.length > 0) {
            that.selectVoicer = that.vListData[0]
            that.ruleForm.vcn = that.vListData[0].code
          }
          if (that.anchorData && that.anchorData.length > 0) {
            that.selectAnchor = that.anchorData[0]
            that.ruleForm.anchorId = that.anchorData[0].partnerId
            that.ruleForm.videoType = that.anchorData[0].type
          }
        }
      })
    },
    getDraftMessage() {
      if (this.fromEditOrDraft) return
      const draftData = {
        page: 0,
        size: 20
      }
      getDraft(draftData).then(res => {
        const _this = this
        if (res.content.length > 0) {
          _this.$confirm('您有未完成的作品，是否继续编辑', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(resConfir => {
            const draftContent = res.content.pop()
            console.log('创建_获取草稿箱:', draftContent, res)
            this.draftID = draftContent.id
            draftContent.content.title = draftContent.title
            this.setFormDefaultValue(draftContent.content)
          })
        }
      }).catch(error => {
        console.log('draft_error:', error)
      })
    },
    getDefaultBgImg() {
      if (this.fromEditOrDraft) return
      getDefaultImg().then(res => {
        // 兼容
        if (res && res.hasOwnProperty('url')) {
          this.ruleForm.bgUrl = res.url
        }
      }).catch(() => {
      })
    },
    getVisibleLanguages() {
      if (this.moreLanguages) {
        visibleLanguages().then(res => {
          this.languagesData = res
        }).catch(err => {
          console.log(err)
        })
      }
    },
    setFormDefaultValue(res) {
      console.log('setDefault-message:', res)
      this.ruleForm.title = res.title // 作品名称
      this.ruleForm.content = res.content // 内容
      this.lastContent = res.content
      this.ruleForm.type = res.type // 类型
      this.ruleForm.spd = res.spd // 语速
      this.ruleForm.vol = res.vol // 朗读音量
      this.ruleForm.vcn = res.vcn === '' ? 'xiaopei' : res.vcn // 发音人
      if (res.type === 0) { // 音频
        this.ruleForm.audioFormat = res.format // 音频格式 mp3
        this.ruleForm.rate = res.rate
      } else if (res.type === 1) { // 视频
        this.ruleForm.videoFormat = res.format // 背景音乐URL
        this.ruleForm.videoType = res.videoType // 视频类型
        this.ruleForm.bgAudioUrl = res.bgAudioUrl // 视频格式 mp4 avi
        this.ruleForm.bgAudioVol = res.bgAudioVol // 背景音乐音量 0-100 100为原声音
        this.ruleForm.subtitles = !!res.subtitles // 视频格式 mp4 avi
        this.ruleForm.location = res.location // 形象位置  0 中间 -100 左边， 100 右边
        this.ruleForm.bgUrl = res.bgUrl // 背景URL
        this.ruleForm.bgType = res.bgType // 背景URL
        this.ruleForm.anchorId = res.anchorId // 形象ID
        this.ruleForm.quality = parseInt(res.quality)
        this.ruleForm.ratio = res.width + ' * ' + res.height
        const location = parseFloat(res.location)
        this.selectLocation = location < 0 ? -0.25 : location === 0 ? 0 : 0.25
      }
    },
    getAuthServerConfig() {
      var videoRatios = this.anchorAuthData.videoRatios ? this.anchorAuthData.videoRatios.split(',') : []
      this.fblOptios = videoRatios

      if (this.ruleForm.ratio.length < 1) {
        this.ruleForm.ratio = videoRatios[0]
      } else {
        this.fblOptios.forEach(item => {
          if (item.indexOf(this.ruleForm.ratio) > -1) {
            this.ruleForm.ratio = item
          }
        })
      }
      this.ratioSelect(this.ruleForm.ratio)

      const audioRates = this.anchorAuthData.audioRates ? this.anchorAuthData.audioRates.split(',') : []
      audioRates.sort()
      this.audioRateOptions = audioRates
      if (this.ruleForm.rate.length < 1) {
        this.ruleForm.rate = audioRates[0]
      }
    },
    textAreaBlur() {
      const _this = this
      setTimeout(() => {
        _this.isSelectContentText = true
      }, 200)
    },
    // 试听按钮是否可用
    setTryBtnCanBeUse(val) {
      const _this = this
      setTimeout(function() {
        _this.selectString = window.getSelection().toString()

        // if (_this.isIE()) {
        //   _this.selectString = document.selection.createRange().text
        // } else {
        //   _this.selectString = window.getSelection().toString()
        // }
        _this.isSelectContentText = _this.selectString.length === 0
      }, 50)
    },
    textAreaValueChange(value) {
      if (value.length < this.lastContent.length) {
        // 文字有删除
        this.isSelectContentText = true
        const textarea = this.$refs.contentInput.$refs.textarea
        const inputLocation = textarea.selectionStart
        const deleteLength = this.lastContent.length - value.length
        const deleteContent = this.lastContent.substring(inputLocation, inputLocation + deleteLength)
        if (deleteContent.indexOf(']') !== -1 || deleteContent.indexOf('】') !== -1) {
          var preString = this.lastContent.substring(0, inputLocation)
          if (preString.indexOf('[') !== -1 || preString.indexOf('【') !== -1) {
            var last = preString.lastIndexOf('[')
            last = last == null ? preString.lastIndexOf('【') : last
            preString = preString.substring(0, last)
            const lastString = this.lastContent.substring(inputLocation + deleteLength, this.lastContent.length)
            value = preString + lastString
            this.ruleForm.content = value
            const that = this
            const insertLocation = value.length - lastString.length
            if (textarea.setSelectionRange) {
              setTimeout(function() {
                textarea.setSelectionRange(insertLocation, insertLocation)
                textarea.focus()
                that.lastContent = value
              }, 0)
            } else if (textarea.createTextRange) {
              // 兼容IE
              const rng = textarea.createTextRange()
              rng.move('character', insertLocation)
              rng.select()
            }
          }
        } else {
          this.lastContent = value
          this.ruleForm.content = value
        }
      } else {
        this.lastContent = value
        this.ruleForm.content = value
      }
    },
    inserValue(ops) {
      const type = parseInt(ops.split(',')[0])
      const value = ops.split(',')[1]
      const textarea = this.$refs.contentInput.$refs.textarea
      const inputLocation = textarea.selectionStart
      var insertValue = ''
      if (type === 0) {
        insertValue = '【' + value + '】'
      } else if (type === 1) {
        insertValue = '[p' + value + '000]'
      } else if (type === 2) {
        insertValue = '[w' + value + ']'
      } else if (type === 3) {
        if (this.pyInputValue != null && this.pyInputValue.length < 1) {
          return
        }
        this.pyInputVisible = false
        insertValue = '[=' + this.pyInputValue + value + ']'
      }
      const newValue = textarea.value.slice(0, inputLocation) + insertValue + textarea.value.slice(inputLocation)
      this.ruleForm.content = newValue
      this.lastContent = newValue
      const insertLocation = inputLocation + insertValue.length
      if (textarea.setSelectionRange) {
        setTimeout(function() {
          textarea.setSelectionRange(insertLocation, insertLocation)
          textarea.focus()
        }, 0)
      } else if (textarea.createTextRange) {
        // 兼容IE
        const rng = textarea.createTextRange()
        rng.move('character', insertLocation)
        rng.select()
      }
    },

    /** **
     *   其他
     */
    tabClick(component) {
      this.activeName = component.name
    },
    contentChanged(event) {
      this.fetchedAudio = false
      this.playUrl = ''
    },
    ratioSelect(selectRatio) {
      const width = parseInt(selectRatio.split('(')[0].split('*')[0].replace(/(^\s*)|(\s*$)/g, ''))
      const height = parseInt(selectRatio.split('(')[0].split('*')[1].replace(/(^\s*)|(\s*$)/g, ''))
      this.isPortrait = width < height
      if (this.isPortrait) {
        this.selectLocation = 0
      }
    },
    voicerShow() {
      if (this.vListData.length === 0) {
        this.$refs.voicerpopover.showPopper = false
        this.$confirm('您暂无可用的发言人', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
        }).catch(() => {
        })
      }
    },
    // 检测是否插入多语种标签

    /** **
     *  形象选择
     */
    showSelectAnchor() {
      if (this.anchorData.length === 0) {
        this.$refs.voicerpopover.showPopper = false
        this.$confirm('您暂无可用的虚拟形象', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
        }).catch(() => {
        })
        return
      }
      this.$refs.anchorSelect.anchorDatas = this.anchorData
      this.$refs.anchorSelect.dialog = true
    },
    anchorSelectListen(selectAnchor) {
      console.log('形象选择:', selectAnchor)
      this.selectAnchor = selectAnchor
      this.ruleForm.videoType = selectAnchor.type
      this.ruleForm.anchorId = selectAnchor.partnerId
      this.$refs.anchorSelect.dialog = false
    },

    /** **
     *
     *  表单
     */
    resetForm() {
      this.$refs['ruleForm'].resetFields()
    },

    /** *
     *    背景图和背景音乐
     */
    selectBackGroundSourceClick(index) {
      this.$refs.sourceSelect.dialogPicSelectVisible = true
      this.$refs.sourceSelect.sourceType = index
      const ratios = this.ruleForm.ratio.split('(')[0].split('*')
      this.$refs.sourceSelect.videoRatio = index === 1 ? ratios[0] + 'x' + ratios[1] : ''
    },
    sourceSelectListen(data, sourceType) {
      const url = data.url
      const name = data.name
      this.setSourceUrl(sourceType, url, name)
      this.$refs.sourceSelect.dialogPicSelectVisible = false
      // if (sourceType === 1) {
      //   const picWidth = parseInt(data.ratio.split('x')[0])
      //   const picHeght = parseInt(data.ratio.split('x')[1])
      //   const videoRatios = this.ruleForm.ratio.split('(')[0]
      //   console.log('picWidth:', this.ruleForm.ratio, videoRatios)
      //   const videoRatioWidth = parseInt(videoRatios.split('*')[0])
      //   const videoRatioHeight = parseInt(videoRatios.split('*')[1])
      //   const isWidth = picWidth > videoRatioWidth - 30 && picWidth < videoRatioWidth + 30
      //   const isHeight = picHeght > videoRatioHeight - 30 && picHeght < videoRatioHeight + 30
      //   if (isWidth && isHeight) {
      //     this.setSourceUrl(sourceType, url, name)
      //     this.$refs.sourceSelect.dialogPicSelectVisible = false
      //   } else {
      //     this.$confirm('所选图片分辨率与视频分辨率不一致，会影响视频质量，确定使用吗？', '提示', {
      //       confirmButtonText: '确定',
      //       cancelButtonText: '取消',
      //       type: 'warning'
      //     }).then(() => {
      //       this.setSourceUrl(sourceType, url, name)
      //       this.$refs.sourceSelect.dialogPicSelectVisible = false
      //     })
      //   }
      // } else {
      //   this.setSourceUrl(sourceType, url, name)
      //   this.$refs.sourceSelect.dialogPicSelectVisible = false
      // }
    },
    setSourceUrl(sourceType, url, name) {
      if (sourceType === 1) {
        this.ruleForm.bgUrl = url + '?name=' + name
      } else {
        if (url.indexOf('?') !== -1) {
          this.ruleForm.bgAudioUrl = url + '&name=' + name
        } else {
          this.ruleForm.bgAudioUrl = url + '?name=' + name
        }
      }
    },
    selectVoicerListen(voicerJson) {
      this.selectVoicer = voicerJson
      this.ruleForm.vcn = this.selectVoicer.code
      this.$refs.voicerpopover.showPopper = false
    },
    getAudioName(bgUrl) {
      if (bgUrl && bgUrl.length > 0) {
        // 这个为了兼容之前已上传没有name的素材
        if (bgUrl.indexOf('?') === -1) {
          return null
        }
        const params = bgUrl.split('?')[1].split('&')
        var name = ''
        for (const val of params) {
          if (val.indexOf('name=') !== -1) {
            name = val.split('=')[1]
            break
          }
        }
        return name + '.' + bgUrl.split('?')[0].split('.').pop()
      } else {
        return null
      }
    },
    deleteSelectAudio() {
      this.ruleForm.bgAudioUrl = ''
    },
    /** ***
    *   试听
    */
    devideTextIntoGroups(text) {
      const count = 199
      if (text.length <= count) {
        this.contentParts.push(text)
      } else {
        const marks = ['，', '。', '！', '？', ',', '.', '?', '!']
        var lastMaskIndex = 0
        var markBool = false
        for (var i = 0; i <= count; i++) {
          const str = text.charAt(i)
          if (marks.indexOf(str) > -1) {
            lastMaskIndex = i
            markBool = true
          }
        }
        lastMaskIndex = markBool ? lastMaskIndex : count
        const saveText = text.substring(0, lastMaskIndex + 1)
        const nextText = text.substring(lastMaskIndex + 1, text.length)
        // console.log('saveText:', saveText, 'nextText:', nextText)
        this.contentParts.push(saveText)
        this.devideTextIntoGroups(nextText)
      }
    },
    tryPlayEnd() {
      const currentIndex = Object.values(this.playUrlLists).indexOf(this.playUrl)
      const nextPlayUrl = this.playUrlLists[currentIndex + 1]
      if (nextPlayUrl !== null && nextPlayUrl !== undefined) {
        this.playUrl = nextPlayUrl
      } else {
        this.fetchedAudio = false
      }
    },
    tryListenClosePlay() {
      this.playUrl = ''
      this.playUrlLists = []
      this.audioDialogVisible = false
      // if (this.isIE()) {
      //   document.selection.empty()
      // }
    },
    resetAudioPlayerParams() {
      this.playUrl = ''
      this.playUrlLists = []
      this.contentParts = []
    },
    textSelectSubmitListen() { // 选取语音试听
      this.resetAudioPlayerParams()
      this.devideTextIntoGroups(this.selectString)
      const that = this
      this.ruleForm.vcn = 'xiaopei'
      this.audioDialogVisible = true
      this.contentParts.some(function(item, index) {
        const formContent = {
          content: item,
          format: that.ruleForm.format,
          spd: that.ruleForm.spd,
          title: that.ruleForm.title,
          vcn: that.ruleForm.vcn,
          vol: that.ruleForm.vol,
          index: index,
          lanType: 0
          // rate: that.ruleForm.rate
        }
        console.log('formContent:', formContent)
        listenAudio(formContent).then(res => {
          const listIndex = formContent.index
          if (listIndex === 0) {
            that.playUrl = res
          }
          that.playUrlLists[index] = res
        }).catch(err => {
          console.log(err)
          this.audioDialogVisible = false
        })
      })
    },
    submitListen(event) { // 语音试听
      if (this.ruleForm.content.length <= 0) {
        this.$message({
          message: '发音内容不能为空',
          type: 'error'
        })
        return
      }
      this.contentParts = []
      this.devideTextIntoGroups(this.ruleForm.content)
      this.loading = true
      const that = this
      this.ruleForm.vcn = this.activeName === 'audio' ? this.ruleForm.vcn : 'xiaopei'
      this.contentParts.some(function(item, index) {
        const formContent = {
          content: item,
          format: that.ruleForm.format,
          spd: that.ruleForm.spd,
          title: that.ruleForm.title,
          vcn: that.ruleForm.vcn,
          vol: that.ruleForm.vol,
          index: index,
          lanType: 0
          // rate: that.ruleForm.rate
        }
        listenAudio(formContent).then(res => {
          const listIndex = formContent.index
          if (listIndex === 0) {
            that.fetchedAudio = true
            that.playUrl = res
            that.loading = false
          }
          that.playUrlLists[index] = res
        }).catch(err => {
          that.loading = false
          that.fetchedAudio = false
          console.log(err)
        })
      })
    },
    checkInsertLanguageFlagOk() {
      if (this.moreLanguages) {
        var isOk = false
        this.languagesData.some(element => {
          const language_flag = '【' + element.name + '】'
          if (this.ruleForm.content.indexOf(language_flag) > -1) {
            isOk = true
            return
          }
        })
        if (!isOk) {
          this.ruleForm.content = '【普通话】' + this.ruleForm.content
        }
      }
    },
    /** ***
     *
     *  创建音视频
     */
    submitAudio(event) { // 创建音频
      this.playUrl = ''
      this.$refs['ruleForm'].validate((valid) => {
        if (valid) {
          this.loading = true
          this.ruleForm.lanType = this.moreLanguages ? 1 : 0
          this.checkInsertLanguageFlagOk()
          addAudio(this.ruleForm).then(res => {
            const that = this
            this.delCaoGao()
            this.$message({
              showClose: true,
              message: '创建成功',
              type: 'success',
              duration: 2000,
              onClose: function() {
                that.$router.push({ path: './works' })
              }
            })
            this.loading = false
          }).catch(err => {
            this.loading = false
            console.log(err)
          })
        }
      })
    },

    resetVideoFormSomeValue() {
      if (this.ruleForm.ratio !== undefined) {
        const width = this.ruleForm.ratio.split('(')[0].split('*')[0].replace(/(^\s*)|(\s*$)/g, '')
        const height = this.ruleForm.ratio.split('(')[0].split('*')[1].replace(/(^\s*)|(\s*$)/g, '')
        this.ruleForm.width = width
        this.ruleForm.height = height
        this.ruleForm.location = String(width * this.selectLocation)
      }
    },
    submitVideo(event) { // 创建视频
      this.$refs['ruleForm'].validate((valid) => {
        if (valid) {
          delete this.ruleForm.id
          this.ruleForm.format = this.ruleForm.videoFormat
          this.ruleForm.vcn = 'xiaopei'
          this.ruleForm.lanType = this.moreLanguages ? 1 : 0
          this.ruleForm.bgAudioUrl = encodeURI(this.ruleForm.bgAudioUrl)
          this.checkInsertLanguageFlagOk()
          if (this.ruleForm.bgUrl.length === 0) {
            this.ruleForm.bgUrl = 'http://hudong-media.oss-cn-beijing.aliyuncs.com/ai-video/default-bg.png'
          }
          this.resetVideoFormSomeValue()
          console.log('form:', this.ruleForm)
          this.loading = true
          addVideo(this.ruleForm).then(res => {
            this.delCaoGao()
            const that = this
            this.$message({
              message: '创建成功',
              type: 'success',
              onClose: function() {
                that.$router.push({ path: './works' })
              }
            })
            this.loading = false
          }).catch(err => {
            this.loading = false
            console.log(err)
          })
        }
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@media screen and (min-width: 1024px) {
  .anchor-title {
    line-height: 30px;
    font-weight: 500;
    padding: 0 5px;
    max-width: 120px;
    overflow: hidden;
  }

  /deep/ .el-tabs__header {
    margin: 0 60px 30px;
  }
}

/deep/ .el-card {
  border: 1px solid #DCDFE6;
  -webkit-box-shadow: 0 0px 3px 0 rgba(0,0,0,0.12);
  box-shadow: 0 0px 3px 0 rgba(0,0,0,0.12);
  margin: 0;
}

/deep/ .el-radio-button__orig-radio:checked + .el-radio-button__inner {
  -webkit-box-shadow: none;
  box-shadow: none;
}

/deep/ .el-radio-button__inner {
  padding: 0;
  margin-right: 10px;
  border-radius: 5px !important;
  border: 1px solid #dcdfe6 !important;
  margin-bottom: 20px;

  .el-image {
    border-radius: 3px !important;
    width: 90px;
    height: 90px;
  }
}
.el-button--mini {
  padding: 5px;
}
/deep/ .el-input--suffix .el-input__inner {
  padding-right: 30px;
}
.el-select{
  width: 260px;
}
.anchorButton{
   width: 122px;
   height: 170px;
   padding: 0px;
   border-radius: 5px;
   img{
     width: 120px;
     height: 140px;
   }
   div{
     margin-top: 5px;
     overflow: hidden;
     text-overflow: ellipsis;
     word-break: keep-all;
     white-space: nowrap;
   }
}
</style>
