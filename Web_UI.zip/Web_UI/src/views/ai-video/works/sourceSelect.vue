<template>
  <div id="app">
    <el-dialog :visible.sync="dialogPicSelectVisible" append-to-body width="620px" @close="closePlay" @closed="dialogClosed">
      <div slot="title" class="head-container" style="padding:0;margin:0">
        <!-- 搜索 -->
        <el-input v-model="query.name" clearable placeholder="" class="filter-item" style="width: 200px;" />
        <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="rToQuery">搜索</el-button>
        <!-- 新增 -->
        <div v-permission="['admin','works:add']" style="display: inline-block;margin: 0px 2px;">
          <el-button
            class="filter-item"
            size="mini"
            type="primary"
            icon="el-icon-plus"
            @click="add"
          >添加素材</el-button>
        </div>
      </div>
      <div v-show="videoRatio.length > 0" class="videoRatioTip">建议与视频分辨率 {{ videoRatio }} 保持一致</div>
      <el-row :gutter="20">
        <el-col v-for="(item, i) in data" :key="i" :span="12" class="colLineGutter" @click.native="(cardClick(i))">
          <el-row justify="start" :gutter="20">
            <el-col v-if="sourceType===1" :span="10">
              <el-popover :title="item.name" placement="top" width="320" trigger="hover">
                <div class="popovermage" :style="backgroundDiv(item.url)" />
                <div slot="reference" class="dialogimage" :style="backgroundDiv(item.url)" />
              </el-popover>
              <div class="ratio">{{ item.ratio }}</div>
            </el-col>
            <el-col v-else :span="10">
              <div class="dialogimage">
                <el-button ref="playButton" data-playing="false" @click.stop="playAudio($event, i )">
                  <i ref="playButtonIcon" class="el-icon-video-play" />
                </el-button>
              </div>
            </el-col>
            <el-col :span="14" class="titleCol">
              <div class="titleCenter">{{ item.name }}</div>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
      <div>
        <audio v-show="false" ref="audioPlayer" loop="loop" />
      </div>
    </el-dialog>
  </div>
</template>
]
<script>
import initData from '@/mixins/initData'
export default {
  name: 'SourceSelect',
  mixins: [initData],
  data() {
    return {
      audioPlayer: null,
      lastPlayButton: null,
      sourceType: 1,
      dialogPicSelectVisible: false,
      dialogTitle: '',
      videoRatio: ''
    }
  },
  watch: {
    dialogPicSelectVisible: function(val) {
      if (val === true) {
        this.$nextTick(() => {
          this.init()
        })
      }
    }
  },
  methods: {
    beforeInit() {
      this.size = 9999
      const type = (this.sourceType === 1) ? 'image' : 'audio'
      this.url = 'api/material'
      this.params = { page: this.page, size: this.size, type: type, status: 1 }
      const query = this.query
      const name = query.name
      if (name) { this.params['name'] = name }
      return true
    },
    rToQuery() {
      if (this.sourceType !== 1) {
        this.closePlay()
      }
      this.page = 0
      this.init()
    },
    backgroundDiv(url) {
      return 'background-image:url(' + url + ')'
    },
    add() {
      this.$router.push({ path: './material' })
    },
    cardClick(index) {
      if (this.sourceType === 1) {
        this.$emit('handleSourceSelect', this.data[index], this.sourceType)
      } else {
        this.dialogPicSelectVisible = false
        if (this.lastPlayButton) {
          this.pausePlay(this.lastPlayButton, this.lastPlayButton.$el.lastChild.firstChild)
        }
        this.$refs.audioPlayer.src = ''
        this.$emit('handleSourceSelect', this.data[index], this.sourceType, name)
      }
    },
    playAudio(event, i) {
      const currentPlayBtn = this.$refs.playButton[i]
      const currentPlayBtnIcon = this.$refs.playButtonIcon[i]
      if (this.lastPlayButton !== currentPlayBtn) {
        if (this.lastPlayButton !== null) {
          this.pausePlay(this.lastPlayButton, this.lastPlayButton.$el.lastChild.firstChild)
        }
        this.lastPlayButton = currentPlayBtn
        const playSrc = this.data[i].url
        this.startPlay(playSrc, currentPlayBtn, currentPlayBtnIcon)
      } else {
        const isPlaying = currentPlayBtn.$attrs['data-playing']
        if (isPlaying === 'false') {
          this.startPlay('', currentPlayBtn, currentPlayBtnIcon)
        } else {
          this.pausePlay(currentPlayBtn, currentPlayBtnIcon)
        }
      }
    },
    pausePlay(currentPlayBtn, currentPlayBtnIcon) {
      currentPlayBtnIcon.setAttribute('class', 'el-icon-video-play')
      currentPlayBtn.$attrs['data-playing'] = 'false'
      this.$refs.audioPlayer.pause()
    },
    startPlay(src, currentPlayBtn, currentPlayBtnIcon) {
      if (src && src.length > 0) {
        this.$refs.audioPlayer.src = src
      }
      currentPlayBtnIcon.setAttribute('class', 'el-icon-video-pause')
      currentPlayBtn.$attrs['data-playing'] = 'true'
      this.$refs.audioPlayer.play()
    },
    closePlay() {
      if (this.source !== 1 && this.lastPlayButton) {
        this.pausePlay(this.lastPlayButton, this.lastPlayButton.$el.lastChild.firstChild)
        this.$refs.audioPlayer.src = ''
        this.lastPlayButton = null
      }
    },
    dialogClosed() {
      this.data = []
      this.audioPlayer = null
      this.lastPlayButton = null
      this.sourceType = 1
      this.dialogTitle = ''
      this.query.name = ''
    }
  }
}
</script>

<style lang="scss" scoped>
/deep/ .el-card {
  margin: 10px 0;
}
/deep/ .el-card__body {
  padding: 15px;
}
/deep/ .el-dialog__body {
    padding: 20px;
    padding-top: 0px;
    margin-top: -10px;
}
.videoRatioTip{
   color: red;
   text-align: center;
   padding: 10px;
}
.time {
  font-size: 13px;
  color: #999;
}

.bottom {
  margin-top: 8px;
  line-height: 10px;
}
.dialogimage {
  width: 100%;
  height: 70px;
  display: block;
  border: #eee 1px solid;
  border-radius: 4px;
  align-content: center;
  text-align: center;
  background-repeat: no-repeat;
  background-size: cover;

  button {
    font-size: 32px;
    border: none;
    padding: 0;
    margin-top: 17px;
  }
}
.popovermage {
  width: 100%;
  height: 180px;
  border: #eee 1px solid;
  border-radius: 4px;
  background-repeat: no-repeat;
  background-size: cover;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}
.limitLineTitle {
  padding-top: 6px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
.colLineGutter{
   margin-top: 20px;
}
.titleCenter{
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
  overflow: hidden;
}
.ratio{
    text-align: center;
}
</style>
