<template>
  <div id="app">
    <el-dialog :visible.sync="dialog" append-to-body width="600px" title="选择形象">
      <el-row v-if="anchorDatas.length > 0" :gutter="20">
        <el-col v-for="(item,index) in anchorDatas" :key="index" :span="6">
          <div class="cantianer" @click="cardClick(item)">
            <img :src="item.thumb">
            <div class="anchorname">{{ item.name }}</div>
          </div>
        </el-col>
      </el-row>
      <div v-else class="noList">您暂无可用的虚拟形象</div>
    </el-dialog>
  </div>
</template>
]
<script>
export default {
  name: 'AnchorSelect',
  data() {
    return {
      dialog: false,
      anchorDatas: []
    }
  },

  methods: {
    cardClick(selectAnchor) {
      this.$emit('handleAnchorSelect', selectAnchor)
    }
  }
}
</script>

<style lang="scss" scoped>
.el-row{
  .el-col{
     .cantianer{
       border-radius: 5px;
       height:170px;
       width: 100%;
       margin-bottom: 20px;
       border: 1px solid lightgray;
       &:hover{
         color: #11A983;
         box-shadow:0px 0px 8px 3px rgba($color: #000000, $alpha: 0.2)
        }
        img{
           width: 100%;
           height: 140px;
        }
        .anchorname{
          text-align: center;
        }
     }
  }
}
/deep/ .el-dialog__body{
   max-height: 500px;
   overflow: scroll !important
}
.noList{
  width: 100%;
  font-size: 20px;
  text-align: center;
}
</style>
