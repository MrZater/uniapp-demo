<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-select v-model="query.character" clearable placeholder="年龄段" class="filter-item" style="width: 120px" @change="toQuery">
        <el-option
          v-for="item in dictMap['voicer_character']"
          :key="item.id"
          :label="item.label"
          :value="item.label"
        />
      </el-select>
      <el-select v-model="query.speaker" clearable placeholder="分类" class="filter-item" style="width: 100px" @change="toQuery">
        <el-option
          v-for="item in dictMap['voicer_speaker']"
          :key="item.id"
          :label="item.label"
          :value="item.label"
          :disabled="item.status===0"
        />
      </el-select>
      <el-select v-model="query.modal" clearable placeholder="应用类型" class="filter-item" style="width: 110px" @change="toQuery">
        <el-option
          v-for="item in dictMap['voicer_type']"
          :key="item.id"
          :label="item.label"
          :value="item.value"
          :disabled="item.status===0"
        />
      </el-select>
      <el-select v-model="query.sence" clearable placeholder="应用场景" class="filter-item" style="width: 110px" @change="toQuery">
        <el-option
          v-for="item in dictMap['voicer_sence']"
          :key="item.id"
          :label="item.label"
          :value="item.value"
          :disabled="item.status===0"
        />
      </el-select>
      <el-select v-model="query.status" clearable placeholder="状态" class="filter-item" style="width: 80px" @change="toQuery">
        <el-option v-for="item in statusOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-select v-model="query.type" clearable placeholder="" class="filter-item" style="width: 80px">
        <el-option v-for="item in queryTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-input v-model="query.value" clearable placeholder="输入搜索内容" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <div style="display: inline-block;margin: 0px 2px;">
        <el-button
          v-permission="['admin','voicer:config']"
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-plus"
          @click="showAddDialog"
        >新增</el-button>
      </div>
    </div>
    <!--表单组件-->
    <eForm ref="form" :is-add="isAdd" :dict-map="dictMap" />

    <!--表格渲染-->
    <el-table v-loading="loading" :data="data">
      <el-table-column prop="id" label="ID" align="center" width="80" />
      <el-table-column prop="name" label="名称" />
      <el-table-column prop="alias" label="别名" />
      <el-table-column prop="code" label="VCN代码" />
      <el-table-column prop="languages" label="语言" />
      <el-table-column prop="character" label="年龄段" />
      <el-table-column prop="speaker" label="分类" />
      <el-table-column prop="type" label="应用类型" />
      <el-table-column prop="sence" label="应用场景" />
      <el-table-column prop="style" label="风格" />
      <el-table-column prop="info" label="风格标签" />
      <el-table-column label="状态" align="center">
        <template slot-scope="scope">
          <div v-for="item in statusOptions" :key="item.key">
            <el-tag v-if="scope.row.status === item.key" size="small" :type="scope.row.status === 1 ? '' : 'info'">{{ item.display_name }}</el-tag>          </div>
        </template>
      </el-table-column>
      <el-table-column v-if="checkPermission(['admin','voicer:config'])" label="操作" width="150px" align="center">
        <template slot-scope="scope">
          <el-button v-permission="['admin','voicer:config']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
          <el-button v-permission="['admin','anchor:config']" size="mini" type="warning" @click="toggleStatus(scope.row.id, scope.row.status)"><svg-icon :icon-class="scope.row.status === 1 ? 'disable' : 'enable'" /></el-button>
          <el-button v-permission="['admin','voicer:config']" :loading="delLoading" size="mini" type="danger" icon="el-icon-delete" @click="deleteOne(scope.row.id)" />
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      :current-page="page + 1"
      :page-size="size"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"
    />
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import initDict from '@/mixins/initDict'
import { del, toggle } from '@/api/ai-video/voicer'
import eForm from './form'
export default {
  components: { eForm },
  mixins: [initData, initDict],
  data() {
    return {
      title: '发音人',
      crudMethod: { del, toggle },
      queryTypeOptions: [
        { key: 'id', display_name: 'ID' },
        { key: 'name', display_name: '名称' },
        { key: 'alias', display_name: '别名' },
        { key: 'code', display_name: 'VCN代码' }
      ]
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()

      // 加载数据字典
      this.getDictMap('voicer_speaker,voicer_type,voicer_sence,voicer_character')
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/voicer'
      this.params = { page: this.page, size: this.size }
      const query = this.query
      const type = query.type
      const value = query.value
      const speaker = query.speaker
      const sence = query.sence
      const character = query.character
      const modal = query.modal
      const status = query.status
      if (type && value) { this.params[type] = value }
      if (speaker) { this.params['speaker'] = speaker }
      if (sence) { this.params['sence'] = sence }
      if (character) { this.params['character'] = character }
      if (modal) { this.params['type'] = modal }
      if (status !== '' && status !== null) { this.params['status'] = status }
      return true
    },
    beforeShowEditDialog(data) {
      this.dialogForm.sences = data.sence ? data.sence.split('、') : []
      return data
    }
  }
}
</script>

<style scoped>

</style>
