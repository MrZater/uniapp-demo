<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" :title="isAdd ? '新增' : '编辑'" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="100px">
      <el-form-item label="名称" prop="name">
        <el-input v-model="form.name" />
      </el-form-item>
      <el-form-item label="别名" prop="alias">
        <el-input v-model="form.alias" />
      </el-form-item>
      <el-form-item label="VCN代码" prop="alias">
        <el-input v-model="form.code" />
      </el-form-item>
      <el-form-item label="分类" prop="speaker">
        <el-select v-model="form.speaker" placeholder="请选择">
          <el-option
            v-for="item in dictMap['voicer_speaker']"
            :key="item.id"
            :label="item.label"
            :value="item.value"
            :disabled="item.status===0"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="年龄段" prop="character">
        <el-select v-model="form.character" placeholder="请选择">
          <el-option
            v-for="item in dictMap['voicer_character']"
            :key="item.id"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="应用类型" prop="type">
        <el-select v-model="form.type" placeholder="请选择">
          <el-option
            v-for="item in dictMap['voicer_type']"
            :key="item.id"
            :label="item.label"
            :value="item.value"
            :disabled="item.status===0"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="应用场景" prop="sences">
        <el-select v-model="sences" multiple placeholder="请选择">
          <el-option
            v-for="item in dictMap['voicer_sence']"
            :key="item.id"
            :label="item.label"
            :value="item.value"
            :disabled="item.status===0"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="擅长领域">
        <el-input v-model="form.domain" />
      </el-form-item>
      <el-form-item label="风格">
        <el-input v-model="form.style" />
      </el-form-item>
      <el-form-item label="风格标签">
        <el-input v-model="form.info" />
      </el-form-item>
      <el-form-item label="示例文本">
        <el-input
          v-model="form.text"
          type="textarea"
          placeholder="请输入内容"
          maxlength="250"
          show-word-limit
          :autosize="{ minRows: 3, maxRows: 6}"
        />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="text" size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="submitForm">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/ai-video/voicer'
export default {
  mixins: [initForm],
  props: {
    dictMap: {
      type: Object,
      required: true
    }
  },
  data() {
    const validSences = (rule, value, callback) => {
      if (this.sences.length > 0) {
        callback()
      } else {
        callback(new Error('应用场景不能为空'))
      }
    }
    return {
      title: '发音人',
      crudMethod: { add, edit },
      sences: [],
      form: {
        id: '',
        name: '',
        alias: '',
        code: '',
        icon: '',
        languages: '',
        character: '',
        speaker: '',
        sence: '',
        type: '',
        domain: '',
        gender: '',
        style: '',
        info: '',
        text: '',
        status: 1
      },
      rules: {
        name: [
          { required: true, message: '名称不能为空', trigger: 'blur' }
        ],
        alias: [
          { required: true, message: '别名不能为空', trigger: 'blur' }
        ],
        code: [
          { required: true, message: 'VCN码不能为空', trigger: 'blur' }
        ],
        speaker: [
          { required: true, message: '发音人分类不能为空', trigger: 'blur' }
        ],
        character: [
          { required: true, message: '发音人年龄段不能为空', trigger: 'blur' }
        ],
        type: [
          { required: true, message: '应用类型不能为空', trigger: 'blur' }
        ],
        sences: [
          { required: true, validator: validSences, trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    beforeSubmitForm() {
      this.form.sence = this.sences.join('、')
      return true
    }
  }
}
</script>

<style scoped>

</style>
