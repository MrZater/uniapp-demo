<template>
  <div style="display: inline-block;">
    <el-dialog :visible.sync="dialog" :close-on-click-modal="false" :before-close="cancel" :title="title" append-to-body width="475px" @close="cancel">
      <el-form ref="form" :model="form" :rules="rules" size="small" label-width="88px">
        <el-form-item label="当前密码" prop="pass">
          <el-input v-model="form.pass" type="password" placeholder="请输入当前账户的登录密码" style="width: 320px;" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="form.phone" auto-complete="on" placeholder="请输入新的手机号码" style="width: 200px;" />
          <el-button :loading="codeLoading" :disabled="isDisabled" size="small" @click="sendCode">{{ buttonName }}</el-button>
        </el-form-item>
        <el-form-item label="验证码" prop="code">
          <el-input v-model="form.code" placeholder="请输入您收到的6位数字验证码" style="width: 320px;" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="medium" round @click="cancel">取消</el-button>
        <el-button :loading="loading" type="primary" size="medium" round @click="doSubmit">确认</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import md5 from 'js-md5'
import store from '@/store'
import { resetPhone } from '@/api/system/code'
import { updatePhone } from '@/api/system/user'

export default {
  props: {
  },
  data() {
    const validPhone = (rule, value, callback) => {
      if (!value) {
        callback(new Error('请输入手机号码'))
      } else if (!this.isValidPhone(value)) {
        callback(new Error('请输入正确的11位手机号码'))
      } else {
        callback()
      }
    }
    return {
      loading: false,
      dialog: false,
      title: '修改手机号',
      form: { phone: '', code: '' },
      user: { phone: '' },
      codeLoading: false,
      codeData: { type: 'phone', value: '' },
      buttonName: '获取验证码', isDisabled: false, time: 60,
      rules: {
        phone: [
          { required: true, trigger: 'blur', validator: validPhone }
        ],
        pass: [
          { required: true, message: '当前密码不能为空', trigger: 'blur' }
        ],
        code: [
          { required: true, message: '验证码不能为空', trigger: 'blur' }
        ]
      }
    }
  },

  methods: {
    isValidPhone(str) {
      const reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/
      return reg.test(str)
    },
    cancel() {
      this.resetForm()
    },
    sendCode() {
      if (this.isValidPhone(this.form.phone)) {
        this.codeLoading = true
        this.buttonName = '验证码发送中'
        this.codeData.value = this.form.phone
        const _this = this
        resetPhone(this.codeData).then(res => {
          this.$message({
            showClose: true,
            message: '发送成功，验证码有效期10分钟',
            type: 'success'
          })
          this.codeLoading = false
          this.isDisabled = true
          this.buttonName = this.time-- + '秒后重新发送'
          this.timer = window.setInterval(function() {
            _this.buttonName = _this.time + '秒后重新发送'
            --_this.time
            if (_this.time < 0) {
              _this.buttonName = '重新发送'
              _this.time = 60
              _this.isDisabled = false
              window.clearInterval(_this.timer)
            }
          }, 1000)
        }).catch(err => {
          this.resetForm()
          this.codeLoading = false
          console.log(err.response.data.message)
        })
      }
    },
    doSubmit() {
      const that = this
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.loading = true
          this.user = { phone: this.form.phone, password: md5(this.form.pass) }
          updatePhone(this.form.code, this.user).then(res => {
            this.loading = false
            this.resetForm()
            that.$message({
              message: '手机号更新成功',
              type: 'success',
              duration: 1500
            })
            store.dispatch('GetInfo').then(() => {})
          }).catch(err => {
            this.loading = false
            console.log(err.response.data.message)
          })
        } else {
          return false
        }
      })
    },
    resetForm() {
      this.dialog = false
      this.$refs['form'].resetFields()
      window.clearInterval(this.timer)
      this.time = 60
      this.buttonName = '获取验证码'
      this.isDisabled = false
      this.form = { pass: '', email: '', code: '' }
    }
  }
}
</script>

<style scoped>

</style>
