<template>
  <div style="display: inline-block;">
    <el-dialog :visible.sync="dialog" :close-on-click-modal="false" :before-close="cancel" :title="title" append-to-body width="475px" @close="cancel">
      <el-form ref="form" :model="form" :rules="rules" size="small" label-width="88px">
        <el-form-item label="用户昵称" prop="nickname">
          <el-input v-model="form.nickname" style="width: 320px;" />
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" style="width: 320px;" />
        </el-form-item>
        <el-form-item label="所属部门" prop="belong">
          <el-input v-model="form.belong" style="width: 320px;" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="medium" round @click="cancel">取消</el-button>
        <el-button :loading="loading" type="primary" size="medium" round @click="doSubmit">确认</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>

export default {
  props: {
    userData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      loading: false, dialog: false, title: '修改资料', form: { nickname: this.userData.username, name: this.userData.name, belong: this.userData.dept },
      // loading: false, dialog: false, title: '修改资料', form: { nickname: this.user.username, name: this.user.name, belong: this.user.dept },
      rules: {
        nickname: [
          { required: true, message: '用户昵称不能为空', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '用户名称不能为空', trigger: 'blur' }
        ],
        belong: [
          { required: true, message: '部门名称不能为空=', trigger: 'blur' }
        ]
      }
    }
  },
  mounted() {
    console.log(this.userData)
  },
  methods: {
    cancel() {
      this.resetForm()
    },
    doSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.loading = true
        } else {
          return false
        }
      })
    },
    resetForm() {
      this.dialog = false
      this.$refs['form'].resetFields()
    }
  }
}
</script>

<style scoped>

</style>
