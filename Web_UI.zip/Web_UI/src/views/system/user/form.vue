<template>
  <el-dialog :visible.sync="dialog" :close-on-click-modal="false" :before-close="cancel" :title="isAdd ? '新增用户' : '编辑用户'" append-to-body width="500px">
    <el-form ref="form" :inline="true" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item v-if="isAdd" label="用户名" prop="username">
        <el-input v-model="form.username" class="item_content_width" />
      </el-form-item>
      <el-form-item v-else label="用户名">
        <el-input v-model="form.username" :readonly="true" class="item_content_width" />
      </el-form-item>
      <el-form-item v-permission="['admin','business']" label="租户" prop="tenantId" :style="{ display:(isAdd ?'block' : 'none') }">
        <el-select v-model="form.tenantId" clearable placeholder="请选择租户" class="item_content_width" @change="getDepts">
          <el-option v-for="item in tenantList" :key="item.id" :label="item.name" :value="item.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="部门" prop="deptId">
        <treeselect v-model="form.deptId" :options="depts" :default-expand-level="Infinity" class="tree item_content_width" no-options-text="暂无部门" placeholder="选择部门">
          <div slot="value-label" slot-scope="{ node }" class="tree_textColor">
            <span v-if="node.raw.status === 1">{{ node.label }}</span>
            <span v-else-if="node.raw.status === 0">{{ node.label }}<el-tag type="danger" size="mini" style="margin-left:10px">禁用</el-tag></span>
          </div>
          <label slot="option-label" slot-scope="{ node }">
            <span v-if="node.raw.status === 1">{{ node.label }}</span>
            <span v-else>{{ node.label }}<el-tag type="danger" size="mini" style="margin-left:10px">禁用</el-tag></span>
          </label>
        </treeselect>
      </el-form-item>
      <el-form-item label="电话" prop="phone">
        <el-input v-model.number="form.phone" class="item_content_width" />
      </el-form-item>
      <el-form-item label="姓名" prop="name">
        <el-input v-model="form.name" class="item_content_width" />
      </el-form-item>
      <el-form-item label="角色" prop="roleId">
        <el-select v-model="form.roleId" placeholder="请选择" class="item_content_width">
          <el-option
            v-for="(item, index) in roles"
            :key="item.name + index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="状态" prop="enabled">
        <el-radio v-for="item in enabledTypeOptions" :key="item.key" v-model="form.enabled" :label="item.key">{{ item.display_name }}</el-radio>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="submitForm">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/system/user'
import { getVisibleDepts } from '@/api/system/dept'
import { getVisibleRoles } from '@/api/system/role'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  components: { Treeselect },
  mixins: [initForm],
  data() {
    const validPhone = (rule, value, callback) => {
      if (!value) {
        callback(new Error('请输入手机号码'))
      } else if (!this.isValidPhone(value)) {
        callback(new Error('请输入正确的11位手机号码'))
      } else {
        callback()
      }
    }
    return {
      title: '用户',
      crudMethod: { add, edit },
      form: { name: '', username: '', email: '', enabled: true, roleId: '', tenantId: '', deptId: null, phone: null },
      roles: [], depts: [], tenantList: [],
      enabledTypeOptions: [
        { key: true, display_name: '正常' },
        { key: false, display_name: '禁用' }
      ],
      rules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入姓名', trigger: 'blur' },
          { min: 2, max: 50, message: '长度在 2 到 50 个字符', trigger: 'blur' }
        ],
        tenantId: [
          { required: true, message: '请选择租户', trigger: 'blur' }
        ],
        deptId: [
          { required: true, message: '请选择部门', trigger: 'blur' }
        ],
        roleId: [
          { required: true, message: '请选择角色', trigger: 'blur' }
        ],
        phone: [
          { required: true, trigger: 'blur', validator: validPhone }
        ],
        enabled: [
          { required: true, message: '状态不能为空', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    addSuccessNotify() {
      this.$message({
        message: '添加成功! 默认密码：123456',
        type: 'success',
        duration: 3000
      })
    },
    beforeSubmitForm() {
      this.form.email = this.form.username + Math.ceil(Math.random() * 10000000000) + '@cntv.cn'
      return true
    },
    cancel() {
      this.dialog = false
      this.$refs['form'].clearValidate()
      this.form = this.resetForm
      this.form.deptId = null
      this.form.roleId = null
    },
    getRoles() {
      getVisibleRoles().then(res => {
        this.roles = res
      }).catch(err => {
        console.log(err.response.data.message)
      })
    },
    getDepts() {
      this.form.deptId = null
      getVisibleDepts({ 'tenantId': this.form.tenantId }).then(res => {
        this.depts = res.content
      })
    },
    isValidPhone(str) {
      const reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/
      return reg.test(str)
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.tree{
  .tree_textColor {
      font-size: 13px;
      color: #606266;
  }
}
.item_content_width {
   width: 360px;
}
</style>
