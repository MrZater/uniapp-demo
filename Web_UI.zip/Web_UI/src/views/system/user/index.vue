<template>
  <div class="app-container">
    <!--form 组件-->
    <eForm ref="form" :is-add="isAdd" />
    <el-row :gutter="20">
      <!--部门数据-->
      <el-col :xs="24" :sm="6" :md="4" :lg="4" :xl="4">
        <div class="head-container">
          <el-select v-if="checkPermission(['admin','business'])" v-model="query.tenantId" placeholder="选择租户" class="filter-item" style="width: 100%" @change="rToQuery">
            <el-option v-for="item in tenantList" :key="item.id" :label="item.name" :value="item.id" />
          </el-select>
          <el-input v-else v-model="deptName" clearable placeholder="输入部门名称搜索" prefix-icon="el-icon-search" style="width: 100%;" class="filter-item" @keyup.enter.native="getDepts" />
        </div>
        <el-tree :data="depts" :props="defaultProps" :expand-on-click-node="false" :highlight-current="true" default-expand-all @node-click="handleNodeClick">
          <span slot-scope="{ node, data }">
            <span v-if="data.status === 1">{{ data.name }}</span>
            <span v-else>{{ data.name }}<el-tag type="danger" size="mini" style="margin-left:10px">禁用</el-tag>
            </span>
          </span>
        </el-tree>
      </el-col>
      <!--用户数据-->
      <el-col :xs="24" :sm="18" :md="20" :lg="20" :xl="20">
        <!--工具栏-->
        <div class="head-container">
          <!-- 搜索 -->
          <el-input v-model="query.blurry" clearable placeholder="输入名称" style="width:200px;" class="filter-item" @keyup.enter.native="toQuery" />
          <el-select v-model="query.enabled" clearable placeholder="状态" class="filter-item" style="width: 90px" @change="toQuery">
            <el-option v-for="item in enabledTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
          </el-select>
          <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
          <!-- 新增 -->
          <div v-permission="['admin','user:add']" style="display: inline-block;margin: 0px 2px;">
            <el-button
              class="filter-item"
              size="mini"
              type="primary"
              icon="el-icon-plus"
              @click="showAddDialog"
            >新增</el-button>
          </div>
        </div>
        <!--表格渲染-->
        <el-table v-loading="loading" :data="data">
          <el-table-column prop="username" label="用户名" />
          <el-table-column prop="name" label="姓名" />
          <el-table-column label="部门">
            <template slot-scope="scope">
              <span v-if="scope.row.dept.status === 1">{{ scope.row.dept.name }}</span>
              <span v-else>{{ scope.row.dept.name }}<el-tag type="danger" size="mini" style="margin-left:10px">禁用</el-tag></span>
            </template>
          </el-table-column>
          <el-table-column label="角色">
            <template slot-scope="scope">
              <span>{{ (scope.row.role ? scope.row.role.name : '') }} </span>
            </template>
          </el-table-column>
          <el-table-column prop="phone" label="电话" />
          <el-table-column label="状态" align="center">
            <template slot-scope="scope">
              <el-tag v-if="scope.row.accountLocked" size="small" type="warning">锁定</el-tag>
              <el-tag v-else-if="scope.row.enabled === false" size="small" type="danger">禁用</el-tag>
              <el-tag v-else size="small">正常</el-tag>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="createTime" label="创建日期">
            <template slot-scope="scope">
              <span>{{ parseTime(scope.row.createTime) }}</span>
            </template>
          </el-table-column>
          <el-table-column v-if="checkPermission(['admin','user:edit','user:delete'])" label="操作" width="125" align="center">
            <template slot-scope="scope">
              <el-button v-permission="['admin','user:edit']" title="编辑用户" size="mini" type="primary" icon="el-icon-edit" @click="prepareEditDialog(scope.row)" />
              <el-dropdown trigger="click" @command="handleCommand">
                <el-button type="warning" size="mini" title="更多"><i class="el-icon-more" /></el-button>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item v-permission="['admin','user:edit']" :command="beforeHandleCommand('reset',scope.row)" icon="el-icon-refresh">重置密码</el-dropdown-item>
                  <el-dropdown-item v-if="scope.row.accountLocked" v-permission="['admin','user:edit']" :command="beforeHandleCommand('unlock', scope.row)" icon="el-icon-bell" divided>解锁用户</el-dropdown-item>
                  <el-dropdown-item v-permission="['admin','user:delete']" :disabled="scope.row.id === 1" :loading="delLoading" :command="beforeHandleCommand('delete', scope.row)" icon="el-icon-delete" divided>删除用户</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </template>
          </el-table-column>
        </el-table>
        <!--分页组件-->
        <el-pagination
          :total="total"
          :current-page="page + 1"
          :page-size="size"
          style="margin-top: 8px;"
          layout="total, prev, pager, next, sizes"
          @size-change="sizeChange"
          @current-change="pageChange"
        />
      </el-col>
    </el-row>
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { del, unlock, resetPasswd, checkUser } from '@/api/system/user'
import { getVisibleDepts } from '@/api/system/dept'
import { getVisibleTenants } from '@/api/system/tenant'

import eForm from './form'
export default {
  name: 'User',
  components: { eForm },
  mixins: [initData],
  data() {
    return {
      props: {
        value: 'id',
        label: 'label',
        children: 'children',
        checkStrictly: true
      },
      tenantList: [],
      deptList: [],
      title: '用户',
      crudMethod: { del },
      deptName: '',
      depts: [],
      deptId: null,
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      enabledTypeOptions: [
        { key: true, display_name: '正常' },
        { key: false, display_name: '禁用' }
      ]
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
      this.getTenantList()
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/users'
      const query = this.query
      const blurry = query.blurry
      const enabled = query.enabled
      const deptId = query.deptId
      const tenantID = query.tenantId
      this.params = { page: this.page, size: this.size, deptId: this.deptId }
      this.params['tenantId'] = tenantID
      if (blurry) { this.params['blurry'] = blurry }
      if (enabled !== '' && enabled !== null) { this.params['enabled'] = enabled }
      if (deptId !== '' && deptId !== null && deptId !== undefined) { this.params['deptId'] = deptId[deptId.length - 1] }
      return true
    },
    rToQuery() {
      getVisibleDepts({ 'tenantId': this.query.tenantId }).then(deptRes => {
        this.depts = deptRes.content
      })

      this.page = 0
      this.init()
    },
    getTenantList() {
      if (this.isAdminRole()) {
        getVisibleTenants().then(res => {
          this.tenantList = res.content
          this.tenantList.forEach(item => {
            if (item.id === String(this.$store.getters.user.tenantId)) {
              this.query.tenantId = item.id
              this.rToQuery()
            }
          })
        })
      } else {
        this.query.tenantId = String(this.$store.getters.user.tenantId)
        this.rToQuery()
      }
    },
    getDepts() {
      getVisibleDepts({ 'name': this.deptName }).then(deptRes => {
        this.depts = deptRes.content
      })
    },
    handleCommand(command) {
      switch (command.command) {
        case 'reset':
          // 重置密码
          this.resetPasswd(command.row.id)
          break
        case 'unlock':
          // 解锁
          this.unlockUser(command.row.id)
          break
        case 'delete':
          // 删除
          this.deleteOne(command.row.id)
          break
      }
    },
    beforeHandleCommand(item, row) {
      return {
        'command': item,
        'row': row
      }
    },
    resetPasswd(id) {
      this.$confirm('确定要重置该用户的登录密码？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        resetPasswd(id).then((res) => {
          this.$message({
            message: '重置成功，新密码为：' + res.password,
            type: 'success',
            duration: 10000,
            showClose: true
          })
          this.init()
        }).catch((e) => {
          console.log(e)
        })
      })
    },
    unlockUser(id) {
      this.$confirm('该用户因尝试登录错误次数过多而被锁定，确定要解锁吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        unlock(id).then(() => {
          this.$message({
            message: '解锁成功',
            type: 'success',
            duration: 2500
          })
          this.init()
        }).catch((e) => {
          console.log(e)
        })
      })
    },
    handleNodeClick(data) {
      if (data.parentId === 0) {
        this.deptId = null
      } else {
        this.deptId = data.id
      }
      this.init()
    },
    beforeShowAddDialog() {
      const _this = this.$refs.form
      _this.form.tenantId = this.query.tenantId
      _this.tenantList = this.tenantList
      _this.getDepts()
      _this.getRoles()
    },
    prepareEditDialog(data) {
      checkUser(data.id).then((res) => {
        this.showEditDialog(data)
      })
    },
    beforeShowEditDialog(data) {
      const _this = this.$refs.form
      _this.form.tenantId = this.isAdminRole() ? this.query.tenantId : this.$store.getters.user.tenantId
      _this.getDepts()
      _this.getRoles()
      return {
        name: data.name,
        tenantId: _this.form.tenantId,
        roleId: (data.role != null ? data.role.id : null),
        deptId: (data.dept != null ? data.dept.id : null),
        phone: data.phone,
        enabled: data.enabled,
        username: data.username
      }
    }
  }
}
</script>
