<template>
  <div class="app-container">
    <el-row :gutter="20">
      <el-col :xs="24" :sm="24" :md="8" :lg="6" :xl="5" style="margin-bottom: 10px">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>个人信息</span>
          </div>
          <div>
            <div style="text-align: center">
              <el-upload
                action="string"
                :show-file-list="false"
                :auto-upload="false"
                :accept="allowedFileTypes"
                :on-change="changeUpload"
                :on-success="handleSuccess"
                :on-error="handleError"
                :on-remove="handleRemove"
                :headers="headers"
                class="avatar-uploader"
              >
                <avatar :username="user.name" :src="user.avatar" :size="80" title="点击上传头像" />
              </el-upload>
            </div>
            <ul class="user-info">
              <li><svg-icon icon-class="user1" /> 用户名称 <div class="user-right">{{ user.username }}</div></li>
              <li><svg-icon icon-class="name" /> 姓名 <div class="user-right">{{ user.name }}</div></li>
              <li @click="handleCommand('pass')"><svg-icon icon-class="anq" />
                修改密码
                <div class="user-right"><i class="el-icon-arrow-right" style="margin-left: 5px" />
                </div>
              </li>
              <li @click="handleCommand('phone')"><svg-icon icon-class="phone" /> 手机号码
                <div class="user-right">
                  {{ user.phone }}
                  <i class="el-icon-arrow-right" style="margin-left: 5px" />
                </div>
              </li>
              <!-- <li @click="handleCommand('email')"><svg-icon icon-class="email" />
                用户邮箱
                <div class="user-right">{{ user.email }}<i class="el-icon-arrow-right" style="margin-left: 5px" />
                </div>
              </li> -->
              <li><svg-icon icon-class="dept" /> 所属部门 <div class="user-right"> {{ user.dept.name }}</div></li>
              <li><svg-icon icon-class="date" /> 创建日期 <div class="user-right">{{ parseTime(user.createTime) }}</div></li>
            </ul>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="16" :lg="18" :xl="19">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>操作日志</span>
            <div style="display:inline-block;float: right;cursor: pointer" @click="refresh"><i :class="ico" /></div>
          </div>
          <div>
            <el-table v-loading="loading" :data="data">
              <el-table-column prop="description" label="行为" />
              <el-table-column prop="requestIp" label="IP" />
              <el-table-column :show-overflow-tooltip="true" prop="address" label="IP来源" />
              <el-table-column prop="time" label="请求耗时" align="center">
                <template slot-scope="scope">
                  <el-tag v-if="scope.row.time <= 300" size="small">{{ scope.row.time }}ms</el-tag>
                  <el-tag v-else-if="scope.row.time <= 1000" size="small" type="warning">{{ scope.row.time }}ms</el-tag>
                  <el-tag v-else size="small" type="danger">{{ scope.row.time }}ms</el-tag>
                </template>
              </el-table-column>
              <el-table-column prop="createTime" label="创建日期" width="180px">
                <template slot-scope="scope">
                  <span>{{ parseTime(scope.row.createTime) }}</span>
                </template>
              </el-table-column>
            </el-table>
            <!--分页组件-->
            <el-pagination
              :total="total"
              :current-page="page + 1"
              :page-size="size"
              style="margin-top: 8px;"
              layout="total, prev, pager, next, sizes"
              @size-change="sizeChange"
              @current-change="pageChange"
            />
          </div>
        </el-card>
      </el-col>
    </el-row>
    <UpdatePass ref="pass" />
    <UpdatePhone ref="phone" />
    <!-- 剪裁组件弹窗 -->
    <el-dialog :visible.sync="dialogVisible" width="800px" :before-close="beforeClose" append-to-body title="图片裁剪" :close-on-click-modal="false">
      <ImageCropper ref="vueCropper" :img-file="fileurl" :skuname="skufilekey" @crop-finished="aliUploadFile" />
    </el-dialog>
  </div>
</template>

<script>
import md5 from 'js-md5'
import { mapGetters } from 'vuex'
import { regEmail, parseTime } from '@/utils/index'
import Avatar from '@/components/Avatar'
import UpdatePass from './center/updatePass'
import UpdatePhone from './center/updatePhone'
import ImageCropper from '@/components/ImageCropper'
import { getToken } from '@/utils/auth'
import initData from '@/mixins/initData'
import AliOSS from '@/utils/ali-oss'
import { updateAvatar } from '@/api/system/user'

export default {
  name: 'Center',
  components: { Avatar, UpdatePhone, UpdatePass, ImageCropper },
  mixins: [initData],
  data() {
    return {
      skufilekey: '',
      fileurl: '',
      dialogVisible: false,
      ico: 'el-icon-refresh',
      allowedFileTypes: 'image/png,image/jpeg',
      headers: {
        'Authorization': 'Bearer ' + getToken()
      }
    }
  },
  computed: {
    ...mapGetters([
      'user'
    ])
  },
  created() {
    this.$nextTick(() => {
      this.init()
    })
    this.$store.dispatch('GetInfo').then(() => {})
  },
  methods: {
    parseTime,
    formatEmail(mail) {
      return regEmail(mail)
    },
    beforeInit() {
      this.url = 'api/logs/user'
      this.params = { page: this.page, size: this.size }
      return true
    },
    changeUpload(file, fileList) {
      console.log('changeUpload', file, fileList)
      const isAllow = this.allowedFileTypes.split(',').indexOf(file.raw.type)
      if (isAllow === -1) {
        this.$message.error('允许的图片类型为 JPG / JPEG / PNG ！')
        return false
      }
      const isLt10M = file.size / 1024 / 1024 < 10
      if (!isLt10M) {
        this.$message.error('上传文件大小不能超过 10MB!')
        return false
      }

      // 上传成功后将图片地址赋值给裁剪框显示图片
      this.$nextTick(() => {
        this.fileurl = URL.createObjectURL(file.raw)
        this.dialogVisible = true
      })
    },
    aliUploadFile(blob, key) {
      console.log('aliUploadFile', blob, key)

      // 模仿图片组件内部构建对象的方式
      blob.uid = Date.now()
      blob.name = blob.uid + '.jpg'
      blob.lastModifiedDate = new Date()

      const saveName = 'avatar/' + md5(this.user.username)
      const rawFile = new window.File([blob], blob.name, { type: 'image/jpeg' })

      AliOSS.ossUploadFile({
        headers: this.headers,
        file: rawFile,
        saveName: saveName,
        onProgress: e => {
          this.handleProgress(e, rawFile)
        },
        onSuccess: res => {
          console.log(res, rawFile)
          this.handleSuccess(res, rawFile)
          // delete this.reqs[blob.uid]
        },
        onError: err => {
          console.log(err, rawFile)
          this.handleError(err, rawFile)
          // delete this.reqs[blob.uid]
        }
      })
    },
    beforeClose() {
      this.dialogVisible = false
    },
    handleCommand(command) {
      if (command === 'pass') {
        this.$refs.pass.dialog = true
      } else if (command === 'email') {
        this.$refs.email.dialog = true
      } else {
        this.$refs.phone.dialog = true
      }
    },
    handleRemove(file, fileList) {
      console.log(file, fileList)
    },
    handleProgress(event, file, fileList) {
      console.log(event, file, fileList)
    },
    handleSuccess(response, file, fileList) {
      const that = this
      const avatarUrl = response + '?t=' + Date.now()
      updateAvatar(avatarUrl).then(res => {
        that.$message({
          message: '头像更新成功',
          type: 'success',
          duration: 1500
        })
        that.dialogVisible = false
        that.$store.dispatch('GetInfo').then(() => {})
      }).catch(err => {
        console.log(err.response.data.message)
      })
    },
    // 监听上传失败
    handleError(err, file, fileList) {
      this.$message({
        message: err,
        type: 'error',
        duration: 2500
      })
    },
    refresh() {
      this.ico = 'el-icon-loading'
      this.$refs.log.init()
      setTimeout(() => {
        this.ico = 'el-icon-refresh'
      }, 300)
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
  .avatar-uploader-icon {
    font-size: 28px;
    width: 120px;
    height: 120px;
    line-height: 120px;
    text-align: center
  }

  .avatar {
    width: 120px;
    height: 120px;
    display: block;
    border-radius: 50%
  }
  .user-info {
    padding-left: 0px;
    list-style: none;
    li{
      border-bottom: 1px solid #F0F3F4;
      border-top: 1px solid #F0F3F4;
      padding: 11px 0px;
      font-size: 13px;
    }
    .user-right {
      float: right;

      a{
        color: #317EF3;
      }
    }
  }
</style>
