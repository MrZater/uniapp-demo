<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>字典详情</span>
      <el-button
        v-if="checkPermission(['admin']) && dictName != ''"
        class="filter-item"
        size="mini"
        style="float: right;padding: 4px 10px"
        type="primary"
        icon="el-icon-plus"
        @click="showAddDialog()"
      >新增</el-button>
    </div>
    <div v-if="dictName === ''">
      <div class="my-code">点击字典查看详情</div>
    </div>
    <div v-else>
      <!--工具栏-->
      <div class="head-container">
        <!-- 搜索 -->
        <el-input v-model="query.value" clearable placeholder="输入字典标签查询" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
        <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      </div>
      <!--表单组件-->
      <eForm ref="form" :is-add="isAdd" :dict-id="dictId" />
      <!--表格渲染-->
      <el-table v-loading="loading" :data="data">
        <el-table-column type="index" label="#" align="center" />
        <el-table-column prop="sort" label="排序" width="80" />
        <el-table-column prop="label" label="标签" />
        <el-table-column prop="value" label="值" />
        <el-table-column label="状态" align="center" width="80">
          <template slot-scope="scope">
            <div v-for="item in statusOptions" :key="item.key">
              <el-tag v-if="scope.row.status === item.key" size="small" :type="scope.row.status === 1 ? '' : 'info'">{{ item.display_name }}</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column v-if="checkPermission(['admin'])" label="操作" width="130px" align="center">
          <template slot-scope="scope">
            <el-button v-permission="['admin']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
            <el-button v-permission="['admin']" :loading="delLoading" size="mini" type="danger" icon="el-icon-delete" @click="deleteOne(scope.row.id)" />
          </template>
        </el-table-column>
      </el-table>
    </div>
  </el-card>
</template>

<script>
import initData from '@/mixins/initData'
import { del } from '@/api/system/dictDetail'
import eForm from './form'
export default {
  components: { eForm },
  mixins: [initData],
  data() {
    return {
      title: '字典详情',
      crudMethod: { del },
      dictName: '',
      dictId: 0
    }
  },
  created() {
    this.loading = false
  },
  methods: {
    beforeInit() {
      this.url = 'api/dictDetail'
      this.params = { dictId: this.dictId }
      const query = this.query
      const value = query.value
      if (value) { this.params['label'] = value }
      return true
    }
  }
}
</script>

<style scoped>
  .my-code{
    padding: 15px;
    line-height: 20px;
    border-left: 3px solid #ddd;
    color: #333;
    font-family: Courier New;
    font-size: 12px
  }
</style>
