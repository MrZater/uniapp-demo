<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入搜索内容" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-select v-model="query.type" clearable placeholder="类型" class="filter-item" style="width: 130px">
        <el-option v-for="item in queryTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <el-button v-permission="['admin','clients:add']" class="filter-item" size="mini" type="primary" icon="el-icon-plus" @click="showAddDialog">新增</el-button>
      <!--表单组件-->
      <eForm ref="form" :is-add="isAdd" />
      <!--表格渲染-->
      <el-table ref="table" v-loading="loading" :data="data" style="width: 100%;">
        <el-table-column type="index" width="40" />
        <el-table-column prop="appName" label="应用名称" />
        <el-table-column prop="appId" label="应用ID" />
        <el-table-column prop="scope" label="授权范围" />
        <el-table-column prop="grantType" label="授权类型" />
        <el-table-column label="自动授权" align="center">
          <template slot-scope="scope">
            <div v-for="item in autoApproveOptions" :key="item.key">
              <el-tag v-if="scope.row.autoApprove === item.key" size="small" :type="scope.row.autoApprove === true ? '' : 'info'">{{ item.display_name }}</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间">
          <template slot-scope="scope">
            <span>{{ parseTime(scope.row.createTime) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" align="center">
          <template slot-scope="scope">
            <div v-for="item in statusOptions" :key="item.key">
              <el-tag v-if="scope.row.status === item.key" size="small" :type="scope.row.status === 1 ? '' : 'info'">{{ item.display_name }}</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column v-if="checkPermission(['admin','clients:edit','clients:delete'])" label="操作" width="150px" align="center">
          <template slot-scope="scope">
            <el-button v-permission="['admin','clients:edit']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
            <el-button v-permission="['admin','clients:delete']" :loading="delLoading" size="mini" type="danger" icon="el-icon-delete" @click="deleteOne(scope.row.id)" />
          </template>
        </el-table-column>
      </el-table>
      <!--分页组件-->
      <el-pagination
        :total="total"
        :current-page="page + 1"
        :page-size="size"
        style="margin-top: 8px;"
        layout="total, prev, pager, next, sizes"
        @size-change="sizeChange"
        @current-change="pageChange"
      />
    </div>
  </div>
</template>

<script>
import initDict from '@/mixins/initDict'
import initData from '@/mixins/initData'
import { del } from '@/api/system/clients'
import eForm from './form'
export default {
  components: { eForm },
  mixins: [initData, initDict],
  data() {
    return {
      title: '应用',
      crudMethod: { del },
      priKey: 'id',
      // 排序规则，默认 id 降序， 支持多字段排序 ['id,desc', 'createTime,asc']
      sort: ['id,desc'],
      queryTypeOptions: [
        { key: 'appId', display_name: '应用ID' },
        { key: 'appName', display_name: '应用名称' }
      ],
      autoApproveOptions: [
        { key: true, display_name: '是' },
        { key: false, display_name: '否' }
      ]
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()

      // 加载数据字典
      this.getDictMap('common_status')
    })
  },
  methods: {
    // 获取数据前设置好接口地址
    beforeInit() {
      this.url = 'api/clients'
      const sort = 'id,desc'
      this.params = { page: this.page, size: this.size, sort: sort }
      const query = this.query
      const type = query.type
      const value = query.value
      if (type && value) { this.params[type] = value }
      return true
    },
    beforeShowEditDialog(data) {
      this.dialogForm.scopeIds = data.scope ? data.scope.split(',') : []
      return data
    }
  }
}
</script>

<style scoped>

</style>
