<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" :title="getFormTitle()" width="520px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="100px">
      <el-form-item label="应用名称" prop="appName">
        <el-input v-model="form.appName" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="App ID" prop="appId">
        <el-input v-model="form.appId" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="App Secret" prop="appSecret">
        <el-input v-model="form.appSecret" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="授权类型" prop="grantType">
        <el-select v-model="form.grantType" placeholder="请选择" style="width: 370px;">
          <el-option v-for="item in grantTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
        </el-select>
      </el-form-item>
      <el-form-item label="授权范围" prop="scope">
        <el-checkbox-group v-model="scopeIds" style="width: 370px;">
          <el-checkbox v-for="item in scopeOptions" :key="item.key" :label="item.key">{{ item.display_name }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="回调URL" prop="redirectUrl">
        <el-input v-model="form.redirectUrl" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="退出后页面URL" prop="logoutUrl">
        <span slot="label">
          退出URL
          <el-tooltip class="item" effect="dark" content="用户退出后跳转到的页面URL地址，留空时为系统默认" placement="top-start">
            <i class="el-icon-question" />
          </el-tooltip>
        </span>
        <el-input v-model="form.logoutUrl" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="自动授权" prop="autoApprove">
        <el-radio v-for="item in autoApproveOptions" :key="item.key" v-model="form.autoApprove" :label="item.key">{{ item.display_name }}</el-radio>
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-radio v-for="item in statusOptions" :key="item.key" v-model="form.status" :label="item.key">{{ item.display_name }}</el-radio>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="submitForm">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/system/clients'
export default {
  title: '应用',
  mixins: [initForm],
  props: {
    isAdd: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      scopeIds: [],
      crudMethod: { add, edit },
      scopeOptions: [
        { key: 'basic', display_name: '基础' },
        { key: 'tenant', display_name: '租户数据' },
        { key: 'user', display_name: '用户数据' }
      ],
      autoApproveOptions: [
        { key: true, display_name: '是' },
        { key: false, display_name: '否' }
      ],
      grantTypeOptions: [
        { key: 'password', display_name: '密码授权（password grant)' },
        { key: 'credentials', display_name: '客户端凭据授权（client credentials grant）' },
        { key: 'authorization_code', display_name: '鉴权码授权（authorization code grant）' },
        { key: 'implicit', display_name: '简化授权（implicit grant）' }
      ],
      form: {
        appId: '',
        appSecret: '',
        userId: '',
        appName: '',
        resourceIds: '',
        scope: [],
        grantType: '',
        redirectUrl: '',
        authorities: '',
        autoApprove: true,
        status: 1
      },
      rules: {
        appId: [
          { required: true, message: 'please enter', trigger: 'blur' }
        ],
        appSecret: [
          { required: true, message: 'please enter', trigger: 'blur' }
        ],
        appName: [
          { required: true, message: 'please enter', trigger: 'blur' }
        ],
        scopeIds: [
          { type: 'array', required: true, message: '请至少选择一个', trigger: 'blur, change' }
        ],
        grantType: [
          { required: true, message: 'please enter', trigger: 'blur' }
        ],
        redirectUrl: [
          { required: true, message: 'please enter', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    beforeSubmitForm() {
      this.form.scope = this.scopeIds.join(',')
      return true
    }
  }
}
</script>

<style scoped>

</style>
