<template>
  <el-dialog :visible.sync="dialog" :close-on-click-modal="false" :before-close="cancel" :title="isAdd ? '新增角色' : '编辑角色'" append-to-body width="520px">
    <el-form ref="form" :inline="true" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="角色名称" prop="name">
        <el-input v-model="form.name" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="数据范围">
        <el-select v-model="form.dataScope" style="width: 370px" placeholder="请选择数据范围" @change="changeScope">
          <el-option
            v-for="item in dateScopes"
            :key="item"
            :label="item"
            :value="item"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="角色级别" prop="sort">
        <el-input-number v-model.number="form.level" :min="1" controls-position="right" style="width: 370px;" />
      </el-form-item>
      <el-form-item v-if="form.dataScope === '自定义'" label="数据范围">
        <treeselect v-model="checkedDeptIds" :options="visibleDepts" :default-expand-level="Infinity" multiple style="width: 370px" no-options-text="暂无部门" placeholder="请选择" />
      </el-form-item>
      <el-form-item label="描述信息">
        <el-input v-model="form.remark" style="width: 370px;" type="textarea" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="text" size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="submitForm">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { getVisibleDepts } from '@/api/system/dept'
import { add, edit } from '@/api/system/role'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  components: { Treeselect },
  mixins: [initForm],
  data() {
    return {
      title: '角色',
      crudMethod: { add, edit },
      dateScopes: ['全部', '本级', '自定义', '自己'],
      visibleDepts: [],
      checkedDeptIds: [],
      form: { name: '', deptIds: '', remark: '', dataScope: '本级', level: 5 },
      rules: {
        name: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    beforeSubmitForm() {
      if (this.form.dataScope === '自定义' && this.checkedDeptIds.length === 0) {
        this.$message({
          message: '自定义数据范围不能为空',
          type: 'warning'
        })
        return false
      } else {
        this.form.deptIds = ''
        if (this.form.dataScope === '自定义') {
          this.form.deptIds = this.checkedDeptIds.join(',')
        }
        return true
      }
    },
    getDepts() {
      if (this.visibleDepts.length !== 0) return
      getVisibleDepts().then(res => {
        this.visibleDepts = res.content
      })
    },
    changeScope() {
      if (this.form.dataScope === '自定义') {
        this.getDepts()
      }
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  /deep/ .el-input-number .el-input__inner {
    text-align: left;
  }
</style>
