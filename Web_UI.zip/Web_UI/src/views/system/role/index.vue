<template>
  <div class="app-container">
    <!--表单组件-->
    <eForm ref="form" :is-add="isAdd" />
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入名称或者描述搜索" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <div v-permission="['admin','roles:add']" style="display: inline-block;margin: 0px 2px;">
        <el-button
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-plus"
          @click="showAddDialog"
        >新增</el-button>
      </div>
    </div>
    <el-row :gutter="15">
      <!--角色管理-->
      <el-col :xs="24" :sm="24" :md="16" :lg="16" :xl="17" style="margin-bottom: 10px">
        <el-card class="box-card" shadow="never">
          <div slot="header" class="clearfix">
            <span class="role-span">角色列表</span>
          </div>
          <el-table v-loading="loading" :data="data" highlight-current-row @current-change="handleCurrentChange">
            <el-table-column type="index" />
            <el-table-column prop="name" label="名称">
              <template slot-scope="scope">
                <el-tooltip v-permission="['admin','business']" :content="scope.row.remark" placement="top-start">
                  <span>{{ scope.row.name }}</span>
                </el-tooltip>
              </template>
            </el-table-column>
            <el-table-column prop="dataScope" label="数据范围" />
            <el-table-column prop="level" label="角色级别" />
            <el-table-column :show-overflow-tooltip="true" width="180px" prop="createTime" label="创建日期">
              <template slot-scope="scope">
                <span>{{ parseTime(scope.row.createTime) }}</span>
              </template>
            </el-table-column>
            <el-table-column v-if="checkPermission(['admin','roles:edit','roles:delete'])" label="操作" width="130px" align="center" fixed="right">
              <template slot-scope="scope">
                <el-button v-if="scope.row.permission!='admin'" v-permission="['admin','roles:edit']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
                <el-button v-if="scope.row.permission!='admin'" v-permission="['admin','roles:delete']" size="mini" type="danger" icon="el-icon-delete" @click="deleteOne(scope.row.id)" />
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
      <!-- 授权 -->
      <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="7">
        <el-card class="box-card" shadow="never">
          <div slot="header" class="clearfix">
            <el-tooltip class="item" effect="dark" content="选择指定角色分配菜单" placement="top">
              <span class="role-span">权限分配</span>
            </el-tooltip>
            <el-button
              v-permission="['admin','roles:edit']"
              :disabled="!showButton"
              :loading="menuLoading"
              icon="el-icon-check"
              size="mini"
              style="float: right; padding: 6px 9px"
              type="primary"
              @click="savePermissions"
            >保存</el-button>
          </div>
          <el-tree
            ref="menu"
            :data="menus"
            :default-checked-keys="menuIds"
            :props="defaultProps"
            :check-strictly="true"
            :check-on-click-node="true"
            :expand-on-click-node="false"
            accordion
            show-checkbox
            node-key="id"
          />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { del } from '@/api/system/role'
import { getMenusTree } from '@/api/system/menu'
import eForm from './form'
import { updateMenu } from '@/api/system/role'
export default {
  name: 'Role',
  components: { eForm },
  mixins: [initData],
  data() {
    return {
      title: '角色',
      size: 1000,
      crudMethod: { del },
      sort: ['level,asc'],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      currentId: 0, menuLoading: false, showButton: false,
      delLoading: false, menus: [], menuIds: []
    }
  },
  created() {
    this.getMenus()
    this.$nextTick(() => {
      this.init()
    })
  },
  methods: {
    beforeInit() {
      this.showButton = false
      this.url = 'api/roles'
      const query = this.query
      const value = query.value
      if (value) { this.params['blurry'] = value }
      // 清空菜单的选中
      this.$refs.menu.setCheckedKeys([])
      return true
    },
    getMenus() {
      getMenusTree().then(res => {
        console.log(res)
        this.menus = res
      })
    },
    handleCurrentChange(val) {
      console.log(val)
      if (val) {
        const _this = this
        // 清空菜单的选中
        this.$refs.menu.setCheckedKeys([])
        // 保存当前的角色id
        this.currentId = val.id
        // 点击后显示按钮
        this.showButton = val.permission !== 'admin'
        // 初始化
        this.menuIds = []
        // 菜单数据需要特殊处理
        if (val.permission !== 'admin') {
          console.log(val.menus)
          val.menus.forEach(function(data, index) {
            _this.menuIds.push(data.id)
          })
          console.log(this.menuIds.join(','))
        }
      }
    },
    savePermissions() {
      this.menuLoading = true
      const role = { menus: [] }
      // 得到半选的父节点数据，保存起来
      this.$refs.menu.getHalfCheckedNodes().forEach(function(data, index) {
        const menu = { id: data.id }
        role.menus.push(menu)
      })
      // 得到已选中的 key 值
      this.$refs.menu.getCheckedKeys().forEach(function(data, index) {
        const menu = { id: data }
        role.menus.push(menu)
      })
      updateMenu(this.currentId, role).then(res => {
        console.log(res)
        this.$notify({
          title: '保存成功',
          type: 'success',
          duration: 2500
        })
        this.menuLoading = false
        this.updateUI(res)
      }).catch(err => {
        this.menuLoading = false
        console.log(err.response.data.message)
      })
    },
    updateUI(res) {
      // 无刷新更新 表格数据
      for (let i = 0; i < this.data.length; i++) {
        if (res.id === this.data[i].id) {
          this.data[i] = res
          break
        }
      }
    },
    beforeShowEditDialog(data) {
      const _this = this.$refs.form
      _this.checkedDeptIds = []
      _this.id = data.id
      if (data.deptIds) {
        _this.checkedDeptIds = data.deptIds.split(',')
      }
      if (data.dataScope === '自定义') {
        _this.getDepts()
      }
      return data
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .role-span {
    font-weight: bold;color: #303133;
    font-size: 15px;
  }
</style>
