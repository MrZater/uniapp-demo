<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" :title="getFormTitle()" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="部门名称" prop="name">
        <el-input v-model="form.name" style="width: 370px;" />
      </el-form-item>
      <el-form-item v-show="depts.length > 0 && form.parentId !== 0" label="上级部门" prop="parentId">
        <treeselect v-model="form.parentId" :options="depts" :clearable="false" :default-expand-level="Infinity" style="width: 370px;" no-options-text="暂无部门" placeholder="选择上级部门" />
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-radio v-for="item in statusOptions" :key="item.key" v-model="form.status" :label="item.key">{{ item.display_name }}</el-radio>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="submitForm">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/system/dept'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  components: { Treeselect },
  mixins: [initForm],
  data() {
    return {
      title: '部门',
      depts: [],
      crudMethod: { add, edit },
      form: {
        name: '',
        status: 1,
        parentId: null,
        tenantId: 0
      },
      rules: {
        name: [
          { required: true, message: '请输入名称', trigger: 'blur' }
        ],
        parentId: [
          { required: true, message: '请选择上级部门', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {

  }
}
</script>

<style scoped>

</style>
