<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-select v-model="query.tenantId" v-permission="['admin','business']" clearable placeholder="租户" class="filter-item" style="width: 120px" @change="toQuery">
        <el-option v-for="item in tenantList" :key="item.id" :label="item.name" :value="item.id" />
      </el-select>
      <el-input v-model="query.value" clearable placeholder="输入部门名称搜索" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-select v-model="query.status" clearable placeholder="状态" class="filter-item" style="width: 90px" @change="toQuery">
        <el-option v-for="item in statusOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <div v-permission="['admin','dept:add']" style="display: inline-block;margin: 0px 2px;">
        <el-button
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-plus"
          @click="showAddDialog"
        >新增</el-button>
      </div>
      <div style="display: inline-block;">
        <el-button
          class="filter-item"
          size="mini"
          type="warning"
          icon="el-icon-more"
          @click="changeExpand"
        >{{ expand ? '折叠' : '展开' }}</el-button>
      </div>
    </div>
    <!--表单组件-->
    <eForm ref="form" :is-add="isAdd" />
    <deptAuth ref="deptAuth" />
    <moveDeptForm ref="moveDept" :is-add="false" />
    <!--表格渲染-->
    <el-table ref="treeTable" v-loading="loading" :data="data" :tree-props="{children: 'children', hasChildren: 'hasChildren'}" :default-expand-all="expand" row-key="id">
      <el-table-column prop="name" label="名称" />
      <el-table-column label="状态" align="center">
        <template slot-scope="scope">
          <div v-for="item in statusOptions" :key="item.key">
            <el-tag v-if="scope.row.status === item.key" size="small" :type="scope.row.status ? '' : 'info'">{{ item.display_name }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建日期">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column v-if="checkPermission(['admin','dept:edit','dept:auth','dept:delete'])" label="操作" align="center">
        <template slot-scope="scope">
          <el-button v-permission="['admin','dept:edit']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
          <el-button v-permission="['admin','tenant:anchor:auth','dept:anchor:auth']" size="mini" type="warning" icon="el-icon-setting" @click="showDeptAuthDialog(scope.row)" />
          <el-button v-permission="['admin','dept:delete']" :loading="delLoading" :disabled="scope.$index === 0" type="danger" icon="el-icon-delete" size="mini" @click="deleteOne(scope.row.id)" />
          <el-dropdown v-permission="['admin','dept:transfer']" trigger="click" :disabled="scope.$index === 0" @command="handleCommand">
            <el-button type="warning" size="mini" title="更多"><i class="el-icon-more" /></el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item icon="el-icon-refresh" :command="beforeHandleCommand('moveDept',scope.row)">部门转移</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { del } from '@/api/system/dept'
import eForm from './form'
import deptAuth from './deptAnchorAuth'
import moveDeptForm from './moveDeptForm'
import { getVisibleTenantList } from '@/api/system/tenant'
import checkPermission from '@/utils/permission'
export default {
  name: 'Dept',
  components: { eForm, deptAuth, moveDeptForm },
  mixins: [initData],
  data() {
    return {
      tenantList: [],
      title: '部门',
      crudMethod: { del },
      columns: [{ text: '名称', value: 'name' }],
      expand: true
    }
  },
  created() {
    this.$nextTick(() => {
      console.log(this.$store.getters.user)
      this.init()
      this.getTenantOrDeptList()
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/dept'
      this.params = { page: this.page, size: this.size }
      const query = this.query
      const value = query.value
      const status = query.status
      const tenantID = query.tenantId
      if (value) { this.params['name'] = value }
      if (status !== '' && status !== null) { this.params['status'] = status }
      if (tenantID !== '' && tenantID !== null && tenantID !== undefined) { this.params['tenantId'] = tenantID }

      return true
    },
    afterInit() {

    },
    getTenantOrDeptList() {
      getVisibleTenantList().then(res => {
        this.tenantList = res.content
        const user_tid = this.$store.getters.user.tenantId
        this.tenantList.forEach(item => {
          if (item.id === String(user_tid)) {
            this.query.tenantId = item.id
          }
        })
      })
    },
    beforeShowAddDialog() {
      const _this = this.$refs.form
      _this.depts = this.data
      _this.form.tenantId = this.query.tenantId
    },
    beforeShowEditDialog(data) {
      const _this = this.$refs.form
      _this.depts = this.data
      return {
        name: data.name,
        status: data.status,
        parentId: data.parentId,
        tenantId: this.query.tenantId
      }
    },
    showDeptAuthDialog(row) {
      const deptAuth = this.$refs.deptAuth
      deptAuth.deptData = row
      const tenantId = checkPermission(['admin', 'business']) ? this.query.tenantId : this.$store.getters.user.tenantId
      deptAuth.getCurrentTenantAnchors(tenantId)
      deptAuth.getCurrentDeptAnchors()
      deptAuth.dialog = true
    },
    changeExpand() {
      this.expand = !this.expand
      this.toggleAllRowExpansion(this.expand)
    },
    beforeHandleCommand(index, value) {
      return {
        index: index,
        value: value
      }
    },
    handleCommand(commandData) {
      if (commandData.index === 'moveDept') {
        const _this = this.$refs.moveDept
        _this.tenantList = this.tenantList
        _this.tempTenantId = this.query.tenantId
        _this.tenantId = this.query.tenantId
        _this.deptId = commandData.value.id
        _this.dialog = true
      }
    }
  }
}
</script>
