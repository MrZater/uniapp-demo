<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" title="部门转移" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="租户" prop="tenantId">
        <el-select v-model="form.tenantId" clearable placeholder="请选择租户" style="width: 370px" @change="getDepts">
          <el-option v-for="item in tenantList" :key="item.id" :label="item.name" :value="item.id" :disabled="item.id === tempTenantId" />
        </el-select>
      </el-form-item>
      <el-form-item label="上级部门" prop="parentId">
        <treeselect v-model="form.parentId" :options="depts" :clearable="false" :default-expand-level="Infinity" style="width: 370px;" no-options-text="暂无部门" placeholder="选择上级部门" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="commitForData">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { getVisibleDepts, transferDept } from '@/api/system/dept'
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
export default {
  components: { Treeselect },
  mixins: [initForm],
  data() {
    // const validTenantId = (rule, value, callback) => {
    //   if (!value) {
    //     callback(new Error('请输入手机号码'))
    //   } else if (!this.isValidPhone(value)) {
    //     callback(new Error('请输入正确的11位手机号码'))
    //   } else {
    //     callback()
    //   }
    // }
    return {
      scaleHeight: '0px',
      depts: [],
      deptId: 0,
      tenantList: [],
      tempTenantId: '',
      form: {
        parentId: null,
        tenantId: ''
      },
      rules: {
        tenantId: [
          { required: true, message: '请选择租户', trigger: 'blur' }
        ],
        parentId: [
          { required: true, message: '请选择上级部门', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    getDepts() {
      this.form.parentId = null
      getVisibleDepts({ 'tenantId': this.form.tenantId }).then(res => {
        this.depts = res.content
      })
    },
    commitForData() {
      this.$refs['form'].validate((valid) => {
        console.log('valid:', valid)
        if (valid) {
          transferDept(this.deptId, this.form.parentId).then(res => {
            this.$message({
              message: '部门转移成功',
              type: 'success'
            })
            this.dialog = false
            this.$parent.init()
          }).catch(err => {
            this.dialog = false
            console.log('部门转移err_:', err)
          })
        }
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

</style>
