<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" title="绑定授权" width="640px">
    <el-form ref="form" :model="form" size="small" label-width="100px">
      <el-form-item label="授权形象" prop="anchorIds">
        <el-checkbox-group v-model="form.anchorIds">
          <el-checkbox v-for="item in visibleAnchors" :key="item.partnerId" :label="item.partnerId + ''">{{ item.name }}({{ item.partnerId }})</el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <el-form-item label="授权发音人" prop="voicerIds">
        <el-checkbox-group v-model="form.voicerIds">
          <el-checkbox v-for="item in visibleVoicers" :key="item.code" :label="item.code">{{ item.name }}({{ item.code }})</el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <el-form-item label="音频采样率" prop="audioRates">
        <el-checkbox-group v-model="form.audioRates">
          <el-checkbox v-for="item in audioRateOptions" :key="item" :label="item + ''">{{ item }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <el-form-item label="视频分辨率" prop="videoRatios">
        <el-checkbox-group v-model="form.videoRatios">
          <el-checkbox v-for="item in videoRatioOptions" :key="item" :label="item">{{ item }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <el-form-item v-show="languageIds" label="多语种" prop="highBitrate">
        <el-switch v-model="form.languageIds" />
      </el-form-item>

      <el-form-item v-show="highBitrate" label="高码流" prop="highBitrate">
        <el-switch v-model="form.highBitrate" />
      </el-form-item>

      <el-form-item v-show="videoBackdrop" label="视频背景" prop="videoBackdrop">
        <el-switch v-model="form.videoBackdrop" />
      </el-form-item>

    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button :disabled="!hasAuthed" :loading="deleteLoading" type="warning" size="medium" round style="float:left" @click="doRemove">移除授权</el-button>
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { editDeptAuth, getDeptAuth, deleteDeptAuth, getTenantAuth } from '@/api/ai-video/anchorAuth'
export default {
  data() {
    return {
      loading: false,
      deleteLoading: false,
      dialog: false,

      hasAuthed: false,

      highBitrate: false,
      videoBackdrop: false,
      languageIds: false,
      visibleAnchors: [],
      visibleVoicers: [],
      deptData: null,
      form: {
        anchorIds: [],
        voicerIds: [],
        audioRates: [],
        highBitrate: false,
        videoBackdrop: false,
        languageIds: false,
        videoRatios: []
      },
      videoRatioOptions: [],
      audioRateOptions: []
    }
  },
  methods: {
    cancel() {
      this.resetForm()
    },
    doSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          console.log('form:', this.$refs.form)
          this.loading = true
          this.doEdit()
        }
      })
    },
    doEdit() {
      const sForm = JSON.parse(JSON.stringify(this.form))
      editDeptAuth(this.deptData.id, sForm).then(res => {
        this.resetForm()
        this.$message({
          message: '修改成功',
          type: 'success',
          duration: 2500
        })
        this.loading = false
      }).catch(err => {
        this.loading = false
        console.log(err)
      })
    },
    doRemove() {
      const that = this
      this.$confirm('您确定要移除该部门的授权吗？授权移除后，将会继承上级部门的授权！', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        that.deleteLoading = true
        deleteDeptAuth(this.deptData.id).then(res => {
          that.resetForm()
          that.$message({
            message: '移除成功',
            type: 'success',
            duration: 2500
          })
          that.deleteLoading = false
        }).catch(err => {
          that.deleteLoading = false
          console.log(err.response.data.message)
        })
      })
    },
    resetForm() {
      this.dialog = false
      this.$refs.form.resetFields()

      this.form = {
        anchorIds: [],
        voicerIds: [],
        audioRates: [],
        highBitrate: false,
        videoBackdrop: false,
        languageIds: false,
        videoRatios: []
      }
    },
    getCurrentTenantAnchors(id) {
      getTenantAuth(id).then(res => {
        this.visibleAnchors = res.anchors
        this.visibleVoicers = res.voicers
        this.videoRatioOptions = res.videoRatios ? res.videoRatios.split(',') : []
        this.audioRateOptions = res.audioRates ? res.audioRates.split(',') : []
        this.audioRateOptions.sort()
        this.highBitrate = res.highBitrate
        this.videoBackdrop = res.videoBackdrop
        this.languageIds = res.languages.length > 0
      }).catch(err => {
        console.log(err)
      })
    },
    getCurrentDeptAnchors() {
      getDeptAuth(this.deptData.id).then(res => {
        res = res[this.deptData.id]
        if (res) {
          this.hasAuthed = true
          this.form.voicerIds = res.voicerIds ? res.voicerIds.split(',') : []
          this.form.anchorIds = res.anchorIds ? res.anchorIds.split(',') : []
          this.form.videoRatios = res.videoRatios ? res.videoRatios.split(',') : []
          this.form.audioRates = res.audioRates ? res.audioRates.split(',') : []
          this.form.highBitrate = res.highBitrate
          this.form.videoBackdrop = res.videoBackdrop
          this.form.languageIds = res.languageIds === '18'
        } else {
          this.hasAuthed = false
        }
      }).catch(err => {
        console.log('deptError', err)
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

</style>
