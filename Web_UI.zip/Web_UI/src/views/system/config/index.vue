<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入搜索内容" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-select v-model="query.type" clearable placeholder="类型" class="filter-item" style="width: 130px">
        <el-option v-for="item in queryTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <div style="display: inline-block;margin: 0px 2px;">
        <el-button
          v-permission="['admin','config:add']"
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-plus"
          @click="showAddDialog"
        >新增</el-button>
      </div>
    </div>
    <!--表单组件-->
    <eForm ref="form" :is-add="isAdd" />
    <!--表格渲染-->
    <el-table v-loading="loading" :data="data">
      <el-table-column prop="id" label="id" />
      <el-table-column prop="paramKey" label="key" />
      <el-table-column prop="paramValue" label="value" />
      <el-table-column prop="status" label="状态" />
      <el-table-column prop="remark" label="备注" />
      <el-table-column v-if="checkPermission(['admin','config:delete','config:edit'])" label="操作" width="150px" align="center">
        <template slot-scope="scope">
          <el-button v-permission="['admin','config:edit']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
          <el-button v-permission="['admin','config:delete']" :loading="delLoading" type="danger" icon="el-icon-delete" size="mini" @click="deleteOne(scope.row.id)" />
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      :current-page="page + 1"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"
    />
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { del } from '@/api/system/config'
import eForm from './form'
export default {
  components: { eForm },
  mixins: [initData],
  data() {
    return {
      title: '配置项',
      queryTypeOptions: [
        { key: 'paramKey', display_name: 'key' }
      ]
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/sysConfig'
      this.params = { page: this.page, size: this.size }
      const query = this.query
      const type = query.type
      const value = query.value
      if (type && value) { this.params[type] = value }
      return true
    }
  }
}
</script>

<style scoped>

</style>
