<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" :title="isAdd ? '新增' : '编辑'" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="key" prop="paramKey">
        <el-input v-model="form.paramKey" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="value">
        <el-input v-model="form.paramValue" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="状态   0：隐藏   1：显示">
        <el-input v-model="form.status" style="width: 370px;" />
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="form.remark" style="width: 370px;" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="text" size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/system/config'
export default {
  mixins: [initForm],
  data() {
    return {
      title: '配置项',
      crudMethod: { add, edit },
      form: {
        id: '',
        paramKey: '',
        paramValue: '',
        status: '',
        remark: ''
      },
      rules: {
        paramKey: [
          { required: true, message: 'please enter', trigger: 'blur' }
        ]
      }
    }
  }
}
</script>

<style scoped>

</style>
