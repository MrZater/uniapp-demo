<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" title="绑定授权" width="640px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="100px">
      <el-form-item label="租户名称">
        <el-input v-model="tenantName" style="width: 320px;" readonly />
      </el-form-item>
      <el-form-item label="授权类型" prop="authType">
        <el-radio-group v-model="form.authType" size="mini" style="width: 320px">
          <el-radio-button v-for="item in authTypeOptions" :key="item.key" v-model="form.authType" :label="item.key">{{ item.display_name }}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item
        v-show="form.authType === 1"
        label="AppID"
        prop="appId"
        :rules="{
          required: form.authType === 1, message: '请填写AppID', trigger: ['blur', 'change']
        }"
      >
        <el-input v-model="form.appId" style="width: 320px;" placeholder="请输入App ID" />
      </el-form-item>
      <el-form-item
        v-show="form.authType === 1"
        label="AppSecret"
        prop="appSecret"
        :rules="{
          required: form.authType === 1, message: '请填写AppSecret', trigger: ['blur', 'change']
        }"
      >
        <el-tooltip class="item" effect="dark" content="内容已加密保存，如需修改请直接输入新内容" placement="right">
          <el-input v-model="form.appSecret" style="width: 320px;" placeholder="请输入App Secret" show-password />
        </el-tooltip>
      </el-form-item>
      <el-form-item
        v-show="form.authType === 2"
        label="账户余额"
        prop="balance"
        :rules="{
          required: form.authType === 2, message: '请填写账户余额', trigger: ['blur', 'change']
        }"
      >
        <el-input v-model="form.balance" type="number" style="width: 320px;" placeholder="请输入账户余额" />
      </el-form-item>
      <el-form-item label="授权有效期" prop="expireTime">
        <el-date-picker
          v-model="form.expireTime"
          style="width: 320px;"
          type="datetime"
          placeholder="选择日期时间"
          value-format="yyyy-MM-dd HH:mm:ss"
          default-time="23:59:59"
        />
      </el-form-item>
      <el-form-item label="最大用户数" prop="maxAccountNum">
        <span slot="label">
          用户数
          <el-tooltip class="item" effect="dark" content="该租户最多可以开设的用户数量，0为不限" placement="top-start">
            <i class="el-icon-question" />
          </el-tooltip>
        </span>
        <el-input v-model="form.maxAccountNum" type="number" style="width: 320px;" />
      </el-form-item>
      <el-form-item label="授权形象" prop="anchorIds">
        <el-checkbox-group v-model="form.anchorIds">
          <el-checkbox v-for="item in visibleAnchors" :key="item.partnerId" :label="item.partnerId + ''">{{ item.name }}({{ item.partnerId }})</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="授权发音人" prop="voicerIds">
        <el-checkbox-group v-model="form.voicerIds">
          <el-checkbox v-for="item in visibleVoicers" :key="item.code" :label="item.code">{{ item.name }}({{ item.code }})</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <!-- <el-form-item label="语种">
        <el-checkbox-group v-model="form.languageIds">
          <el-checkbox v-for="item in visibleLanguages" :key="item.id" :label="item.id">{{ item.name }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item> -->
      <el-form-item label="音频采样率" prop="audioRates">
        <el-checkbox-group v-model="form.audioRates">
          <el-checkbox v-for="item in audioRateOptions" :key="item.name" :label="item.name + ''">{{ item.name }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="视频分辨率" prop="videoRatios">
        <el-checkbox-group v-model="form.videoRatios">
          <el-checkbox v-for="item in videoRatioOptions" :key="item.name" :label="item.name">{{ item.name }}</el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="多语种" prop="languageIds">
        <el-switch v-model="form.languageIds" />
      </el-form-item>
      <el-form-item label="高码流" prop="highBitrate">
        <el-switch v-model="form.highBitrate" />
      </el-form-item>
      <el-form-item label="视频背景" prop="videoBackdrop">
        <el-switch v-model="form.videoBackdrop" />
      </el-form-item>
      <el-form-item label="作品保存周期" prop="saveDays">
        <el-select v-model="form.saveDays">
          <el-option v-for="item in saveDaysOptions" :key="item.value" :value="item.value" :label="item.label" />
        </el-select>
      </el-form-item>
      <el-form-item label="备注" prop="remark">
        <el-input
          v-model="form.remark"
          type="textarea"
          placeholder="请输入内容"
          maxlength="250"
          show-word-limit
          :autosize="{ minRows: 3, maxRows: 6}"
        />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { editAuth } from '@/api/ai-video/anchorAuth'
import { visibleAnchors } from '@/api/ai-video/anchor'
import { visibleVoicers } from '@/api/ai-video/voicer'

export default {
  data() {
    return {
      loading: false, dialog: false, tenantId: 1, tenantName: '', visibleAnchors: [], visibleVoicers: [], visibleLanguages: [],
      authTypeOptions: [
        { key: 0, display_name: '试用' },
        { key: 1, display_name: '独立授权' },
        { key: 2, display_name: '预付费' }
      ],
      form: {
        authType: 0, // 授权类型
        balance: 0, // 余额
        remark: '', // 备注
        appId: '',
        appSecret: '',
        expireTime: '',
        maxAccountNum: 0,
        anchorIds: [],
        voicerIds: [],
        audioRates: [],
        languageIds: false,
        highBitrate: false,
        videoBackdrop: false,
        videoRatios: [],
        saveDays: 7
      },
      audioRateOptions: [
        { name: '16k' },
        { name: '24k' },
        { name: '48k' }
      ],
      videoRatioOptions: [
        { name: '1920 * 1080 (16:9)' },
        { name: '1280 * 720 (16:9)' },
        { name: '856 * 480 (16:9)' },
        { name: '1080 * 1920 (9:16)' },
        { name: '720 * 1280 (9:16)' },
        { name: '480 * 856 (9:16)' },
        { name: '1440 * 1080 (4:3)' },
        { name: '960 * 720 (4:3)' },
        { name: '640 * 480 (4:3)' },
        { name: '1080 * 1440 (3:4)' },
        { name: '720 * 960 (3:4)' },
        { name: '480 * 640 (3:4)' },
        { name: '1080 * 1620 (2:3)' },
        { name: '720 * 1080 (2:3)' },
        { name: '480 * 720 (2:3)' }
      ],
      saveDaysOptions: [
        { value: 7, label: '一周' },
        { value: 30, label: '一个月' },
        { value: 90, label: '三个月' },
        { value: 365, label: '一年' }
      ],
      rules: {
        expireTime: [
          { required: true, message: '请输入过期时间', trigger: 'blur' }
        ],
        anchorIds: [
          { type: 'array', required: true, message: '请至少选择一个形象', trigger: 'change' }
        ],
        voicerIds: [
          { type: 'array', required: true, message: '请至少选择一个发音人', trigger: 'change' }
        ],
        audioRates: [
          { type: 'array', required: true, message: '请选择音频采样率', trigger: 'change' }
        ],
        videoRatios: [
          { type: 'array', required: true, message: '请选择视频分辨率', trigger: 'change' }
        ],
        maxAccountNum: [
          { required: true, message: '请输入最大用户数', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {

    cancel() {
      this.$refs.form.resetFields()
      this.resetForm()
    },
    doSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.loading = true
          this.form.maxAccountNum = JSON.parse(this.form.maxAccountNum)
          this.doEdit()
        }
      })
    },
    doEdit() {
      const sForm = JSON.parse(JSON.stringify(this.form))
      editAuth(this.tenantId, sForm).then(res => {
        this.$refs.form.resetFields()
        this.resetForm()
        this.$message({
          message: '修改成功',
          type: 'success',
          duration: 2500
        })
        this.loading = false
        this.$parent.init()
      }).catch(err => {
        this.loading = false
        console.log(err.response.data.message)
      })
    },
    resetForm() {
      this.dialog = false
      this.form = {
        authType: 0, // 授权类型
        balance: 0, // 余额
        remark: '', // 备注
        appId: '',
        appSecret: '',
        expireTime: '',
        anchorIds: [],
        voicerIds: [],
        audioRates: [],
        highBitrate: false,
        videoBackdrop: false,
        videoRatios: [],
        languageIds: false,
        maxAccountNum: 0,
        saveDays: 7
      }
    },
    resetCheckeSelect(compare, all, type) {
      var allID = []
      all.forEach(item => {
        allID.push(String(item[type]))
      })
      const r = compare.filter(id => {
        return allID.indexOf(id) > -1
      })
      return r
    },
    getVisibleAnchors() {
      visibleAnchors().then(res => {
        this.visibleAnchors = res
        this.form.anchorIds = this.resetCheckeSelect(this.form.anchorIds, res, 'partnerId')
      }).catch(err => {
        console.log(err)
      })
    },
    getVisibleVoicers() {
      visibleVoicers().then(res => {
        this.visibleVoicers = res
        this.form.voicerIds = this.resetCheckeSelect(this.form.voicerIds, res, 'code')
      }).catch(err => {
        console.log(err)
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

</style>
