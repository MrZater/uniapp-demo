<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :visible.sync="sysConfigDialog" title="系统配置" width="640px" @close="cancel">
    <el-form ref="form" size="small" label-width="100px">
      <el-form-item label="域名设置" prop="name">
        <el-input v-model="domain" placeholder="请输入域名" />
      </el-form-item>
      <el-form-item ref="uploadItem" label="Logo设置" prop="Logofile">
        <el-upload
          ref="logoupload"
          action=""
          :accept="allowedFileTypes"
          list-type="picture"
          :http-request="aliUploadFile"
          :limit="2"
          :file-list="file_lists[0]"
          :auto-upload="false"
          :before-upload="handleBeforeUpload"
          :on-change="handleFileChange"
          :on-remove="handleFileRemove"
        >
          <el-button slot="trigger" size="small" type="primary" @click="click(0)">选取文件</el-button>
        </el-upload>
      </el-form-item>
      <el-form-item ref="uploadItem" label="背景图设置" prop="BgFile">
        <el-upload
          ref="bgupload"
          action=""
          :accept="allowedFileTypes"
          list-type="picture"
          :http-request="aliUploadFile"
          :limit="2"
          :file-list="file_lists[1]"
          :auto-upload="false"
          :before-upload="handleBeforeUpload"
          :on-change="handleFileChange"
          :on-remove="handleFileRemove"
        >
          <el-button slot="trigger" size="small" type="primary" @click="click(1)">选取文件</el-button>
        </el-upload>
      </el-form-item>
      <el-form-item label="提示">
        <span>只允许上传PNG/JPG的文件，且文件大小不超过100M</span>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { setSettings } from '@/api/system/tenant'
import AliOSS from '@/utils/ali-oss'
import { getToken } from '@/utils/auth'

export default {
  components: {},
  data() {
    return {
      settings: {},
      tenantID: '',
      totalUpload: 0,
      uploaded: 0,
      fileSelect: 0,
      sysConfigDialog: false,
      file_lists: [[], []],
      loading: false,
      allowedFileTypes: 'image/png,image/jpeg',
      domain: '',
      uploadContent: {}
    }
  },
  methods: {
    setDefaultValue(val) {
      var bg_file_list = []
      if (val && val.bgUrl.length > 0) {
        const file = { url: val.bgUrl, name: val.bgName, isDeafault: true }
        bg_file_list.push(file)
      }
      this.file_lists[1] = bg_file_list

      var c_logo_file_list = []
      if (val && val.logoUrl.length > 0) {
        const file = { url: val.logoUrl, name: val.logoName, isDeafault: true }
        c_logo_file_list.push(file)
      }
      this.file_lists[0] = c_logo_file_list

      if (val && val.domain.length > 0) {
        this.domain = val.domain
      }
    },
    click(index) {
      this.fileSelect = index
    },
    cancel() {
      this.resetForm()
      this.$parent.init()
    },
    doSubmit() {
      var hasUploadItem = false
      this.loading = true
      this.file_lists.forEach((item, index) => {
        if (item.length > 0) {
          if (item[0].hasOwnProperty('isDeafault') && index === 0) {
            this.uploadContent.logoUrl = item[0].url
            this.uploadContent.logoName = item[0].name
          } else if (item[0].hasOwnProperty('isDeafault') && index === 1) {
            this.uploadContent.bgUrl = item[0].url
            this.uploadContent.bgName = item[0].name
          } else {
            hasUploadItem = true
            index === 0 ? this.$refs.logoupload.submit() : this.$refs.bgupload.submit()
            this.totalUpload = this.totalUpload + 1
          }
        } else {
          if (index === 0) {
            this.uploadContent.logoUrl = ''
            this.uploadContent.logoName = ''
          } else if (index === 1) {
            this.uploadContent.bgUrl = ''
            this.uploadContent.bgName = ''
          }
        }
      })
      if (!hasUploadItem) {
        this.sendContentToServer()
      }
    },
    resetForm() {
      this.domain = ''
      this.file_lists = [[], []]
      this.sysConfigDialog = false
    },
    aliUploadFile(res) {
      const that = this
      this.loading = true
      AliOSS.ossUploadFile({
        header: {
          'Authorization': 'Bearer ' + getToken()
        },
        file: res.file,
        onProgress: p => {
        },
        onSuccess: fileUrl => {
          that.loading = false
          that.fileUploaded(fileUrl, res.file)
        },
        onError: error => {
          that.loading = false
          console.log(error)
        }
      })
    },
    fileUploaded(res, file) {
      if (this.file_lists[0].length > 0 && this.file_lists[0][0].raw === file) {
        this.uploadContent.logoUrl = res
        this.uploadContent.logoName = file.name
      } else if (this.file_lists[1].length > 0 && this.file_lists[1][0].raw === file) {
        this.uploadContent.bgUrl = res
        this.uploadContent.bgName = file.name
      }
      this.uploaded = this.uploaded + 1
      if (this.uploaded === this.totalUpload) {
        this.sendContentToServer()
      }
    },
    sendContentToServer() {
      this.uploadContent.domain = this.domain
      const _that = this
      console.log('sendCotent:', _that.uploadContent)
      setSettings(this.tenantID, this.uploadContent).then(res => {
        _that.loading = false
        _that.cancel()
        _that.$message({
          message: '设置成功',
          type: 'success',
          duration: 2500
        })
      }).catch(() => {
        _that.loading = false
      })
    },
    handleBeforeUpload(file) {
      const isAllowed = this.allowedFileTypes.split(',').indexOf(file.type) >= 0
      const isLt2M = file.size / 1024 / 1024 < 100
      if (!isAllowed) {
        this.$message.error('上传文件类型不允许!')
      }
      if (!isLt2M) {
        this.$message.error('上传文件大小不能超过100MB!')
      }
      return isAllowed && isLt2M
    },
    handleFileChange(file, fileList) {
      var c_file_list = []
      c_file_list.push(file)
      this.file_lists[this.fileSelect] = c_file_list
      this.$forceUpdate()
    },
    handleFileRemove(file, fileList) {
      this.file_lists.forEach((files, index) => {
        if (files.length > 0) {
          if (files[0] === file) {
            this.file_lists[index] = []
          }
        }
      })
    }
  }
}
</script>
<style lang='stylus' scoped>

</style>
