<template>
  <el-dialog :append-to-body="true" :close-on-click-modal="false" :before-close="cancel" :visible.sync="dialog" :title="isAdd ? '新增租户' : '编辑租户'" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="100px">
      <el-form-item label="租户名称" prop="name">
        <el-input v-model="form.name" style="width: 320px;" />
      </el-form-item>
      <el-form-item label="联系人" prop="contactName">
        <el-input v-model="form.contactName" style="width: 320px;" />
      </el-form-item>
      <el-form-item label="联系电话" prop="contactNumber">
        <el-input v-model="form.contactNumber" style="width: 320px;" />
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="form.remarks" type="textarea" style="width: 320px;" />
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-radio v-for="item in statusOptions" :key="item.key" v-model="form.status" :label="item.key">{{ item.display_name }}</el-radio>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="medium" round @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" size="medium" round @click="submitForm">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import initForm from '@/mixins/initForm'
import { add, edit } from '@/api/system/tenant'
export default {
  title: '租户',
  mixins: [initForm],
  props: {
    isAdd: {
      type: Boolean,
      required: true
    }
  },
  data() {
    const validPhone = (rule, value, callback) => {
      if (!value) {
        callback()
      } else if (!this.isValidPhone(value)) {
        callback(new Error('请输入正确的11位手机号码'))
      } else {
        callback()
      }
    }
    return {
      crudMethod: { add, edit },
      form: {
        name: '',
        remarks: '',
        contactNumber: '',
        contactName: '',
        status: 1
      },
      rules: {
        name: [
          { required: true, message: '请输入租户名称', trigger: 'blur' },
          { min: 2, max: 30, message: '长度在 2 到 30 个字符', trigger: 'blur' }
        ],
        contactNumber: [
          { required: false, trigger: 'blur', validator: validPhone }
        ],
        status: [
          { required: true, message: '状态不能为空', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    isValidPhone(str) {
      const reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/
      return reg.test(str)
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
