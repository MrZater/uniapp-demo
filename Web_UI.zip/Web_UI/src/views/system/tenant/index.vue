<template>
  <div class="app-container">
    <!--工具栏-->
    <div class="head-container">
      <!-- 搜索 -->
      <el-input v-model="query.value" clearable placeholder="输入搜索内容" style="width: 200px;" class="filter-item" @keyup.enter.native="toQuery" />
      <el-select v-model="query.type" clearable placeholder="类型" class="filter-item" style="width: 130px">
        <el-option v-for="item in queryTypeOptions" :key="item.key" :label="item.display_name" :value="item.key" />
      </el-select>
      <el-button class="filter-item" size="mini" type="success" icon="el-icon-search" @click="toQuery">搜索</el-button>
      <!-- 新增 -->
      <div style="display: inline-block;margin: 0px 2px;">
        <el-button
          v-permission="['admin','tenant:add']"
          class="filter-item"
          size="mini"
          type="primary"
          icon="el-icon-plus"
          @click="showAddDialog"
        >新增</el-button>
      </div>
    </div>
    <!--表单组件-->
    <eForm ref="form" :is-add="isAdd" />

    <!--授权组件-->
    <anchorAuth ref="anchorAuth" />

    <!-- 系统配置 -->
    <sysConfig ref="sysConfig" />
    <!--表格渲染-->
    <el-table ref="table" v-loading="loading" :data="data">
      <el-table-column prop="id" label="ID" />
      <el-table-column prop="name" label="租户名称" />
      <!-- <el-table-column label="授权信息">
        <template slot-scope="scope">
          <div v-for="item in authTypeOptions" :key="item.key">
            <el-tag v-if="authMaps[scope.row.code] && authMaps[scope.row.code].authType === item.key" size="small" :type="item.key === 1 ? '' : 'info'">{{ item.display_name }}</el-tag>
          </div>
        </template>
      </el-table-column> -->
      <el-table-column label="创建时间">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" align="center">
        <template slot-scope="scope">
          <div v-for="item in statusOptions" :key="item.key">
            <el-tag v-if="scope.row.status === item.key" size="small" :type="scope.row.status === 1 ? '' : 'info'">{{ item.display_name }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column v-if="checkPermission(['admin','tenant:edit','tenant:delete'])" label="操作" width="150px" align="center">
        <template slot-scope="scope">
          <el-button v-permission="['admin','tenant:edit']" size="mini" type="primary" icon="el-icon-edit" @click="showEditDialog(scope.row)" />
          <el-button v-permission="['admin','tenant:anchor:auth']" size="mini" type="warning" icon="el-icon-s-check" @click="showAuthDialog(scope.row)" />
          <el-button v-permission="['admin','tenant:config']" size="mini" type="warning" icon="el-icon-setting" @click="showSysConfigDialog(scope.row)" />
          <el-button v-permission="['admin','tenant:delete']" :loading="delLoading" size="mini" type="danger" icon="el-icon-delete" @click="deleteOne(scope.row.id)" />
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      :current-page="page + 1"
      :page-size="size"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"
    />
  </div>
</template>

<script>
import initData from '@/mixins/initData'
import { del } from '@/api/system/tenant'
import { getAuthMap } from '@/api/ai-video/anchorAuth'
import eForm from './form'
import anchorAuth from './anchorAuth'
import sysConfig from './sysConfigs'

export default {
  components: { eForm, anchorAuth, sysConfig },
  mixins: [initData],
  data() {
    return {
      title: '租户',
      crudMethod: { del },
      priKey: 'id',
      authMaps: {},
      // 排序规则，默认 id 降序， 支持多字段排序 ['id,desc', 'createTime,asc']
      sort: ['id,desc'],
      queryTypeOptions: [
        { key: 'id', display_name: 'ID' },
        { key: 'name', display_name: '租户名称' }
      ],
      authTypeOptions: [
        { key: 0, display_name: '试用' },
        { key: 1, display_name: '独立授权' },
        { key: 2, display_name: '预付费' }
      ]
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
    })
  },
  methods: {
    beforeInit() {
      this.url = 'api/tenant'
      this.params = { page: this.page, size: this.size }
      const query = this.query
      const type = query.type
      const value = query.value
      if (type && value) { this.params[type] = value }
      return true
    },
    afterInit(data) {
      if (!data || data.length === 0) {
        return
      }
      const ids = []
      data.forEach(function(row, index) {
        if (ids.indexOf(row.id) === -1) {
          ids.push(row.id)
        }
      })
      getAuthMap(ids.join(',')).then(res => {
        this.authMaps = res
      })
      return
    },
    showAuthDialog(data) {
      const _this = this.$refs.anchorAuth
      _this.tenantId = data.id
      _this.tenantName = data.name
      _this.resetForm()
      var anchorAuth = null
      if (this.authMaps[data.id]) {
        anchorAuth = JSON.parse(JSON.stringify(this.authMaps[data.id]))
      }
      if (anchorAuth) {
        anchorAuth.anchorIds = anchorAuth.anchorIds.length > 0 ? anchorAuth.anchorIds.split(',') : []
        anchorAuth.voicerIds = anchorAuth.voicerIds.length > 0 ? anchorAuth.voicerIds.split(',') : []
        anchorAuth.audioRates = anchorAuth.audioRates.length > 0 ? anchorAuth.audioRates.split(',') : []
        anchorAuth.videoRatios = anchorAuth.videoRatios.length > 0 ? anchorAuth.videoRatios.split(',') : []
        anchorAuth.languageIds = anchorAuth.languageIds === '18'
        _this.form = anchorAuth
      }
      _this.getVisibleVoicers()
      _this.getVisibleAnchors()
      _this.dialog = true
    },
    showSysConfigDialog(row) {
      const _this = this.$refs.sysConfig
      _this.setDefaultValue(JSON.parse(JSON.stringify(row.settings)))
      _this.tenantID = row.id
      _this.sysConfigDialog = true
    }
  }
}
</script>

<style scoped>

</style>
