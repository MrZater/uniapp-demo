<template>
  <div class="contain" />
</template>

<script>
export default {
  name: 'Login',
  data() {
    return {
      loading: null,
      query: null
    }
  },
  watch: {
    $route: {
      handler: function(route) {
        this.query = route.query
        this.refUrl = route.query.ref // 成功URL
        this.redirectUrl = route.query.redirecturl // 失败URL
      },
      immediate: true
    }
  },
  created() {
    this.handleLogin()
  },
  mounted() {
    this.loading = this.$loading({
      lock: true,
      text: '正在跳转，请稍后...',
      background: 'rgba(0, 0, 0, 0.1)'
    })
  },
  beforeDestroy() {
    this.loading.close()
  },
  methods: {
    handleLogin() {
      if (!this.query.token || !this.query.sign || !this.query.t || !this.query.noncestr) {
        return
      }
      const that = this
      this.$store.dispatch('OAuthLogin', this.query).then((toUrl) => {
        if (toUrl && (toUrl.indexOf('http://') >= 0 || toUrl.indexOf('https://') >= 0)) {
          window.location.href = toUrl
        } else {
          that.$router.push({ path: '/ai-video/works' })
        }
      }).catch((err) => {
        console.log(err.response.data.message)
        const errMsg = err.response.data.message
        window.location.href = that.redirectUrl + (that.redirectUrl.indexOf('?') > 0 ? '&ERR=' + errMsg : '?ERR=' + errMsg)
      })
    }
  }
}
</script>
<style lang='scss' scoped>

</style>
