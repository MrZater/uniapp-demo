
<template>
  <div class="navbar">
    <hamburger :toggle-click="toggleSideBar" :is-active="sidebar.opened" class="hamburger-container" />
    <breadcrumb class="breadcrumb-container" />

    <div class="right-menu">

      <el-dropdown class="avatar-container right-menu-item hover-effect" trigger="hover">
        <div class="avatar-wrapper">
          <avatar :username="user.name" :src="user.avatar" :size="40" />
          <i class="el-icon-caret-bottom" />
        </div>
        <el-dropdown-menu slot="dropdown">
          <span style="display:block;" @click="$router.push('/user/center')">
            <el-dropdown-item>
              个人中心
            </el-dropdown-item>
          </span>
          <span style="display:block;" @click="$refs.pass.dialog = true">
            <el-dropdown-item>
              修改密码
            </el-dropdown-item>
          </span>
          <span style="display:block;" @click="open">
            <el-dropdown-item divided>
              退出登录
            </el-dropdown-item>
          </span>
        </el-dropdown-menu>
      </el-dropdown>

      <!-- <el-tooltip v-permission="['admin','business']" content="切换租户" effect="dark" placement="bottom">
        <div class="tenant-wrapper right-menu-item hover-effect">
          <avatar username="长江云" :size="40" :rounded="false" :custom-style="{'border-radius': '5px'}" />
        </div>
      </el-tooltip> -->
    </div>
    <!-- 修改密码弹窗 -->
    <updatePass ref="pass" />

  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Avatar from '@/components/Avatar'
import Breadcrumb from '@/components/Breadcrumb'
import Hamburger from '@/components/Hamburger'
import UpdatePass from '@/views/system/user/center/updatePass'

export default {
  components: {
    Breadcrumb,
    Hamburger,
    Avatar,
    UpdatePass
  },
  data() {
    return {
      dialogVisible: false
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'user',
      'device',
      'redirectUrl'
    ])
  },
  mounted() {
    setTimeout(() => {
      if (this.user.needResetPassword != null && this.user.needResetPassword === true) {
        this.$refs.pass.dialog = true
      } else {
        this.$refs.pass.dialog = false
      }
    }, 200)
  },
  methods: {
    open() {
      this.$confirm('确定注销并退出系统吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.logout()
      })
    },
    updatePass() {
      console.log('updatePass')
    },
    toggleSideBar() {
      this.$store.dispatch('ToggleSideBar')
    },
    logout() {
      const that = this
      this.dialogVisible = false
      this.$store.dispatch('LogOut').then((res) => {
        console.log(that.redirectUrl)
        if (that.redirectUrl && that.redirectUrl.length > 0) {
          window.location.href = that.redirectUrl
        } else {
          location.reload() // 为了重新实例化vue-router对象 避免bug
        }
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.navbar {
  height: 50px;
  overflow: hidden;
  position: relative;
  background: #fff;
  box-shadow: 0 1px 4px rgba(0,21,41,.08);

  .hamburger-container {
    line-height: 58px;
    height: 50px;
    float: left;
    padding: 0 15px;
  }
  .breadcrumb-container{
    float: left;
  }

  .right-menu {
    float: right;
    height: 100%;
    line-height: 50px;
    margin-right: 10px;

    &:focus {
      outline: none;
    }

    .right-menu-item {
      display: inline-block;
      padding: 0 8px;
      font-size: 18px;
      color: #5a5e66;
      vertical-align: text-bottom;
      margin-right: 10px;

      &.hover-effect {
        cursor: pointer;
        transition: background .3s;

        &:hover {
          background: rgba(0, 0, 0, .025)
        }
      }
      &:last-child {
        margin-right: 20px;
      }
    }

    .avatar-container {

      .avatar-wrapper {
        margin-top: 5px;
        position: relative;

        .el-icon-caret-bottom {
          cursor: pointer;
          position: absolute;
          right: -15px;
          top: 15px;
          font-size: 12px;
        }
      }
    }

    .tenant-wrapper {
      margin-top: 5px;
      position: relative;
    }

  }
}
</style>
