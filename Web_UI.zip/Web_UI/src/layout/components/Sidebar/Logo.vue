<template>
  <div v-if="sidebarLogo" class="sidebar-logo-container" :class="{'collapse':collapse}">
    <transition name="sidebarLogoFade">
      <router-link v-if="collapse" key="collapse" class="sidebar-logo-link" to="/">
        <img v-if="userLogo" :src="userLogo" class="sidebar-logo">
        <el-image v-else :src="imgSrc" class="sidebar-logo" fit="contain" />
      </router-link>
      <router-link v-else key="expand" class="sidebar-logo-link" to="/">

        <div style="width:100%;text-align: center">
          <img v-show="userLogo" class="user_logo" :src="userLogo">
          <div v-show="userLogo" class="line" />
          <el-image :src="imgSrc" class="c_logo" fit="fill" />
          <h1 class="sidebar-title">{{ webName }} </h1>
        </div>
      </router-link>
    </transition>
  </div>
</template>

<script>
import logoImg from '@/assets/logo/cc_logo.png'
import { mapState } from 'vuex'
export default {
  name: 'SidebarLogo',
  props: {
    collapse: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      imgSrc: logoImg
    }
  },
  computed: {
    ...mapState({
      webName: state => state.settings.webName,
      sidebarLogo: state => state.settings.sidebarLogo,
      userLogo: state => state.user.userLogo
    })
  }
}
</script>

<style lang="scss" scoped>
.sidebarLogoFade-enter-active {
  transition: opacity 1.5s;
}

.sidebarLogoFade-enter,
.sidebarLogoFade-leave-to {
  opacity: 0;
}

.sidebar-logo-container {
  position: relative;
  width: 100%;
  background: #2b2f3a;
  text-align: center;
  overflow: hidden;
  padding: 15px 10px;

  .sidebar-logo-link {
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    .line{
    width:1px;
    background-color:rgb(211, 211, 211);
    height: 15px;
    display: inline-block;
    margin:0 10px;
  }
  .user_logo{
     height: 23px;
  }
  .c_logo{
    width: 79px;
    height: 23px;;
  }

    & .sidebar-title {
      margin-top: 15px ;
      color: #fff;
      font-weight: 600;
      font-size: 14px;
      font-family: Avenir, Helvetica Neue, Arial, Helvetica, sans-serif;
    }
  }

  &.collapse {
      padding: 10px 10px;
    .sidebar-logo {
      width:30px;
      height:30px;
      object-fit: contain;
    }
  }
}
</style>
