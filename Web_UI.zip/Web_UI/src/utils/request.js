import axios from 'axios'
import router from '@/router/routers'
import { Message, MessageBox } from 'element-ui'
import store from '../store'
import { getToken } from '@/utils/auth'
import { getRefreshToken } from '@/api/login'

/* 是否正在刷新的标志*/
window.isRefreshing = false
/* 存储请求的数组*/
var refreshSubscribers = []

/* 将所有的请求都push到数组中,其实数组是[function(token){}, function(token){},...]*/
function subscribeTokenRefresh(cb) {
  refreshSubscribers.push(cb)
}

/* 数组中的请求得到新的token之后自执行，用新的token去请求数据*/
function onRrefreshed(token) {
  refreshSubscribers.map(cb => cb(token))
}

/**
 * 快过期了 和 已经过期了
 * @returns {boolean}
 */
function isTokenWillExpired() {
  const expireTime = store.getters.expireTime
  if (expireTime) {
    const nowTime = new Date().getTime()
    const willExpired = expireTime - nowTime / 1000 < 30 * 60
    return willExpired
  }
  return false
}

function directLogin() {
  router.push({
    path: '/login',
    query: {
      redirectUrl: window.location.href.split('#')[1] || ''
    }
  })
}

// 创建axios实例
const service = axios.create({
  baseURL: process.env.NODE_ENV === 'production' ? process.env.VUE_APP_BASE_API : '/', // api 的 base_url
  timeout: 5000 // 请求超时时间
})

// request拦截器
service.interceptors.request.use(
  config => {
    const token = getToken()
    if (token) {
      config.headers['Authorization'] = 'Bearer ' + token // 让每个请求携带自定义token 请根据实际情况自行修改
      config.headers['Content-Type'] = 'application/json;charset=utf-8'

      /* 判断token是否将要过期 */
      if (!isTokenWillExpired() || (config.url.indexOf('/auth/refresh-token') !== -1)) {
        return config
      }

      /* 判断是否正在刷新 */
      if (!window.isRefreshing) {
        window.isRefreshing = true
        getRefreshToken().then(res => {
          console.log(res)
          window.isRefreshing = false
          store.dispatch('ReloadToken', res.token)
          onRrefreshed(res.data)
          refreshSubscribers = []
        }).catch(err => {
          console.log(err)
          directLogin()
        })
        const retry = new Promise((resolve, reject) => {
          subscribeTokenRefresh((token) => {
            config.headers['Authorization'] = 'Bearer ' + token
            resolve(config)
          })
        })
        retry
      }
    }
    return config
  },
  error => {
    console.log(error) // for debug
    Promise.reject(error)
  }
)

// response 拦截器
service.interceptors.response.use(
  response => {
    const code = response.status
    if (code < 200 || code > 300) {
      Message.error({
        message: response.message
      })
      return Promise.reject('error')
    } else {
      return response.data
    }
  },
  error => {
    if (error.response) {
      const code = error.response.status
      if (code === 401) { //  登录过期
        MessageBox.confirm('您的登录状态已过期，请重新登录！', '登录过期', {
          confirmButtonText: '重新登录',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          store.dispatch('RemoveToken').then(() => {
            location.reload() // 为了重新实例化vue-router对象 避免bug
          })
        })
      } else if (code === 403) { // 没有权限
        MessageBox.confirm('您没有访问该页面或进行该操作的权限！', '权限错误', {
          confirmButtonText: '重新登录',
          cancelButtonText: '返回',
          type: 'warning'
        }).then(() => {
          store.dispatch('LogOut').then(() => {
            location.reload()
          })
        }).catch(() => {
          if (router.history.router !== null) {
            router.go(-1)
          } else {
            router.push({ path: '/' })
          }
        })
      } else {
        const errorMsg = error.response.data.message || '网络请求错误'
        if (errorMsg !== undefined) {
          Message.error({
            message: errorMsg
          })
        }
      }
    }
    return Promise.reject(error)
  }
)
export default service
