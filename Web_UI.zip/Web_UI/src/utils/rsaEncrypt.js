import JSEncrypt from 'jsencrypt/bin/jsencrypt'

// 密钥对生成 http://web.chacuo.net/netrsakeypair

const publicKey = '-----BEGIN PUBLIC KEY-----' +
  'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYa42M3vKp/doDJP+n+DEFyt70' +
  'tV+iMZmR+XTjXLLnU4EUfoXMyyi7P72WRp9jnmtmtA4dIqVDaW3mO6Ivm7mbDNV1' +
  'NxBvhJRTsDsiJ2ksaagmtyt3Owb/VKFpIKrF4GrqVMJhtQNHsbII4wjUA/o1+BaO' +
  '2ebnnieB5fGgC0j9WQIDAQAB' +
  '-----END PUBLIC KEY-----'

const privateKey = '-----BEGIN RSA PRIVATE KEY-----' +
  'MIICXAIBAAKBgQCYa42M3vKp/doDJP+n+DEFyt70tV+iMZmR+XTjXLLnU4EUfoXM' +
  'yyi7P72WRp9jnmtmtA4dIqVDaW3mO6Ivm7mbDNV1NxBvhJRTsDsiJ2ksaagmtyt3' +
  'Owb/VKFpIKrF4GrqVMJhtQNHsbII4wjUA/o1+BaO2ebnnieB5fGgC0j9WQIDAQAB' +
  'AoGACbStmJcY2kDPOWyJeBt6ma0Tuf7ztksUxaIeMp00Sj07xr+Qyxvzvcq/Cpr4' +
  'KtqLaciU7n+GiQ6lYCgTeZcfwDntGjV9VbjaQ4pkAGPvnA550Lm9HzVOY8x0wDhA' +
  '9fB9fvKpkC95rSV3dIBqCOtmfdnuAgIsN7crqV+4yUVUa8ECQQDJm+Vkr9i2SSc2' +
  'HXc7z3kOJOWcR7/+E63Gq7Mh1M1iBpqFQTEsj/2aDUnuopqcHlXeQmjd4KPTxr06' +
  'I4mOcsG5AkEAwYpvMmwrgVreaJG2JmHk6t0vricmgOWxqG0ilnb/70Bx+A0+wyIr' +
  'y6IcMFg3sStYYlhJABMXpU273DXRxrpooQJAf58uERS3rHyWU81HQxdM3EVDDDDn' +
  'OmEeqhrapFnfQWRIwH3KMRldQf2ThXptQNJ7LN0BISMo0dCGzJzeYMwIEQJBAIOJ' +
  'T2uogqTmmjPdnDtX2xoYe7hT2WJPOcArdA9pDyaO2SZp8hby2WsLYTcmLauWtvoX' +
  '4H1RfIeXXi8a0NjMhiECQDcaSplhoL4cCGdoAzcK75bkpeu7FvHd8p5Zz5qtfXpR' +
  'cCO/jUjsZMuGYFaR8j8jr9dNVD3eP0g95VnUuUd+ubg=' +
  '-----END RSA PRIVATE KEY-----'

// 加密
export function encrypt(txt) {
  const encryptor = new JSEncrypt()
  encryptor.setPublicKey(publicKey) // 设置公钥
  return encryptor.encrypt(txt) // 对需要加密的数据进行加密
}

// 解密
export function decrypt(txt) {
  const encryptor = new JSEncrypt()
  encryptor.setPrivateKey(privateKey)
  return encryptor.decrypt(txt)
}

