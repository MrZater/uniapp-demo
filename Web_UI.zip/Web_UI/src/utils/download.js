import axios from 'axios'
var CancleToken = axios.CancelToken
var source

export function downloadFile(url, saveName, progressCallback, callback) {
  source = CancleToken.source()
  axios({
    url: url,
    method: 'get',
    responseType: 'blob',
    cancelToken: source.token,
    onDownloadProgress(progress) {
      // 这里是下载的进度
      const pro = Math.round(progress.loaded / progress.total * 100)
      progressCallback(pro)
    }
  }).then(res => {
    if (window.navigator.msSaveBlob) {
      try {
        const blobObject = new Blob([res.data])
        window.navigator.msSaveBlob(blobObject, saveName)
        callback(true)
      } catch (e) {
      }
    } else {
      const blobUrl = window.URL.createObjectURL(res.data)
      const link = document.createElement('a')
      document.body.appendChild(link)
      link.href = blobUrl
      link.download = url.split('/').pop()
      link.setAttribute('download', saveName)
      link.click()
      document.body.removeChild(link) // 下载完成移除元素
      window.URL.revokeObjectURL(url) // 释放掉blob对象
      callback(true)
    }
  }).catch(function(e) {
    if (axios.isCancel(e)) {
      console.log('Request canceled', e.message)
    }
  })
}
export function cancleDownload() {
  source && source.cancel('download cancle by user')
}
