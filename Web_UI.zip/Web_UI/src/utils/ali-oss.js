'use strict'

import request from '@/utils/request'
import { dateFormat } from '@/utils'

var OSS = require('ali-oss')
var stsToken = {}

export default {

  /**
   * 创建oss客户端对象
   * @returns {*}
   */
  async createOssClient() {
    if (!stsToken || !stsToken.expiration || Date.parse(stsToken.expiration) <= Date.now() - 3600 * 1000) {
      stsToken = await request.get('api/storage/upload-token')
    }

    return new Promise((resolve, reject) => {
      if (stsToken) {
        const client = new OSS({
          accessKeyId: stsToken.accessKeyId,
          accessKeySecret: stsToken.accessKeySecret,
          region: stsToken.region,
          bucket: stsToken.bucket,
          stsToken: stsToken.securityToken
        })
        resolve(client)
      } else {
        reject('获取token失败')
      }
    })
  },

  getSaveName() {
    const date = dateFormat(new Date(), 'yyyyMMdd') // 当前时间
    const dateTime = dateFormat(new Date(), 'yyyyMMddhhmmss') // 当前时间
    const randomStr = Math.floor(Math.random() * (8999)) + 1000
    const fileName = date + '/' + dateTime + randomStr // 文件名字（相对于根目录的路径 + 文件名）

    return fileName
  },

  /**
   * 文件上传
   * @param option
   */
  ossUploadFile(option) {
    const file = option.file
    const self = this
    return new Promise((resolve, reject) => {
      const extensionName = file.name.substr(file.name.indexOf('.')) // 文件扩展名
      const fileName = (option.saveName ? option.saveName : self.getSaveName()) + extensionName

      // 执行上传
      self.createOssClient().then(client => {
        // 异步上传,返回数据
        resolve({
          fileName: file.name,
          fileUrl: fileName
        })
        // 上传处理
        // 分片上传文件
        client.multipartUpload(stsToken.prefix + '/' + fileName, file, {
          progress: function(p) {
            const e = {}
            e.percent = Math.floor(p * 100)
            option.onProgress(e)
          }
        }).then((response) => {
        //   console.info('multipartUpload', response)
          if (response.res.statusCode === 200) {
            option.onSuccess(stsToken.domain.replace(/(\/*$)/g, '') + '/' + response.name, file)
            return response
          } else {
            option.onError('上传失败', file)
          }
        }, err => {
          option.onError('上传失败', file)
          reject(err)
        })
      }, err => {
        option.onError(err)
        reject(err)
      })
    })
  }
}
