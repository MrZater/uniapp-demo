const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  token: state => state.user.token,
  refreshToken: state => state.user.refreshToken,
  expireTime: state => state.user.expireTime,
  roles: state => state.user.roles,
  user: state => state.user.user,
  userLogo: state => state.user.userLogo,
  redirectUrl: state => state.user.redirectUrl,
  loadMenus: state => state.user.loadMenus,
  permission_routers: state => state.permission.routers,
  socketApi: state => state.api.socketApi,
  baseApi: state => state.api.baseApi,
  fileUploadApi: state => state.api.fileUploadApi,
  updateAvatarApi: state => state.api.updateAvatarApi,
  qiNiuUploadApi: state => state.api.qiNiuUploadApi,
  sqlApi: state => state.api.sqlApi,
  swaggerApi: state => state.api.swaggerApi
}
export default getters
