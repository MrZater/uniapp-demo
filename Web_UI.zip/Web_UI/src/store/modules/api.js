const baseUrl = process.env.VUE_APP_BASE_API
const api = {
  state: {
    // 实时控制台
    socketApi: baseUrl + '/websocket?token=kl',
    // 修改头像
    updateAvatarApi: baseUrl + '/api/user/update-avatar',
    // 上传文件到七牛云
    qiNiuUploadApi: baseUrl + '/api/qiNiuContent',
    // Sql 监控
    sqlApi: baseUrl + '/druid',
    // swagger
    swaggerApi: baseUrl + '/swagger-ui.html',
    // 文件上传
    fileUploadApi: baseUrl + '/api/storage',
    // baseUrl，
    baseApi: baseUrl
  }
}

export default api
