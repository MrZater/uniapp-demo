import { login, logout, getInfo, oauthLogin } from '@/api/login'
import { setToken, removeToken } from '@/utils/auth'
import jwtDecode from 'jwt-decode'

const user = {
  state: {
    token: '',
    userLogo: '',
    redirectUrl: '',
    expireTime: 0,
    user: {},
    roles: [],
    // 第一次加载菜单时用到
    loadMenus: false
  },

  mutations: {
    SET_USERLOGO: (state, logo) => {
      state.userLogo = logo
    },
    SET_REDIRECT_URL: (state, url) => {
      state.redirectUrl = url
    },
    SET_TOKEN: (state, token) => {
      state.token = token
      state.expireTime = token ? jwtDecode(token).exp : 0
    },
    SET_USER: (state, user) => {
      state.user = user
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_LOAD_MENUS: (state, loadMenus) => {
      state.loadMenus = loadMenus
    }
  },

  actions: {

    UpdateUserLogo({ commit }, logoUrl) {
      commit('SET_USERLOGO', logoUrl)
    },
    // 登录
    Login({ commit }, userInfo) {
      const username = userInfo.username
      const password = userInfo.password
      const code = userInfo.code
      const uuid = userInfo.uuid
      return new Promise((resolve, reject) => {
        login(username, password, code, uuid).then(res => {
          setToken(res.token)
          commit('SET_TOKEN', res.token)
          commit('SET_REDIRECT_URL', '')
          setUserInfo(res.user, commit)
          // 第一次加载菜单时用到， 具体见 src 目录下的 permission.js
          commit('SET_LOAD_MENUS', true)
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 三方登录
    ReloadToken({ commit }, token) {
      return new Promise((resolve, reject) => {
        setToken(token)
        commit('SET_TOKEN', token)
        commit('SET_REDIRECT_URL', '')
        resolve()
      })
    },

    // 三方登录
    OAuthLogin({ commit }, data) {
      return new Promise((resolve, reject) => {
        oauthLogin(data).then(res => {
          setToken(res.token)
          commit('SET_TOKEN', res.token)
          commit('SET_REDIRECT_URL', res.fromUrl)
          setUserInfo(res.user, commit)
          // 第一次加载菜单时用到， 具体见 src 目录下的 permission.js
          commit('SET_LOAD_MENUS', true)
          resolve(res.toUrl)
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 获取用户信息
    GetInfo({ commit }) {
      return new Promise((resolve, reject) => {
        getInfo().then(res => {
          setUserInfo(res, commit)
          resolve(res)
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 登出
    LogOut({ commit }) {
      return new Promise((resolve, reject) => {
        logout().then(res => {
          logoutToken(commit)
          resolve(res)
        }).catch(error => {
          logoutToken(commit)
          reject(error)
        })
      })
    },

    // 登出
    RemoveToken({ commit }) {
      logoutToken(commit)
    },

    UpdateLoadMenus({ commit }) {
      return new Promise((resolve, reject) => {
        commit('SET_LOAD_MENUS', false)
      })
    }
  }
}

export const logoutToken = (commit) => {
  commit('SET_TOKEN', '')
  commit('SET_ROLES', [])
  removeToken()
}

export const setUserInfo = (res, commit) => {
  // 如果没有任何权限，则赋予一个默认的权限，避免请求死循环
  if (res.roles.length === 0) {
    commit('SET_ROLES', ['common'])
  } else {
    commit('SET_ROLES', res.roles)
  }
  commit('SET_USER', res)
}

export default user
