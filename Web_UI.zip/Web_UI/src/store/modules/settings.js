import defaultSettings from '@/settings'
import variables from '@/styles/element-variables.scss'

const { webName, caseNumber, footerTxt, showFooter, fixedHeader, sidebarLogo, uniqueOpened } = defaultSettings

const settings = {
  state: {
    fixedHeader: fixedHeader,
    sidebarLogo: sidebarLogo,
    theme: variables.theme,
    uniqueOpened: uniqueOpened,
    showFooter: showFooter,
    footerTxt: footerTxt,
    caseNumber: caseNumber,
    webName: webName
  },
  mutations: {
    CHANGE_SETTING: (state, { key, value }) => {
      if (state.hasOwnProperty(key)) {
        state[key] = value
      }
    }
  },
  actions: {
    changeSetting({ commit }, data) {
      commit('CHANGE_SETTING', data)
    }
  }
}

export default settings
