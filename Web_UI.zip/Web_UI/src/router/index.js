import router from './routers'
import store from '@/store'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css'// progress bar style
import { getToken } from '@/utils/auth' // getToken from cookie
import getPageTitle from '@/utils/get-page-title'
import { buildMenus } from '@/api/system/menu'
import { filterAsyncRouter } from '@/store/modules/permission'
import { getDataP } from '@/api/data'

NProgress.configure({ showSpinner: false })// NProgress Configuration

const whiteList = ['/login', '/oauth']// no redirect whitelist

router.beforeEach((to, from, next) => {
  // set page title
  document.title = getPageTitle(to.meta.title)

  NProgress.start() // start progress bar

  // // 判断url参数中是否有access_token，有则自动登录
  const access_token = to.query.access_token
  if (access_token && access_token.length > 0) {
    store.dispatch('ReloadToken', access_token).then(() => {
      delete to.query.access_token
    }).catch((err) => {
      console.log(err)
    })
  }

  if (getToken()) {
    // 已登录且要跳转的页面是登录页
    if (to.path === '/login') {
      next({ path: '/' })
      NProgress.done() // if current page is dashboard will not trigger	afterEach hook, so manually handle it
    } else {
      if (store.getters.roles.length === 0) { // 判断当前用户是否已拉取完user_info信息
        store.dispatch('GetInfo').then(res => { // 拉取user_info
          // 动态路由，拉取菜单
          loadMenus(next, to)
        }).catch((err) => {
          console.log(err)
          store.dispatch('LogOut').then(() => {
            location.reload() // 为了重新实例化vue-router对象 避免bug
          })
        })
      // 登录时未拉取 菜单，在此处拉取
      } else if (store.getters.loadMenus) {
        // 修改成false，防止死循环
        store.dispatch('UpdateLoadMenus').then(res => {})
        loadMenus(next, to)
      } else {
        next()
      }
    }
  } else {
    /* has no token*/
    if (whiteList.indexOf(to.path) !== -1) { // 在免登录白名单，直接进入
      next()
    } else {
      next(`/login?redirect=${to.path}`) // 否则全部重定向到登录页
      NProgress.done()
    }
  }
})

export const loadMenus = (next, to) => {
  buildMenus().then(res => {
    const asyncRouter = filterAsyncRouter(res)
    asyncRouter.push({ path: '*', redirect: '/404', hidden: true })
    store.dispatch('GenerateRoutes', asyncRouter).then(() => { // 存储路由
      router.addRoutes(asyncRouter) // 动态添加可访问路由表
      next({ ...to, replace: true })
    })
  })

  getDataP('api/tenant/domain', { domain: document.domain }).then(res => {
    if (res && res.tenantConfig) {
      var userLogoUrl = ''
      if (res.tenantConfig.hasOwnProperty('logoUrl') && res.tenantConfig.logoUrl.length > 0) {
        userLogoUrl = res.tenantConfig.logoUrl
        var link = document.querySelector("link[rel*='icon']") || document.createElement('link')
        link.type = 'image/x-icon'
        link.rel = 'shortcut icon'
        link.href = userLogoUrl
        document.getElementsByTagName('head')[0].appendChild(link)
        store.dispatch('UpdateUserLogo', userLogoUrl)
      }
    }
  }).catch(err => {
    console.log('domain_erro:', err)
  })
}
router.afterEach(() => {
  NProgress.done() // finish progress bar
})
